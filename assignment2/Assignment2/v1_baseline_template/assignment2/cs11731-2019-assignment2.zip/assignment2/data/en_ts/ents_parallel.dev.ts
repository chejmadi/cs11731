Ku humelela loku hi tlhelo ra mapatu ku hi tsundzuxa lava va nga tirha eka mfumo lowu khale lava a va lava swo antswa eka tiko ra hina
Sweswi ku tlula eka nkarhi lowu nga tshama wu va kona
Ndzi khensa hi ku tshembeka eka hinkwenu ka n'wina ntirhisano wa n'wina.
Yuropo na Amerika swi hoxa xandla eka tihakelo ta le henhla
Ndzi ta boxa ntsena swimbirhi swa swona.
Kutani swi le rivaleni leswaku a hi nge fikeleli leswi hi tivekeleke swona.
Fambelanisa matshalatshala
Ekusunguleni a ku katsiwe 10 wa matiko
Galileo se u kaneriwile.
Nongonoko lowu wu tirha eswibedhlele ni le titliliniki ku sivela nsiko wa vana.
Vaxanisiwa lava nga riki ehansi ka ntlhanu va dlayiwile ekaya eka doroba ri ri rin'we.
dokumende ya vuxavisi
Leswi ndzi swi ringanyetaka i tlhontlho lowukulu.
Xana u tsakela ku burisana hi mhaka leyi hi nkarhi wa ntsombana lowu?
Ndzi na timhakanyana ti nga ri tingani.
Mbumambumelo
kambe ku nga ri hi ndlela yo antswa swinene.
Kokoana
hi ku ya hi timfanelo ta vanhu ta masungulo
Swiphiqo swin'wana swa ha ri kona.
soyi
Hambiswiritano, leyi i mhaka ya swa vumbiwa.
Sweswo i vukala xihundla.
Vuhleri bya vusweti na swa rimbewu leswi khumbaka mfuwo wa vaakitiko na mitlawa leyi nga na vutsakeri.
ha twanana eka timhaka to angarhela na to endla kunene.
Loko aphili yi ri makongomana na ku ala ka komiti ku pfuxeta rejistrexini ya munhu
LESWAKU ku TEKERIWA ENHLOKWENI xiboho xa EM 111 / 2004 xa Meyarankulu lexi sikuhatiweke 19 Mhawuri 2004.
Hi tshembha leswaku hi na xivangelo xo tinyungubyisa hi swina.
Ku sunguriwa ka mphamelo: nkoka wa swakudya na mati.
maendlelo ya miehleketo kumbe mavonelo yo khuma mayelana na ntlawatsongo wun'wana na wun'wana loko hi lava ku xixima ku hambanahambana ka mfuwo.
Loko swi ri tano, va ta va va nyumisiwile.
Tatana Xipikara na Mutshamaxitulu,
tlilorini na swilo leswitsongo
Vamasipala Vamasipala vanga hoxa xandla eka ku xava na ku hakelela switirhisiwa na ntsengo lowukulu wa tiphurojeke.
Loko mufi a nga xanisiwi hi vuvabyi byo tlulela, papila ro huma eka dokodela leri kombisaka leswaku ku tleketliwa a swi nge vi na nghozi eka rihanyo ra vaaki.
Hambileswi ku nga na ndzima leyi, ntirho wo tala wu lava ku endliwa.
khanselara wa wadi
U fanele ku yi landza eka DLTC laha u endleke xikombelo xa wena.
a va avanile eka mhaka leyi.
Xana hi ta tirhisa njhani xiyimo?
ndza yi lemuka mipfilungano leyi.
Swikombiso swa nkoka mayelana na leswi swi katsa:
Va amukeriwile.
A nyanya, ku nyanya swinene.
Hi fanele ku seketela mhaka ya swivandla leswi pfalekeke.
Xiviko a xi tekeli enhlokweni
Tanihilaha mi tivaka hakona mitlangu na ndhavuko hi yona ndlela ya matirhelo eku hundzuluxeni ka rixaka.
1998 swikongomelo swa ku teka xiave ka vaakindhawu swi koxometiwile eka mune wa misinya leyi landzelaka
xidzana
NCOP yi tikarhatela ku fikisa emakumu Milawumbisi leyi ku nga si hela mavhiki ya tsevu ku endlela leswaku ku va na ku nghenelela ka vaakatiko hi ku gingirikeka na ku nyika nkarhi wo ringanela eka swifundzankulu wo nyika matimba eka vurhumiwa bya swona.
dzovo
Dyondzo yi tiyisisa vumbundzuku eka vantshwa.
Vukorhokeri byo Pfuneta Mindyangu Swiphiqo hinkwaswo swi nga oloxiwa!
Ndzi fanele ku engeta leswaku hi dinga ku khomisa xisweswo.
Swi le rivaleni leswaku hi fanele ku va na endlelo ra xiyenge xo karhi.
tinhlayohlayo ta rihanyu na swa nkoka
Swo tala swa switori leswikulu i switori swa rirhandzu.
kambe n'wana wa mudyondzisi wa kwala mugangeni a khomeriwa nandzu wo fana naswona khoto yi nwi chaja ku fana ekhoto.
Lexi i xivangelo xin'wana xa xivutiso xa mina.
Hi marito man'wana, leswi i swa nkoka swinene.
swona swi hambanile swinene.
endlelo hi leri landzaka
Mbuyelo hi leswaku a ku na endlelo rin'we.
African People's Convention - xivandla xin'we
Sweswi ndzi ta eka swiphemu swa nguva yo leha swinene.
Leswi swi ta pfuna eku tumbuluxiwen ka vuswikoti bya mafambiselo.
55% wa timhangu
Yi valanga tindlela ta mafambiselo ya ntlimbo na ku nyika manghenelo eka swikili swa masungulo swa mafambiselo ya ntlimbo.
Hakunene, a ndzi tshembi ku sweswo swi ta vanga xiphiqo.
Vuxokoxoko bya pfhumba ra lembe leri byi ta tivisiwa hi ku famba ka nkarhi eka vhiki leri landzelaka.
Vadyondzi va hina va komba leswaku va nga sisimuka eka tlhontlho lowu.
Leswi swi fanele ku voniwa tanihi xitoloveto xin'we ntsena.
mbango na rihanyu
matsavu yo cheriwa emathinini
Ku tshama etindlwini swi nga ri enawini.
n'wana loyi a nga hansi ka malembe mambirhi naswona u ri muhakeri eka Nkwama wa Ndzindzakhombo wa Vamahlalele (UIF) u nga ha koxa mimbuyelo ya adopuxini.
xisohesohe
Nhlamulo yi kwihi ke?
Vhoti yi ta va kona eka timinete tingaritingani.
Tikomiti ta Tiwadi ti:
Ndza tshemba leswaku lexi a xi nga ta laveka.
tumbuluxa kumbe ku hlamusela mitirho na vutihlamuleri bya tikomiti ta tiwadi.
Ha swi tiva leswaku i va ngani va nga vana.
ximilana
Varhangeri lava va na vutihlamuleri byo tiyisisa leswaku swisandzu na ku kombisa ku vilela swi endliwa hi ndlela ya xindzhuti na ku komba ku kula.
A hi twisisa kuri hikokwalaho ka yini swi kotlanile ni minhlawulo eUSA.
Xikombiso, mavandla ya twanana leswaku vandal lerin'wana ri ta nyika tlhelo ra rona ra mhaka, va endla ta no va nga ngheneleriwi.
Naswona leswi kumbexana i ntiyiso hi man'wana ya matiko lawaya.
kambe hi xona xiyimo xa kona.
Yimela van'wana ku ringeta mianakanyo eka ntlawa.
Kambe sisitimi yeleyo a yi twanani na sisitimi yin'wana ya Sisitimi ya Vululami bya Vugevenga.
Tiphesente ta mindyangu leyi nga ni ndlala yi yile ehansi ku suka eka 29,3% hi 2002 ku fika eka 13,4% hi 2013.
Eka hina, nhlangano wa swifundzha a wu nga vi na nkoka.
Mfumu wu ya emahlweni ku kongomisa no kurisa ku dyondziwaka Tinhlayo na Sayense ya Fizikali tani hi ku tumbuluxa vuswikoti bya matimba lebyi lavekaka eka ikhonomi ya hina leyi ya ha kulaka.
mphamelo wo hlanganiseriwa swi vula ku mamisa na ku tlhela u nyika n'wana masi man'wana kumbe swakudya
Swoleswo a swi ta va swi lulamile.
Chati leyi nga laha hansi yi kombisa minsawutiso leyi nyikiwaka vana na vukhale lebyi va
tiphurojeke ta nhlanganelo wa a ti katsa leti landzelaka
Minxava ya vahumelerisi i ya nkoka eka van'wamapurasi.
Lowu i njhekanjhekisano wa xisayense ku tlula wa xipolitiki.
vuafrikahato
Ndzi ehleketa leswaku i xihumelelo xo ka xi nga twisiseki.
vumba
Va fanele ku tshembisa leswaku va ta rhumela swilo swo tala hi switimela.
Veka nhlengeletano eka nkarhi lowu nga kahle eka lava u lavaka leswaku va nghenela nhlengeletano leyi.
Vona va twisisa sisiteme leyi.
Ya pfuna hikuva wa swi tiva leswaku u angarherile hinkwaswo leswi lavekaka.
mavanyisa-milambu
malawulelo ya mavabyi na vutshunguri.
vatirhi
xitifikheti xa vukati
nsivelo hi miri
Ndzi ehleketa ku ri hi dinga ku endla hi ndlela leyi.
Swinawana swa Makunguhatelo ya Masipala & Mafambiselo ya Matirhelo, 2001.
Hi ve na mikanerisano yo leha eka mhaka leyi.
I va mani va kumaka tindhawu leti?
Ku na timhaka to tala leti hi khumbaka eka xiyimo xa misava hinkwayo.
Swoleswo i ku hambanisa ka nkoka.
va nga ha kuma fayini.
Ndzawulo ya Vuphorisa
silin'i
ti fanele ku tiva leswaku
Swilo swa antswa swinene sweswi.
Masonja
Mitlhontlho leyi ya hinkwavo yi hetelele hi xiyimo xo hlanganeriwa.
Malawulelo ya xona ya tale endhawini yin'we lero a xi tirhi.
naswona ku cinca kwihi na kwihi ka pholisi ya tihakelo ku fanele ku famba na mpimanyeto wa masipala wa lembe na lembe lowu nyikiwa eka huvo hi ku ya hi xiyenge xa 16 xa Nawu wa Mafambiselo ya Timali ta Masipala.
Sisiteme ya swingolongondzwana swa nkarhi yi ta tirhisiwa.
Ha ha yimele mivuyelo yo fuwa, hambiswiritano.
Tanihileswi un'wana na un'wana a swi tivaka
Palamende yi simekile Tihofisi ta Palamende ta Xidemokirasi eka swifundzhankulu - Limpopo
Hikokwalaho, ndzi ta vulavula mina hi xiviri.
ndzima yi endliwile.
Mfumo wa Miganga: Nawu wa Mafambiselo ya Timali ta Masipala, 2003
xigandlu
Vana
mikarhi ya nkunguhato yi fanele yi va leyi yi pfumelelaka vanhu va va aki ku va kona (hambi i na mixo
hi masungulo.
Switulu leswi vuriwaka eka mhaka ya 2 swi fanele ku averiwa Minhlangano leyi phikizanelaka nhlawulo, hi ndlela leyi landzelaka: "; na
Ndzi fanele ku vula leswaku ndzi titwa ndzi nyanyukile hi tlhelo rin'wana.
Tanihileswi tinso ti tirhaka mitirho yo tala yo hambanahambana
Tihositele leti vutshamo byi nga endliwa tiyuniti ta mindyangu.
Bindzunyingi (tinkota ta rixaka)
tindlu na nsirhelelo wa vanhu.
Lexi xi fanele ku amukeriwa, hambiswiritano.
Ku na xiphiqo xikulu xa switumbuluxiwa swo tenga.
Endla xikombelo eka embasi ya Afrika Dzonga kumbe mixini loko u tshama eka matiko ya le handle.
nhlahlu wa tihlo
Mukondiraka u tirhisa vanhu va le handle lava nga tiviki ndhawu yaleyo naswona nkarhi wun'wana maphasela ya swakudya a ya fikeleli va vuyeriwa.
Ndzi ringanyetile leswaku hi ya emahlweni na muhundzulo lowu.
Vulandzelerisi bya nghingiriko wa komiti ya wadi
xava nkarhi wa vunavetisi / kumbe ndhawu leyi lavekaka leswaku ku ta va ni ku humelela ka nongonoko wo navetisa wa mfumo
Namuntlha, hi kota ku famba hi ya ehenhla en'walungwini hi nga chavi ku khomiwa.
a ndzi yimi na wona hisekelo lowu.
Hi ku tiyisisa xi fanele ku va hi ndlela leyin'wana.
Xivangelonkulu xa rifu
eka nkarhi wa sweswi
Xikombiso xa vumbirhi i xa ku riha timali leti tirhisiweke.
Leswi swi languteriwa ku humelela elembeni ra 2004.
nkoka lowu nga vaka kona wa vumakelo lebyi a wu ehleketeki.
4. NKONGOMISO WA TINDLELA TA MATIKHOMELE
A ndzi lavi ku nghena eka leswi ku ya emahlweni namuntlha.
Ha ha ri ntsena eka goza ra ku veka swikongomelo.
Pulanete yi fanele ku sirheleriwa hi hina kusuka eka hina vinyi.
Ndza ku kombela
Xa vumbirhi hi ta va hi ri ku papalateni ka ku xandziwa ka mphikizano.
Swiphiqo swa nthyakiso wa mbango a swi se vonaka hikwalaho ka lahlekelo wa swikili.
Timali na Mafambiselo ya ku Xava Tinhundzu eka Ndzawulo ya Timhaka ta Xikaya.
Hi tlhelo lerin'wana, ndzi vhotile ndzi kaneta ntwanano hi woxe.
Ku na mune wa swilaveko swo rhanga eka ku humelela ka yona
Swi tikomba onge ka ha ri na mapheji matsongo ku hetisa.
Ku nga cincacinci ka swipimo leswi sindzisiwaka hi mihlangano ya misava.
Hambiswiritano, ku ringanisa a hi swilo leswi nga fikeleriwaka hi ku sindzisa.
Xan ku nga sirhelelkanga loku ku ku cinca njhani elembenir? 1
Hi fanele ku nyika nyingiso wo tala eka nkoka wa mitlawa ya vatirhisani.
Ndzi se ndzi vulavurile hi mfanelo ya vukhondzi.
Ku nyika vukorhokeri bya swa nawu eka swisiwana na vanhu lava pfumalaka.
kumbe hi ndlela leyi swi nga va ka xiswona. '
A swi nge ringanani.
vuswikoti na minkoka yi ta kamberiwa.
Ku ni swo tala swinene leswi faneleke ku endliwa eka sweswo.
Hi ta fikelela hi ku hatlisa ntwanano eka swoleswo.
[Hoxa logo ya munyiki wa vukorhokeri]
Va swirhundzu na va matlhari, langutani mitiyiso eka matiko hinkwayo.
I goza
"Swivandla swa ndhuma" swi nga ha endliwa swa mihlangano hi xivumbeko xa mitlawa kumbe mihlangano (xik. Foramu ya Alana na Vun'wini byo ka byi nga ri bya Mfumo kumbe mihlangano ya vaakindhawu), kambe yi tala ku va mipaluxo ya nkarhinyana ya nkalaenetiso wa vaakindhawu kumbe ku hambana ka miehleketo.
Leswi swi ta va pfuna ku antswisa eka mitirho yo landzela na ximakiwa xo hetelela.
Hambiswiritano, ku na nkayivelo.
A wu yimi u ri wexe eka ku va vagingiriki va ntshembo.
Naswona a swi fanelangi ku teka nkarhi wo leha.
Hambiswiritano, ku cinca ku na nkoka.
Phakeji leyi ya maxelo na yona i ya mayelana na vumundzuku bya swa tipolitiki.
na swona yena
Ngopfu-ngopfu, ku hava vumbhoni byo ringanyeta leswaku minhlaselo ya mapurasi ya susumeta hi tipolotiki.
Hambiswiritano, a swi fanelanga ku hi kongomisa eka vuxisi bya le rivaleni.
Leswi swi vula ku veka mimpimo yo hohlotela nhluvuko wa swa ikhonomi.
Tiko swi vula Mfumo wa Riphabiliki ra Afrika-Dzonga lowu tirhaka hi ku leteriwa hi Holobyenkulu;
Xiyimo xo ka xi nga ri kahle
nhlangano wa tinomboro
Hikokwalaho ndzi ta xi nghenisa eka vhoti endzhaku ka nkarhi.
pfumala vatswari (kumbe vatswari va nga tiveki leswaku va tshama kwihi);
Hambiswiritano, i xivandla xo pfilungana swinene.
Ha khensa eka hinkwaswo.
KU HANYA HI KU NTSHUXEKA NA XITSONGWATSONGWANI
Ndzi ehleketa leswaku sweswo, hi ndlela yoleyo, i endlelo ro lulama.
Xiyimo xa Khomixini tanihi ndhawu leyi langutisiwaka ya timfanelo ta ximunhu eAfrika Dzonga.
Swi na nkoka swonghasi ku tirhana na xona hi ndlela leyi.
Phepha ra tifomula leri katsiwile eku heteleleni ka phepha ra swivutiso.
vuvabyi bya switsongwatsongwana
Hlamusela leswaku ntirho lowu wu teka nkarhi na leswaku loko ku tirhiwa na vaakindhawu ku hluvukisa kungu ra wadi, ku fanele ku nyikiwa nkarhi wo ringanela ku kota ku endla tano.
U ni digiri ya Masitasi ya vurimi.
Migingiriko yo karhi ya swa ikhonomi ya laveka ku kota ku hlayisa ku hambanahambana ka swivumbiwa.
Milawu ya Manjhekanjhekisanelo hi malembe ya 1990.
Ku tirhisa mpimo wo ringanela wa eneji eka misava leyi hluvukeke swi swi le ka xipyimo xa le hansi ku tlula mpimo.
Nkwama i nkunguhato wa xinawu laha vulawuri bya nhundzu byi hundziseriwaka eka munhu kumbe nhlangano (vun'winyi hi xinawu) leswaku ku vuyeriwa munhu un'wana (muvuyeriwa).
milimitara
Xa vumbirhi, xiyimo xa ikhonomi.
Clubview 16 / 04 @ tiawara ta 17
Nyika mavonelo eka ximakiwa lexi nga ku ndlandlamukeni;
Hambiswiritano, milawu yi fanele ku landzeleriwa.
Ku kondletela ndzingano wa rimbewu na swivandlanene swo tala eka vanhu lavatsongo i mikongomelo leyi pfanganisiweke leyi yi kumekaka eka kungu leri hinkwaro.
Loko swi fanerile, hi ta fanela ku sungula nongonoko wa migingiriko laha.
Ndza tshemba hi lahlekeriwile hi nkateko laha.
Hi mukhuva wolowo, ku na xivangelo xin'wana na xin'wana ku nyika nseketelo lowu faneleke.
I ntirho wa hina ku va pfuna.
Swiboho swa hakelo yo suka eka nkwama swi fanele ku suka eka endlelo ra nkunguhato
Xana hi yihi YIN'WE ya tipulani ta bindzu leti landzelaka ke?
Xana swi nga va na khombo hi ndlela yihi?
5.2.4 Ntirho wa vaakitiko eka tiMSP
Vukorhokeri bya ambulense ya phurayivhete na byona byi tirhela vaaki.
Swikumiwa eka switirhsiwa swa 186 eka swifundzha hinkwaswo hi 2013 swi kombisile leswaku minhlayo xikarhi ya mimpimo yo khomiwa ka xindzhuti
hlaya maphephahungu na ku yingisela rhadiyo
Vukorhokeri hi Swamati "PI 1"
Hambiswiritano, hi fanele ku hlamusela swi twisiseka leswaku vumunhu na mahanyelo lamanene swi vula yini.
Ndzi amukela phurojeke leyi.
Leyi i mhaka leyi faneleke ku tekeriwa enhlokweni.
Xiendleko xa 14 xa CBP: SWOT ya mitlawa na mitlawa ya vusweti / rimbewu (hilaha swi nga tsariwa hakona eka Xiyenge xa 2 xa makungu ya wadi)
1993 naswona leswi nga kumiwa no longoloxiwa eka xiyenge xa 182 xa Vumbiwa bya khale
Xana munhu wihi kumbe wihi u lava ku vulavula hambana na xiringanyeto lexi?
a hi nge vi na vutihlamuleri.
hekitara
Nhlanganelo wa minghingiriko
Swi na nkoka ku twisisa ku hambana loku nga kona exikarhi ka ku kambisisa, ku kambela na ku veka tihlo.
Mutirhisi u fanele a hakela vukorhokeri bya gezi lebyi a nyikiweke byona eka ndzhawu ku nga ri endzhaku ka siku leri vekiweke.
Endla xikobelo eka Senior Manager: Animal Health, loko u lava ku katsiwa eka nongonoko lowu wu hangalasiwaku.
wu amukela mfanelo yo phiketa.
Maendlelo ya swa Bindzu ra SADC i swin'wana swa tiphuphu ta maendlelo ya nhlanganelo wa xifundza xa SADC.
lowu langutisiweke eka xiyengetsongo xa
hi ta va na nkateko wo endla sweswo.
Ku na swiphiqo leswo tala swinene swo hambanahambana.
Xexo ku tava xiyimo xa hina.
Eka mhaka yaleyo, hi fanele ku gingiriteka ku nga ri ku debya.
Khabinete yi amukela mbuyelo wa vulavisisi lebyi nyikaka vumbhoni lebyi kumekaka hinkwako eku swekiweni ka mixavo
I mani a nga ta hakelela leswo?
Xana i yini swiphemunkulu swa mpfumelelanompfampfarhutwa?
Sweswo a swi fanele ku va etimbilwini ta mbhurisano wa hina.
loko Tihuvo ta Mhasipala ti nga ha hlawula Komiti ya vufambisi kumbe Komiti yin'wana
cinco wa nsumo
Tisisa tindlela to tihanyisa ta mitlawa ya vanhu vo karhi,ku katsa tinhundzu ta vona, mitlhontlho, mivuyelo leyi languteriweke, na mikateko leyi nga kona.
Ku gangisa na swikombelo swa maphorisa yo tinyiketela.
Munghana wa wena a nga na tsakeli ku xava mikavelo eka khampani leyi.
mfumu wu ta fanela ku
kumbexana i nchumu lowu nga landzeleriki swinawana.
Ndzi humese tinhloko mhaka timbirhi.
Vutleketli bya tinhundzu bya boheka ku durha.
Ku hlangana ka timasipala hi ku angarhela swi katsa tiko hinkwaro.
Ha kunenenene, kumbe a hi nga fanelangi ku hlamala.
Hi fanele hi nga ngheneleli eka tipolitiki ta mihlangano.
Hambi swi ri tano, varhangeri va tindzawulo, hi ku ya hi vutihlamuleri lebyi va nga na byona ku ya hi xiyenge xa 7(3)(b) xa nawu wa vurhangeri bya xiviri na mafambisele ya tindzawulo na ku ya hi milawu yo tshinya, va fanele ku tiyisisa leswaku matikhomele ya vatirhi va vona ya fambelana na matirhele na ilawu leyi fambisaka milawu ya mfumo na matirhele lawa ya nga vekiwa ku ya hi milawu ya mfumo.
ndzi ehleketa leswaku ku na swo tala ku va mi swi endla.
ku ni swimbonani swintsongo leswi phatimaka ku tlula lembe leri hundzeke.
Hi ndlela yo fana, xivandlankulu xa ndzavisiso xi avanyisiwile.
mfungho wa bizi
4.4 Khabinete yi amukerile ku thoriwa nakambe ka swirho leswi landzelaka eka Bodo ya Vukorhokeri bya swa Timali.
Nxopaxopo wa mpimanyeto wa swa timali wa rimbewu wu nyika vamanana xikombo xa ku tiboha ka mfumo ku lulamisa swilaveko swo kongoma vamanana na timfanelo ta nhlayiso wa swa rihanyo, dyondzo na mathoriwelo.
Xitifiketi xo koma xa mucato xa nyiketiwa kambe a ku na timali leti hakeriwaku loko ku nyiketiwa xitifiketi lexi nga nawini hi ku rejistara mucato.
tlawa wa tindlu
A hi ehleketi leswaku ku nga va na swirhalanganyi swa vufambisi leswi nga ta ka swi nga hluriwi.
Ku khoma hi mbilu swi tala ku vangiwa hi ku pfaleka ka nkhuluko wa ngati ku ya embilwini na le byongweni.
xikongomelo xa ku nyika vuxokoxoko xi ta va xi nga ha ri xa nkoka.
Loko Nawumbisi lowu hundziseriweke eka Nhlengeletano ya Milawu hi ku landza ndzimana ya (g) kumbe ya (h) wu nga pasisiwi hi Nhlengeletano ya Milawu Nawumbisi wolowo wu hundzela hi nkarhi, kambe Nawumbisi tanihi laha a wu pasisiwile hi Nhlengeletano ya Milawu eku sungulena wu nga ha pasisiwa nakambe hi Nhlengeletano ya Milawu, kambe hi ku seketeriwa hi vhoti ya swirho swa yona swa mbirhi-xa-nharhu kumbe ku tlula.
8. Xitici xo veka swiharhi swi ri swoxe eDurban a xi le ku tirheni sweswi
Xikongomelonkulu xa ndzetelodyondzo lowu i ku:
Swivandla swa ntikelo leswi nga na vutihlamuleri eka vusimeki
Va lava leswaku hi va pfuna eka ku tikarhata ka vona.
Kutani, hi ta va na mbulavurisano ku nga se fika nkarhi wo wisa wa ximumu.
Laha ku nga na mfungho wa ()
A swi tika ku va ndzawulo yi landzelerisa vinyi va tikontiraka.
Maendlelo ya swa mfuwo.
Timinete ta mina timbirhi a ti ndzi pfumeleli ku ya emahlweni.
Hi mavonelo ya mina ku na xilaveko xo vekiwa erivaleni laha.
A hi tlheleli eka maendlelo ya ntolovelo.
Hlohlotela ku va erivaleni - u nga a vi vanhu loko va nyika mavonelo ya vona.
Hlamusela swiyimo laha ku navetisa ku fanele ku humelela leswaku ku nga tava ko humelela.
xibukwana xa Vutivi (Resource Book), xa tikomiti ta tiwadi, lexi hlamuselaka leswaku CBP na IDP i ntswini na ndlela leyi swi hlanganaka hi yona.
U kombisile ku vilela eka khomixini ya vugevenga.
8. Ku siviwa ka mhaka ya 11 hi mhaka leyi landzelaka:
Ku nga hlayiwa yini?
Xo sungula, vufambisi bya xitirhisiwa xa mati leswi nga mhikizano wa misava mayelana na Vumbiwa.
hi vulawuri a endla swikombonkulu swa matirhelo leswi nga fanela na leswi nga tirhaka eka mfumo wa miganga hi ku angarhela; na
Ndzi nga ka ndzi nga ku nyiki switshunxo hambi xin'we namuntlha.
Sweswi swi fanele ku endliwa hi masungulo ya le henhla.
kumbe nhlengeletano yi languta kungu ra ku aka gondzo rintshwa eka ndhawu yo karhi.
A ndzi ta tsakela ku nkhensa un'wana ni un'wana loyi a nga kona.
Vumbiwa ra Afrika-Dzonga ri na Tsalwa ra Timfanelo leri tiyisisaka nsirhelelo wa timfanelo.
Hi 2006, Vukorhokeri bya Switsundzuxo bya Riverside byi nghenelerile, byi tsundzuxa hi swa xithekiniki, mafambiselo, swa timali na nseketelo wo letela.
ku vevukeriwa ka laveka
Hi fanele hi hangalasa mahungu ya leswaku ku hava murhi wo tshungula HIV / AIDS.
Xiyimo xa 3 i ku ya emahlweni ka switirhisiwa swa madyondzele.
Xana swivilelo leswi swi tekeriwile enhlokweni eka mpimanyeto ke?
Ku ya ehansi a ku fanelanga ku endla leswaku hi cinca tipulani leti.
Tumbuluxa vutleketli bya vaaki lebyi tirhaka hi ndlela yo antswa, yo hlayiseka na ku koteka.
-khumba
Loko NCOP yo lava ku cinca swo karhi eka Nawumbisi, Nawumbisi lowu wu fanele ku vuyiseriwa eka Huvo ya Rixaka leyi nga ta amukela kumbe ku alelana na ku cinca loku.
Khomferense yi na xikongomelo xo kambisisa vuhundzuluxi bya swo twiwa no voniwa eka theyori na ku endla, ku tiyisisa leswaku swilaveko swa ririmi swa vahangalasi na vahaxi, ku kanela mahlanguti ya swa ririmi na mifuwo ya AVT, ku langutisisa eka ku tirhisana exikarhi ka indasitiri na swivandla swa xiakhademiki, ku lavisisa ku fambelana na matirhiselo ya theyori ya vuhundzuluxi eka muxaka lowu wa vuhundzuluxi.
Ndzi ta tsakela ku kombisa leswi hi xikombiso xa sweswi.
siku, vhiki, n'weti, kumbe lembe
Loko va ha ri kona, va fanele ku susiwa.
Tinkota ta rixaka
xiyelaniso, endlelo, xitalo na xedulu ya ku hlengeleta switiviwa
Swi sirhelela timfanelo ta vatirhi no sivela ku chavisiwa.
Nkayivelo wa ku rhula, vusirheleri na timfanelo ta ximunhu, nhluvukiso wo tiyiseleka swi ta tika ku swi fikelela.
Ndza tshemba leri i goza ra nkoka swinene ku ya emahlweni.
Va lava ku vona mbuyelo wa kahle hi xihatla.
Swi tano, hi kanetana ni mianakanyo ya muxaka walowo.
Xana u na yona mli xo sungula?
Nkul Max Sisulu
Fomo ya CoR 21.2: Xitiviso xa Munhu loyi a Pfumeleriweke ku amukela Vukosi
Vanhu vo tala se va hlamuserile timali ta swa mahanyelo kumbe ntirho wa vona.
nhlangano wa dyondzo
Lembe ximali ri famba ku sukela hi ti 1 Mawuwani ta lembe rin'wana na rin'wana ku fika ti 30 Khotavuxika ta lembe leri landzelaka
huvo yo rhendzeleka
Hikokwalaho hi na nkarhi wo ringanela.
tiko rin'wana
"Loko hi endla hangalaso nakambe hi fanele ku tekela enhlokweni ku kumeka ka swakudya.
Mhaka ya nkoka i ndlela yo fika kona.
Engetelo lowu nghenisiweke, wu na ntsengo wa 20% ta engetelo wa tilevhele ta nkarhi lowu nga hundza ta timali.
Swi tlakusa nhlayo ya vaxanisiwa va swa vungungumerisi.
Loko u lava ku teka byala bya wena lebyi u byi xaveke ematikweni ya le handle eka nhlaluko ro nghena etikweni u fanele ku endla xikombelo xa xitifikheti eka Xiyenge xa Nsivelo wo Ndlandlamuxiwa xa Ndzawulo ya Vurimi, Swihlahla na SwavuhIipfi (DAFF) enhlalukweni ro nghena etikweni leswaku byi ta rhwariwa byi yisiwa laha u lavaka ku byi xavisela kona eAfrika-Dzonga.
Longoloxa mitirho ya mafambiselo eka nhlangano.
ndzi seketela endlelo leri vuyerisaka vaakitiko swinene.
Ntshunxeko wa ku vulavula i wutsongo.
Eka xiyimo xa vuphatnara byo pfumelelana hi nomu (verbal partnership)
Hi anakanya leswi ku va masungulo ya kahle ya nkanerisano.
ku va ri tirha kahle
Mitlawa yi kuma kungu ra matirhelo leri nga riki na nchumu na ku hetisa ntirho wa 2.
Laha nakambe ku se ku khatsiwile ndzima leyi vonakaka.
Tikomiti ta TiwadiTiwadi natona ti na ntirho wa nkoka ku wu tlanga tani hi xinghenelelo exikarhi ka mfumo na vaakindhawu.
u vurile leswaku xibedlhele lexi xi kombisa ku humelela eku antswiseni ka mphakelo wa vukorhokeri byo antswa eka xifundzha xa Kapa-Vupeladyambu.
Meyara Mathabo Leeto wa masipala wa Matjhabeng eFree State u nghenile ehofisini hi Nyenyankulu 2006.
ku hatlisisa ku lulamisa misava na swa vurimi na tipulani to enela eka ku xava misava, masimekelo ya kahle ya vukorhokeri bya nseketelo wa vurimi na nseketelo wa swakudya swa ndyangu, no antswisa xiyimo xa mali no fikelela eka MAFISA ku nyika xikweleti xitsongo eka xiyenge lexi: kuta langutisiwa swinene eka tindhawu leti langutisaka swinene eka vatshami va le mapurasini na lava kumekaka eka tindhawu leti va susiwaka hi xitalo, naswona hi nga engetela van'wamabindzu va vantima eka ntshovelo wa vurimi hi 5% hi lembe, na tinkota eka vun'winyi bya misava swi ta pfuna ku hatlisisa;
Ndzi ta boxa swinharhu ntsena.
Byebyo vutumbuluxo hi lebyi hi faneleke ku vulavula hi byona.
Marito lama ya tama ya fambelana swinene
Mapatu ya kahle, mitirho yo tala
nsiha-ngati wa nhamu
THEKINOLOJI YA XIYIMO XA LE HENHLA
Ndzi kombela leswaku hi va khensa hinkwavo.
Kungu ri ta hetisiwa emakumu ka Mudyaxihi 2011.
Sweswi ku ringeta ku le ku endliweni ku engetela mali ebangini.
Leswi swi nga fikeleleka ntsena hi ku kunguhata wa ha ri nkarhi.
loko Tikomti ta Wadi ti ri vayimeri lava kumaka muholo.
Hikowalaho, nhlamulo ya olova.
Marito yo hetelela.
SIKU RA 1
Hikokwalaho, vatirhelamfumo a va fanelangi ku tumbela hi mafambiselo ya mahungu hi ku landza swiyimo swa le hofisini, kambe va fanele ku vekela tikhasimende emahlweni.
Vatirhi va fanele ku tekiwa vari timpipi.
Ndzi navela ku kombisa nseketelo wa leswi swivulavuri swin'wana swi swi vuleke.
ku nghenisa
Vulavisisi bya maphorisa bya karhi bya endliwa.
Leyi i mhaka ya xibalo xa nxavo.
Sweswi ndzi ta jikela eka mhaka leyi pfuxaka matitwele hi ku kongomisa.
Vaakindhawu va fanele ku byeriwa mayelana na hilaha tindzawulo ta rixaka na ta Xifundzankulu ti fambisiwaka hakona
A hi vulavuleni hi xona.
Ntirho wo aka na moya wo cina.
sisiteme yi fanele ku endliwa leswaku yi va yo olova swinene.
Mhaka hinkwayo yi lahaya: swi le rivaleni.
"(2) Vuthu ra Vusirheleri ra Rixaka ri fanele ku tirhisa matimba ya rona na ku tirha mitirho ya rona ntsena hi ku tirhela rixaka hi ku landza kavanyisa ka 11 ka Vumbiwa ra Riphabliki ra Afrika Dzonga
mikhwazi
A hi twisiseni.
Nkwama lowu a wu tava wu nga tangi hi nkarhi wa kahle.
bence ya vawisisi
vakhanselara va masipala na tiofixiayala leti nga na vutihlamuleri bya ku teka xiave ka vaakindhawu na ku simeka sisiteme ya komiti ya wadi.
leswi swi ta boha ku koteka ka Swifundzankulu na vumundzuku bya swona.
A ku na nawu wa ka mhasipala lowu nga nyikiwaka hi Huvo ya Mhasipala handle ka loko -
netiweke yi vuye yi lulamisiwa.
Vadyondzi va vumaki bya tikhemikali va fanele ku kota ku:
Xin'wana ku nga va 'ntiyiso' naswona xin'wana ku nga va 'xo ehleketeliwa'
Mpendulo na vadyondzikuloni a va fanela ku susa torha ra vona ro hlaya hi ku hlaya tibuku leti a ti hlayiwa exikolweni na ta XiXhosa ntsena.
muzayiki
leswaku hi 2014
Ku vilela hi maendlelo ya swa xinawu ku fanele kuva xiphemu xo angarhela xa ku aleriwa hi nawu.
Nhlengeletano leyi hi yona leyi eka yona ku bohiwaka no hakerisiwa tihakelo ta xikolo.
Ina, xibindzwana xi ta laveka ku hlayisa tirhekodonyana.
yo va erivaleni na ku va na vutihlamuleri
mavoni ya le xitarateni
Ku thoriwa ka vathokoti
teka vuhangeri bya endlelo leri.
nawu lowu a wu si sungula ku tirha.
Ku nyika n'wana wa wena swakudya leswi nyikaka matimba i ndlela ya kahle yo ngetelela timinerali na tivhitamini eka nxaxamelo wa madyelo ya n'wana.
Hi vona leswo hi tlhelo ra timfanelo ta ximunhu.
Hikwalaho ndzi ta vuyelela leswi ndzi nga swi vula hi nkarhi wa kona.
Khomixinara, xana mi ehleketa leswaku sweswo swa twisiseka?
Ku tinyiketela ku tirha tiawara to leha.
Kambe ndza ha vona mitlhontlho leyi yaka emahlweni.
Ndzi ehleketa ku ri jekajekisano lowu wu vile lowu pfunaka swinene.
Nawumbisi wa Timfanelo, xiga xa 24,
Eka siku leri, Puresidente lowuntshwa u ta hlambanyisiwa hi Muavanyisinkulu wa Afrika Dzonga.
Gqweta
Nhluvukiso wa ikhonomi
ndzi vekele nkoka wukulu eka swona.
Risimu ra chela ra leswaku, "tshamiseka kutani mfumo wu ta phakela" ri fanele ku tlhontlhiwa - hi ntiyiso a swi humeleriseki naswona a swi fambisani na sisiteme ya mfumo wa Afrika-Dzonga.
Swi le rivaleni leswaku rimba ra pholisi ra rixaka ri ta pfuna.
pheji ya 10).
timhaka to karhi ta ha tama ti nga ololoxiwangi.
Ku teka vutihlamuleri eka tioditi leti taka ta rimbewu, vantshwa na vutsoniwa.
Sweswo xivandlenenenkulu eka matlhelo hamambirhi.
ku oma hi gwitsi
Mfumu wu kumile ku tlula mamiliyoni ya 320 ya tirhandi ku suka eka vaendli va timhaka hi Nomboro ya Riqingho ya Rixaka yo Lwa na Vukungundwana.
A xi fanelanga ku va tano eka nkarhi lowu taka!
Afrika-Dzonga ri fanele ku tirhisa matimba ya rona ku engetela tinhundzu leti rhumeriwaka ematikweni ya le handle.
Nxavo wa mali i ndlela yo fikelela xikongomelo, kambe a hi xona xikongomelo.
Kambe leswi hi swi endlaka hi leswaku ku tava na ntlimbano lokukulu.
Maendlelo yo humesa vanhu loko ku tshuka ku ve na swibuluki kumbe mindzilo.
Mfumo wa Xikwembu a wu ti hi ndlela yo lava ku voniwa.
Hlamusela xikongomelo
Tumbuluxa nxaxamelo lowu hlanganisiweke wa mivuyelo leyi langiteriweke ya mitlawa hinkwayo ya vanhu, u ri karhi u komba laha mivuyelo leyi yi sukelaka kona.
Hi matlhelo yo tala, Afrika-Dzonga ri na vuakitiko byo gingiriteka na ku va na rito leri twalaka, kambe mbuyelo lowu a wu nga languteriwangi wa swiendlo swa mfumo wu vile wu hunguta mali ya nhlohlotelo eka vaakitiko ku va va va vatekaxiave vo kongoma eka nhluvukiso wa vona vini.
XITATIMENDE HI HOLOBYENKULU ROB DAVIES EKA LEKGOTLA YA KHABINETE LEYI A YI KHOMIWILE HI TI 13-15 MHAWURI 2013
Hi ndlela leyi CBP wu pfuna vamasipala ku nyika ku pfuna ka matimba eka swilaveko swa Mpfapfarhuto na Nawu wa Tisisteme ta Masipala
Hikokwalaho, ndzi kunguhata leswaku hi hundela eka vhoti.
Swiletelo na swipimelo
timuziyamu na tigalari
Kumbexana u ya eka ku rhumela swixavisiwa eka matiko mambe?
mali yo lombisa yo dyondza hi yona kumbe tibasari.
Endla swo tala, kutani.
A ndzi ta kombela u ehleketisisa kahle.
ku langutisisa matirhelo ku ya fananisa na swikombo na swikongomisiwa
i swa nkoka ku antswisa ku tinyiketela ka vatirhela mfumo emintirhweni ya vona - ntirho lowu nga le makatleni ya vurhangeri
ku thola maxaka
Kambela, pima no teka goza leri faneleke eka leswi landzelaka:
Afidavhiti yi fanele ku tiyisa vito ra munhu wa nkata loyi a nga loveriwa na siku ra ku lova.
Tikomiti ta Tiwadi i rimba na mahlanganelo naswona ti fanele ku yimeriwa eka Foramu ya Vayimeri va IDP na le ka ntlawa wa ntirho wa IDP lowu faneleke.
Kambe laha hi laha ndzi sungulaka kona ku va na ku kanakana.
Sweswo ku ta va xihlovo xa matimba ya hina.
A hi lava endlelo ro twanana swinene.
Boha no hlamusela swilaveko sa bindzu.
Masipala wa n'wina u fanele ku nyika vuleteri bya ku tivisa eka swirho hinkwaswo swa komiti ya wadi na ku pfuneta ku lulamisa vuleteri
hi ku tiyimela
hefemuteka
Mimbuyelo yi nyika.
va nga langiwa.
va na mahungu laya nga fanela ya matirhelo mayelana na matirhiselo ya switirhisiwa hi ndlela ya xiikhonomi, ya vuswikoti na hi ndlela leyi pfunaka na hi ku kongomisa mfananiso exikarhi ka swikombiso swa matirhelo swa xiviri tanihi leswi swi andlariweke eka pulani ya bindzu.rcontain relevant performance information regarding the economic, efficient and effective application of resources and specifically a comparison between planned and actual performance indicators as set out in that business plan.
Swiyimo leswi fambelanaka ni nandzu:
Va tlhela va tirha tanihi vanhu lava nyikaka vuxokoxoko hi nkarhi wa vuleteri.
Leswi hikokwalaho u faneleke ku tiehleketelela.
Leswi i swiletelo swa tin'hweti ta tsevu leti taka.
Ndzi langutela ntirhisano wa hina wa nkarhi lowu taka.
Ku na swilo swo tala hi nga swi endlaka ku aka xumankulu xa vanhu.
Mhaka hinkwayo leyikulukumba yi vekiwa emahlweni ka vufambisi.
Landzelela tindlela ta ndzawulo leti tirhisiwaka ku hundzisela nandzu emahlweni loko u nga eneli hi xiboho..
Swi nga tlhela swi yisa eka leswaku n'wana a fa.
lowu tihlamulelaka eka Vaaki hinkwavo va Afrika Dzonga.
Holobye u hlohleterile un'wana na un'wana ku tiyisisa leswaku hi dya hi ndlela ya rihanyu lerinene.
Humesela ehandle swilo leswi ku vilerisaka emugangeni wa wena.
Ntirho wa IDP, hikuva wu ri xiphemu xa migingiriko 3 / 1 na 3 / 3 ku ya fika eka 3 / 9 wu tiyisisa leswaku vayimeri lava faneleke va tiwadi va teka xiave eka nkunguhato wa phurojeke ya IDP.
hi ku landza Mavitanele
nyika mpfuneto wa maqhingha eku hleleni ni ku ehleketisisa ka vuhaxi byo tsariwa ni bya xielekithiraniki leswaku byi tatisa eka tirhelo ra mbulavulo wa mfumo ra le henhla naswona ro famba hi nkarhi
Nghenisa thanki
italy
Mathikithi ya galari ya vaaki yo nghena eka ntshamo wa Palamende
Hikokwalaho, eku endleni, mbuyelo wa fana hakunenenene.
Ndzima yo karhi a yi khatsiwile eka mhaka leyi na yona.
u va mutshami wa nkarhi hinkwavo wa Afrika-Dzonga
Feyisi yo sungula ya vuleteri yi fanele ku kongomisa eka swiphemu swa nkoka mavevukiselo na ku letela swikili.
Kambe a hi se endla ku humelela ko hlaya eka sweswo hambiswona.
tihakelelo ta vutleketli
A ku na nhlamulo yo olova ya xivutiso xexo.
Sweswo i khombo leri hi nga eku vileleni hi mayelana na rona.
Ndzi na xiphiqo.
Kambe, nkarhi na nkarhi nakambe, tinguva ti hi hlanganisile tanihi vanakulobye va maqhinga.
Ndzi tsakela ku khensa valulamisi kuva va tekile goza leri.
nkampfunya
Hikokwalaho, hi fanele ku angula.
Ndzi kongomisa, hakunene, eka tihuvo to kambela.
u fanele u teka xiboho xa ku ya hlambanya
Sweswi, xileriso xi tsariwile.
Yaleyo i ndlela yo antswa ku fikelela vutshembeki bya misava hinkwayo.
Ku langutaniwa na xikombelo hi rona siku relero, kambe mali yi vuyisiwa endzhaku ka masikunyana hikokwalaho ka fambiselo ra vulavisisi na nkambelo wa le ndzeni.
Leyi i yin'we ya tiphurojeke ta nkoka ta ku susa matlhari.
Sweswo i masungulo
Hi ta tlhela hi tirha swin'we na Ndzawulo ya Vulanguteri ya Matirhelo na Nkambelo ku veka tihlo eka masimekelo a kungu leri.
Hi fanele ku vekisa eka rihanyu, dyondzo na vuleteri.
Ndza tshemba leswaku leswi swi kahle swinene.
Hi vuenti, tidyondzo eka swivangelo leswi hoxaka xandla eka mimbuyelo leyi nga riki kahle exikolweni eAfrika-Dzonga swi vula leswaku vadyondzisi va na nkarhi wutsongo lowu va vaka kun'we na vadyondzi, va na vutivi lebyi ringanangiki bya dyondzonkulu na ku pfumala vuswikoti byo dyondzisa swa nkoka, ngopfungopfu eka tidyondzo to fana na tindzimi, sayense na metse.
Swi humelele ehenhla ka nkarhi wo leha swinene
Ntsengo wa vukorhokeri bya mphakelo wa gezi wu ta tlakuka.
khasete ya vhidiyo
A hi voneni leswi nga ta humelela eka nkarhi lowu taka.
Ku lulamisa masungulo
hi ndlela yoleyo mivuyelo ya lembe ra vu2 ku ta va xilaveko xo kota ku hundzela eka lembe ra vunharhu.
Xirhambo xa Maphepha: Ntirho wa tindzimi ta Xintima eka dyondzo edzongeni wa Afrika: Buku yo hlawuleka ya Southern African Linguistics and Applied Language Studies (Vholomu ya 30, Nomboro ya 4, 2012).
Milawu yo tika ya tilayisense ta swibhamu yi antswise ku lawuriwa ka swibhamu.
Ndzi teka sweswo tanihi maendlelo lama kanakanisaka swinene.
Layisense leyi yi tirha tin'hweti ta ntsevu na swona yi nyiketiwa eka senthara yin'wana na yin'wana ya nkambelo wa vuchayeri.
vuviri
2. Kun'we na ntlawa wa wena endlani swirhangana swa phurojeke
Vululamisi lebyi hetisekeke byi fanele ku endliwa ku tiyisisa leswaku ntirho wa nkunguhato wu famba kahle, ku tlhela ku va ni mivuyelo ni swifikelelo swi xiyimo xa le henhla swa vusimeki.
Xikombiso: Masipala wa Xifundzatsongo xa Cacadu wu tibohile ku edla matshalatshala lama landzelaka ku tirhana na HIV / AIDS:
Lowu a hi wona nawu lowu ndzi nga wu seketelaka.
A ndzi kali ndza ha lava jekajekisano wun'wana.
Ku ta va ku ri ku tlanga hi nkarhi.
1. Kuma no tata Fomo ya Z83 eka inthanete (Xikombelo xa ku Thoriwa).
kwolomu ka kambirhi hi lembe, rhamba nhlengeletano exikarhi ka swiyenge swa mfumo leswi nga na ku tsakela eka mhaka yihi na yihi leyi yelanaka na mitirho ya swa ririmi; at least twice a year, convene meetings between organs of state that have an interest in any matter related to the language industry;
Swoleswo i swilo swinharhu leswi hi faneleke ku va na swona.
Phepha ra xikambelo ro tsariwa ri nga katsa leswi landzelaka:
ntirho wa ntshamo
A ndzi ta tsakela ku tiva.
Hinkwerhu hi na swiphiqo leswi swi hi faneleke.
ndlopfu
sangu ra khoya
Kutani ndza tivutisa leswaku nkoka wa xiboho a ku ri wihi.
Leyi i mhaka ya SAPS, vaahluri na tikhotso.
Vulemuki bya vutihlamuleri i bya nkoka swonghasi eka endlelo ra ndzivalelano.
Hambiswiritano, ndza mi langutela ku swi vula xikan'wekan'we.
Walowo i muxaka wa nchumu lowu hi faneleke ku tivonela eka wona.
Nawumbisi wu langutane na ku tiyisa tshaku ra Vulawuri bya Swikweleti swa Rixaka ku ololoxa swiphiqo swin'wana ngopfu ngopfu exikarhi ka maendlele ya khoto no tiyisisa tirhisele na tirhele eka leswi Nawu wa vu 34 wa Swikweleti wa Rixaka wa 2005.
Ku hunguta ku dya munyu swi ta herisa ku hisa ka ngati
Swi nga teka masiku ya nkombo ku languta no kuma vutivi.
Vuswikoti byo vulavula hi timbirhi ta tindzimi tinharhu ta ximfumo ta Western Cape.
journal ya dyondzo ya vantima
Mfumo lowu wu na mboyamelatlhelo eka vana, vantshwa, vavasati na vakulukumba.
muhlapfa
Mipimo ya mikarhi yo vutisetela mitlawa ya vaakindhawu
Hi ta kota ku dyondza ku suka eka ntokoto wa wena
NKARHI LOWU VEKIWEKE - leswaku hinkwavo vaakitiko na vatirhi va tiva leswaku swi languteriwe rini ku nyika vukorhokeri
Hi ta ya emahlweni hi veka tihlo swinene xiyimo.
Magoza lama ma nga ta tekiwa eka ku hlayisa tinso ta wena na ku va ti tirha kahle:
naswona wu nga ha alela mphakelo wa mati ku ya eka mphakelo wa zoni hi vutalo byo ka byi nga ri ehansi ka mphakelo wa mati ya masungulo hi ku ya hi nomboro ya mindyangu.
Lowu i njhekanjhekisano wo hambana ehenhla ka mhaka yo hambana.
Ha ha yimele antswiso eka tifanelo ta ximunhu.
a ku na munhu loyi a ya ka eka xiendleko a ri na xikongomelo xo kala a nga tiphini.
Ku tsala xiviko xo hetelela xa kungu ra phurojeke
Ku tilawula a swi enelanga.
Ndzi ehleketa leswaku leswi i swa nkoka swinene.
Lowu i nawu lowu simekiweke ka matlhelo mimbirhi.
NPPPO yi ta humesa xitifikheti xa swiyimo swa timhaka ta vurimi.
Tikomiti ta tiwadi ti nga nghenelela hi ndlela yihi eka tiKNP?
A ndzi ta tsakela ku kongomisa miehleketo eka swibumabumelo swa mina ehenhla ka fole.
Ndzi teka dyondzi ya swa timali ku va nhlokomhaka ya nkoka swinene.
vaakindhawu
ndzaho wa le kule
Swi le kule ngopfu switsongo.
Van'wana va vona i swirho swa mitlawa leyitsongo.
Vulavisisi byo maketa na switsundzuxo swa nawu.
Huvo ya Tinhlayo-nhlayo na hi ku angarhela komititsongo hi vanhu na tinhlayonhlayo ta vanhu eka vuleteri bya vona byo yisa emahlweni na nseketelo
Hi va navelela ku humelela eku tlangeleni ka vona.
Xikombelo xa ku vika nghozi ya le ntirhweni eka va Compensation Fund
Nkarhi wa matimu ya nkoka wu vile kona hi 2001 loko ku tumbuluka xivono xa Khomixini ya e-Afrika.
"Vuthu ra Vusirheleri ra Rixaka ri fanele ku tirhisa matimba ya rona na ku tirha mitirho ya rona ntsena hi ku tirhela rixaka hi ku landza kavanyisa ka 11 ka Vumbiwa ra Riphabliki ra Afrika Dzonga, 1996."
ya mbango lowu nga onhiki rihanyo ra vona kumbe ku hlayiseka; no
mukomberi u fanele a hakela hakelo leyi lavekaka.
Europe ri fanele ku vuyela ematshan'weni eka mhaka leyi.
Hoyohoyo eka hinkwenu.
Eka nkarhi wolowu, Presidente u vulavula ni rixaka tanihi Mufambisi wa Tiko ku nga ri tanihi Mufambisi wa Mfumo.
hi nkarhi lowu faneleke na le ka ndhawu leyi faneleke.
-rhanga-mahlweni
Ntirho lowu u wu hlawuleke ku wu endla i wa nkoka eka vumundzuku bya ximunhu.
Tikomiti ta TiwadiTiwadi ti tirha ntirho wo seketela vakhanselara ku tivisa vaakindhawu.
Xexo xi nga ka xi nga tshemberiwa eka xona, hambiswiritano.
xa ku swi veka erivaleni kahle ta ha suka ehansi leswaku i mani loyi a tekaka xiboho xo hetelela
Leswi hi nga ku endleni ka swona i ku swi teka hi swi yisa eka xikalo lexikulu.
Mi fanele ku tihlanganisa na hofisi ya Xipikara eka masipala wa ka n'wina ku va mi tiva mayelana na swilaveko swa mavikelo
Ndzi rhandza ku khensa ku va mi tekile nkarhi wo hlaya papila leri, no mi khensa ku va mi ta nghenelela eka mbhurisano no hangalasa ntshikileleo wa vuvabyi.
Ya tirha tanihi valangutisisi va swikongomiwa leswi endliweke, na ku nyika vuxokoxoko bya leswi nga languteriwa eka komiti na leswaku swi nga fikeleriwa njhani.
Sweswi, endzhaku ka 15 wa malembe?
Vito ra akhawunti: NDA-ACT36 of 1947
xiviko lexi a va ri na xona xi kumekile hi ku yiviwa.
I ta misava hinkwayo, tanihiloko vanhu hinkwavo kun'wana na kun'wana laha va kumekaka kona laha misaveni; va lulameriwile hi ku khomiwa hi ndlela leyi nga na xindzhuti na nhlonipho.
A hi sunguleni ku tirha, swin'we.
I vunyingi
Leswi swihangalasamahungu swi yisisaka xiswona emahlweni swifaniso swa vavasati.
Ndhawu
2001 ya fambisana na Nawu wa Swiakiwa swa Masipala
Ku va tihakelo ta manyala ti langutiwa eka nkucetelo lowu wutsongo swi endla leswaku ku lwisana na manyala swi tika swinene.
Eka lembeximali leri:
Ndzi nga swi endlisa ku yini?
sisiteme ya moya wa ntshikelelo-henhla
Leswi swi vonaka swinene eka xinawana lexi nga emahlweni ka hina.
Hi ndlela leyi kotekaka.
Naswona swi ya emahlweni
Nkayakayo lowu wa swa ikhonomi wu kona laha.
Ti-instithuxini ta misava - Afrika Dzonga yi hoxe xandla eka ku hundzuluxiwa ku suka eka Organisation of African Unity ku ya eka African Union, yi rhurhela Pan African Parliament na ku pfuna ku fambisa Huvo yak u Rhula na Vusirheleli ya AU.
Mhaka ya mina yo hetelela i ku kombisa leswi ndzi hlamarisaka.
Hinkwerhu hi na ntirho wo lulamisa leswi.
switsalo ni swo tsalela...)
ntivo-vukorhoki
2. Bula hi ta switandzhaku swa Komiti ya Wadi leyi nga landzeleriki Batho Pele eka masipala
Holobyenkulu u ta yisa xiviko loko ntirho wu ri karhi wu famba leswaku Khabinete yi teka xiboho.
Leti i tindlela hinkwato leti nga endliwaka.
Ndzi ta tsakela ku khensa muteki wa mahungu eka xiviko xa yena.
Xa nkoka ngopfu eka vupulani i swilaveko swa vundzeni leswi landzelaka:
Ndzi ehleketa leswaku hi fanele ku veka masungulo ya mpimanyeto.
hi amukela vonelo leri.
Namuntlha hi ku yimela mfumo ndzi ri hi mi twile.
Kambe swi va swa nkarhi wutsongo.
Tiyisisa leswaku switshembiso leswi hi swi endlaka ka vanhu va hina hi leswi hi nga ta swi humelerisa.
NSIRHELELO WA TIMFANELO TA XIMUNHU
Tiwadi ti endla mpfuxeto - vavevukisi
na vuseketeri lebyi lavekaka na matirhiselo ya mali leyi tirhisiwaka hi mavonelo lamanene yi averiwa wadi.
I xihlawuhlawu xo ka xi nga amukeleki exikarhi ka mavandla lamambirhi.
-nomo wa nambu elwandle
eka databeyisi leyi langutisiweke eka ndzimana ya, ndzawulo yi fanele ku katsa, mahungu lawa ya hlengeletiweke na ku longoloxiwa tanihilaha swi nga lulamuseriwa hakona eka ndzimana yoleyo, na data mayelana na vanhu lava .kelelaka tanihi khale-ka-masocha kumbe vahlayisiwa;
Vutalo bya kungu leri byi tirhana na mipfuxeto ya mihlangano leswi swi lavekaka ku hlula ku tsana eka sekitara ya mfumo
swivilelo
Makungu ya leswi a swi ta endliwa ya le tafuleni.
6. Nawu wa Tisisiteme ta Masipala wu tlakusa nhlangano exikarhi ka swiyenge hinkwaswo leswinharhu swa mfumo
xivandla hinkwaxo xa yuro xi le ka nxungeto.
ku katsa na vuleteri bya masungulo ya tindlela to endla mbalango
Vaendli va swikombelo va fanele ku nyiketa vumbhoni bya ku nghenela ka vona eka tiprojeke timbirhi kumbe ku tlula.
wa le tlhelo ka Eskom Holdings.
Ehansi ka xiyengentsongo (2), (3) na (4), mhasipala a nga ha veka -
Sweswo swi hi tisa emakumu ka nhlengeletano wa swa mahungu.
Ku thola, ku tlakusa, ku rhurhisa na ku herisa
Ku seketela tikomiti ta tiwadi hi ku vona leswaku vanhu va tekaxiave
Nkarhi lowu lavekaka wa ku hetisa hi ndlela leyi vuyerisaka minongonoko na mapfhumba lama sunguriweke eka levhele ya wadi.
Nhlengeletano ya masiku mambirhi leyi a yi rhurheriwile hi Afrika-Dzonga hi Mawuwani
swiphemu swa nomo
Ndzi ta sungula hi mpimanyeto na xivumbeko xa mapimanyetelo.
Ku humelerisa leswi, xipano xa ntirho lexi vumbiwaka vakhomaxiave vo hambanahambana xi tumbuluxiwile.
Hi twa leswaku ntirho wo yisa emahlweni wu fanele wu endliwa eka ndhawu yoleyo.
Leswi hi leswi u kunguhataka ku swi endla.
Vuxokoxoko bya dyondzo byi namarhetiwile laha hansi.
d) Dokodela Malcolm Barry Kistnasamy (Ndzawulo ya Rihanyu)
Langutisa swivangelo leswi faneleke ku tekeriwa enhlokweni eka vulavisisi.
Hi ku vona ka hina, leswi a swi tiyiseleki naswitsongo.
Tinhlamulo ti ta engeterwa eka ku hlaya.
Ndzi ya kona sweswi
A swi endleki ku va na dyondzo yo hatlisa.
Swifundzankulu swi na swiphiqo swa timali, ngopfungopfu ndzawulo ya rihanyu.
xihanya-matini na le handle
Eka phurosese leyi, xana a wu swi lemukile leswaku tikhonsepe leti ti vula yini ke?
Switandzhaku leswi salaka i tilevhele ta le henhla ta ku pfumaleka ka mitirho na ku nga ringani eka swa vuvekisi.
Xiphemu xa 1: Malulamiselo na Nkucetelo wa lava nga na xiave
Ka ha pfumaleka vanyingi.
A ndzi xi vhotelanga.
ntsengo wa makete wa nhundzu;
ndzi pfumeleleni ndzi endla nxiyaxiyo wun'we wo hetelela.
Hikokwalaho ka yini hi nga lavi ku swi tirhisa?
khona ya Switarata swa Vermeulen na Van der Walt
Xifaniso xi le rivaleni.
Vakhanselara va wadi va fanele ku langutisisa endlelo eka nhlengeletano yo sungula ya Komiti ya Wadi vona
hi xibumabumelo xa Palamende ya Rixaka
A ndzi ta rhandza naswona ku ku vula swo angarhela swingari swingani.
Tsala nkarhi lowu nhlengeletano yi sungulaka hi wona.
Lowu i ntirho wa 2002.
Tiko rin'we a ri nge pfumeleriwi ku kavanyeta nhlangano wa matiko lama nga xaviselanaka ku ri hava masiku.
Ku na leswi nga vuyerisaka hi ntirhisano endhawini leyi.
Ku vona leswaku Mufambisi wa ka Masipala na N'waDoroba/Meyara va ni vutivi bya timhaka leti ti humaka hi le ka timhaka / tiphurojeke ta nhlangano wa CBP na IDP
Tiva leswaku misava yi na ndlala ra swiendlo
i xiphiqo.
Tiawara ta 2.5
U tsakile leswi a nga kota ku phuntisa boso ya yena.
Xana I yini mhaka ya sweswo?
A swi ta antswa loko a hi tirhile hikwalaho ka nseketelano.
Hi tindlela to hamabanahambana, mitshunxeko yi khumba vutomi bya hina, ku suka eka matlhelo yo hambana.
ka mbirhi.
na ku tshamela ku langutisisa na ku pima.
U komberile ntirhisano wo tiya wa tipholisi ta ikhonomi.
Khabinete yi ya emahlweni yi kombela swiyenge swa mifumo ku hatlisa swi lulamisa timhaka hi ndlela leyi va tirhisaka Vumbiwa ra hina.
Hlanganisa minghingiriko ya nsivelo wa vugevenga.
Kahlekahle hi ndlela leyi kanetanaka na swona
Ku na mitlhontlho yo tala leyi hi langutanaka na yona leyi hi faneleke ku yi vulavula eka nhlengeletano leyi.
Hi langutela ku vona leswi swi humelela.
ha mi tlangerisa!
a hi vavhumbi.
Tinhlayo ta vona ti lawuriwa ku ya hi swilaveko na swiyimo swa xifundza xin'wana na xin'wana.
Xikombiso, Chayina ra hi dinga laha mbango wu vilelaka kona.
hi fanele ku seketela mabindzu ya xiyimo lexitsongo na xa le xikarhi.
Loko va karhi va nwa ayoni
Hikokwalaho i nkarhi wa ku sungula ku hi yingisela.
Hi na ntokoto.
Matirhelo ya vukanganyisi ya vula ku hangalaka ka moya wa matirhele lawa ya nga talela hi vuxisi na ku xavisiwa ka mitirho.
muxaka wolowo wa xiviko a wu nge tirhi.
Muako wa Huvo ya Rixaka ya Swifundzhankulu
matala
Swilo sweswo swimbirhi swi nga famba swin'we.
Mahungu ya phurojeke ya IDP lama fanelaka ya fanele ku olovisiwa ni ku kongoma swinene, ya hlamusela swilo swo fana ni vito ra phurojeke, xikongomelo ni ndhawu.
Ntumbuluko wa wona wo katsana wu katsa swiyenge hinkwaswo swa vuhlayiseki.
Ku tsandzeka ka vuhlanganisi, vutihlamuleri lebyi hambanisiweke na matimba lama khapelaka eka tlhelo lerin'wana swi kavanyeta masimekelo ya tipholisi leti nga kona.
Kumbe i vanhu lava hi va tivaka.
switatimente swa timali eka muako wa ECD
Vavhoti.
Ndzi twisisa leswaku hi le ku tirhaneni ni mimfuwo yo hambana.
eFristata
Laha hi vulavula hi mayelana na ku lulamisiwa ka makete.
Mbuyelo hambiswiritano i wa nkoka swinene.
Bindzu na Mbango
xinyenyetsi
Leswi swi pfumelela Nkwama wa Rixaka ku phalala laha masipala wu langutisaneke na xiyimo xa xihatla xa swa timali
Ntirho wu endliwile eka swiyenge swimbirhi:
musweki
tiko leri ndzi nga ri tekela
ligi yo sungula
madyelo yo rimiwa
Kambe lahaya
ya endhawini ya n'winyi ku landza nchumu wolowo
Sweswo ko va ku nga ri ndlela yona ya ku hundzela emahlweni.
Loko mupfuneti wa khoto ya vana a nyiketa nothisi ya ku yimisa xileriso
nakambe nkhensa hinkwenu ka n'wina.
Ku hambana eka mikanerisano eka swa vurimi yi ya emahlweni.
Naswona ndzi lava ku vulavula hi mhaka ya ku va swipimelo swi nga tirhisiwi kun'wana.
Vutivi byi ta tiyisiwa hi nkarhi walowo wa ha yimile.
Tanihi mhaka ya timhaka ta ntiyiso, yaleyo a hi mhaka.
Laha hilaha kereke yi talaka ku nghenelela.
Leswi swi le henhla ku suka eka nharhu kumbe mune wa leswi a swi tirhiwa hi 2000.
Ndzi tile ku ta vona Maputo tani hi kaya ra vumbirhi.
Manana Mutshama-xitulu
Swi nga va
Eka tipolitiki, tin'hweti ta tsevu ku nga va nkarhi wo leha swinene!
Switirhisiwa swa vadyondzisi swi nga katsa:
A va nge ringaneli hakunene.
Se ndzi ta hundzulukela eka vulanguteri bya swa timali.
Ku na vuxokoxoko lebyi byi nga erivaleni bya leswaku NHI yi ta tirha njhani.
ku nga ri ntsena eka mfumo wa miganga
ntsheketo
 Humesa eneji yo enela ku seketela indasitiri eka mixavo ya le hansi ku tlula yin'wana
Eka leswi hi dinga endlelo leri humelelaka hi ndlela yo fana mikarhi hinkwayo.
Xa vumune, hi fanele ku tiyisa n'wangulano eka timfanelo ta ximunhu.
Xana phurojeke yi ta tumbuluxarifuwo, leri nga ta vuyerisa vaakindhawu nkarhi wo leha (xik. gondzo, damu, soreji)?
Xikongomiwa / mbuyelo
Kambe lahaya ku ta fanela ku va ni nkatekonyana.
Ndlandlamuko na nhluvukiso swi tlula swinene kuva swi tshembela eka lexin'wana.
wo ndzi tatisa
Doha yi ta humelela.
Tikomiti ta Tiwadi ti na mfanelo ya ku vutisa swivutiso na ku endla swibumabumelo eka huvo hi tindlela to antswa ku vanga (endla) mali, ku hunguta tihakelo, ku sivela vukungundwana na ku sirhelela tinhundzu ta masipala.
nyimpi a kuri mhaka ya ntiyiso.
hi fanele ku tsema mphakelo
ku kufumela
ra xidimokiresi leri humelelaka.
Hi ku ya hi nkongomelo wa hina wa lembe leri nga hundza
Swi veke eka xiyenge lexi nga riki xa mfumo
BOKISI LERI RI TATISIWA EMAKUMU KA NGUVA YA MATIRHELO xikombiso xa kona ku nga va:
Hi rixaka rintshwa.
Hi vumbirhi vanhu na tikhamphani va vuyeriwile ku suka eka ku hungutiwa ka xibalo eka malembe matsongo laya hundzeke.
xi-ala mati
Xana nongonoko wu tirhisile hi ku hetiseka vuswikoti byo karhi na ntokoto wa vamanana na vatatana?
Leswi swi ta katsa mindyangu leyi nga vuswetini ngopfu eka swifundzankulu hinkwaswo.
Hi dinga un'wana na un'wana - vanhu hi hinkwavo.
va ta langutana mixupulo yo tika swinene.
Eka ku endla kungu ra lembe mi nga tekela leswi landzelaka enhlokweni:
Vulavisisi lebyi bya karhi bya ya emahlweni
Kahlekahle hi vile na swiviko swimbirhi eka nhlokomhaka ya kona.
vuhundzuluxi bya Xinghezi-Xijarimani
Komiti ya Wadi -
Ina -khanselara wa wadi a nga kombela khanselara wa VR
Sisiteme ya ku lemukisa nghozi hi xihatla swinene yi fanele ku tshama yi ri xitirho xa tipolotiki.
Ndzi ehleketa ku ri a hi fanele ku tlhela hi langutisa eka vito.
milawu ya ntlangu
Loko Khomixini yi enerisekile
Eka leswi hinkwaswo
mi fanele ku wu tsala ehansi mi tlhela mi wu sayina.
Hambiswiritano, eka leswi hi fanele ku engetela ku yisa emahlweni ntirhisano wa swa swifundzha.
marhumelele
epifisisi
Van'wana va vaendli va tipholisi va paluxile ku khumbeka ka vona ka leswaku timasipala ti landzelerile maendlelo yo hambana loko ti tumbuluxa tisisiteme ta komiti ya wadi.
I xikombiso xin'we lexo.
Ku pfuneta hi ku lulamisela nkunguhato wa tiwadi na tikomiti ta tiwadi;
Ha vilerisiwa hi madzolonga na ku dlayana eKenya na Chad, leswi vuyerisaka endzhaku ndzima leyi hi yi endleke eka malembe mangari-mangani mayelana na ku pfuxa tiko nkulu ra Afrika.
Sweswi, a hi languteni eka swirhendzewutana leswi nga na le xikarhi loku a ku nga ri kona ekusunguleni.
Eka xivangelo xexo xi ri xoxe, hi nge pfumeleli ku tsandzeka kun'wana.
Xana i ku fikela rini hi nga ta amukela leswi?
Xana hi yihi mitirho ya Vuyimeri byo Hambanahambana?
Leswi hi leswi hi fanelaka ku ringeta ku swi fikelela.
Xana phurojeke yi ta katsa miehleketo, vutivi na swiringanyeto leswi humaka eka vamanana na vatatana?
Swo fana swa tirha eka ntirhisano na valawuri eka matiko lama sweleke.
Xihlovo xi ri xoxe xa muholo.
Swipimelo eka migingiriko ya madyondziselo na mahlelelo.
Hi se hi vile ni ku humelela loku khomekaka matlhelo hinkwawo.
Ndzi tshemba leswaku ka ha ri na ku hundzuka loku faneleke ku endliwa.
Swikongomelo hi ku landzelela ntikelo wa swifikeleriwa
hi fanele ku vulavurisana swin'we.
A hi si fika eka mhaka yoleyo sweswi eka levhele ya misava.
U na mfanelo yo dyondzisiwa hi ririmi ra ximfumo kumbe tindzimi leti u titsakelaka eka vandla ra dyondzo ra mfumo.
Leswi na swona i ku humelela ka hina.
mati na swakudya
Hi le ku fikeni emakumu ka ku hela ka vhiki loko leha.
Leswi hi tirhanaka na swona la i endlelo ro amukela.
ku hlanganisiwa na n'we.
Naswona hakunene ndza xi twisisa xihatla lexi nga eka mhaka leyi.
Vaendli va tipulani Adam Kalkin, Sean Wall na Mia Anfield va akile muako hi ku tirhisa tikhontheyinara to pfuxiwa hivuntshwa ta 28 leti nga na tiphanele ta sola leswaku ti hunguta ku durha ka muako na ku wu hlayisa.
Vatirhi a va tsakeli ku pfumela leswaku va na swiphiqo swa rihanyo hikuva va chavela mitirho ya vona kumbe nchavo lowu fambelanaka na mavabyi yo karhi.
Bindzunyingi leri nga tirhiki
 Ku engetela tinhundzu leti rhumeriwaka ematikomambe, ku ri karhi ku kongomisiwa eka tindhawu laha Afrika-Dzonga leti se ri nga na vuvekisi bya nkarhi wo leha kona na xiyimonene xo yelanisa, xo tanihi migodi, vumaki, vumaki lebyi lavaka swikili swa le xikarhi, vurimi na ku phurosesa swirimiwa, dyondzo ya le henhla, vupfhumba na vukorhokeri bya mabindzu.
vanhu
Lavisisa mitirho ua swiyenge swa timali na minkoka ya swona.
loko mitirho yi tshama yi ri swin'wana na swin'wana a yi nga humeleli.
Xana i magoza wahi lawa ya tekiwaka ku tirhana na mhaka leyi?
Xa vumbirhi, ndzi ehleketa leswaku mhaka ya nkoka eka xivutiso xo hetelela, i yini leswi nga ta nyanyula ku cinca.
Mavovelo manganimangani, xo sungula eka ku pima xiphiqo.
Tanihi Afrika-Dzonga leri tshunxekeke ra xidimokirasi namuntlha, hi nge bakanyeli etlhelo ku lulamisa leswi humeleleke nkarhi lowu nga hundza.
Tikhoso ta mafambiselo na vulawuri;
Leswi swa ringana na mpimanyeto wa xifundzankulu xahina hinkwaxo.
Leswi entiyisweni ku fanele ku ri xin'we xa switandzhaku.
Kambe i yini ku Avelana Nhluvukiso na ku Hluvukisa?
I vutirhisani lebyi nga na nkoka emisaveni hinkwayo
Kavanyisa loku ku nyika rimba leri ha rona ku va ka na nkunguhato lowu simekiweke eka vaakindhawu.
vukorhokeri bya swa vutomi, tisisiteme ta ku seketela vana, tisenthara ta vamanana, na tindhawu tin'wana ta vuhlayiseki ti ta kuma nyingiso
Mina, a ndzi tshembi
Vachaviseki swirho swa yindlu leyi
Vutomi byi cincile.
Mifumo a yi humesi sweswo.
Ndzi va tlhontlhile leswaku hikwalaho ka yini va nga ri eku gangiseni hi ndlela leyi vonakaka swinene?
Ndzi pfune ndzi va ni miehleketo leyi pfulekeke.
Xikombelo xa ku humesiwa ka xitifiketi xa ku tiyisa leswaku swimila a swi na vuvabyi hi xikongomelo xa ku rhumela swimila ehandle ka tiko
Tirhisa khodi ya nxaxamelo leyi hlamuseriweke.
Ndhawu:
tumbuluxa mbango
Nkarhi lowu ringanyetiweke wa migingiriko ya Kavanyisa ka Nharhu
Ndzi ndhundhuzela ntirho lowu endliweke hi muviki.
Hlawula michini leyi nga hava pongo kumbe tindlela loko u hlawula maendlelo mantshwa kumbe michini yintshwa
U hetile!
xipikiri xa khudzu
Hi na Xipikara na Meyara.
Eku heteleleni vanhu vantima va vumba nhlayo ya le henhla etikweni.
ku pfuna na vuswikoti byo endla swibalo, mindzavo na swibalo swa nhundzu; na
ku simeka na varhumiwa lava nga ta endla ntirho;
I masungulo, kambe a hi mahetelelo.
Leswi i ku khomisiwa tingana lokukulu, ngopfungopfu eka vatirhisi.
Palamende ya xifundzha na Huvo ya Rixaka ya Swifundzhankulu,
Hambi ku humelela yini na yini, xiphiqonkulu i nkoteko wa ku vona ku swa landzeleriwa.
Nhlayiso wa ndzinganiso, mbuyelo na nhlayiso wa switirhisiwa.
Presidente wa Khotoya Vumbiwa
Xiyenge xa 16 xa Mfumo wa Miganga: Nawu wa Tisisiteme ta Masipala, 2000 wu vula leswaku:
Swivandla haswimbirhi i swa nkoka eka ikhonomi ya hina.
Kumisisa vubihi lebyi fambelanaka na mabindzu yo karhi.
dazeni ya khume-nharhu
Kan'we nakambe, lexi xi na nkoka ngopfungopfu eka matiko lamatsongo.
Mfumo a wu hlamarisiwanga hi ku hlaseriwa loku.
fenseriwile no funghiwa ti vonaka ku sivela ku wa?
Vuhundzuluxi bya Xitsonga: Maurice Hlangwani
Mutshamaxitulu wa SALGA na vurhangeri hinkwabyo bya mfumo;
A ndzi ta tsakela ku tisa njhekanjhekisano wo engetela.
ndlela leyi ku vhota swi faneleke ku fambisisiwa xiswona.
Muchuchisi a nga ha kombela leswaku mumangari a ririsiwa loko a vile ni ku lahlekeriwa ko karhi hikokwalaho ka vugevenga lebyi.
Swoleswo a swi vuli leswaku vutomi bya olova endzhaku ka ndlandlamuxo.
Ndhurho wa ku lombe ka le henhlanyana, hambiswiritano, i kutlakuka ka mali leyi tirhisiwaka eka ntswalo.
Ku hoxa xandla ka vaakindhawu ku fanela ku fikelela swilaveko leswi nga veketeriwa eka Nawu wa Tisisteme ta Masipala, 2000 na Nawu wa Swimakiwa swa Masipala, 1998.
Xana va angula eka swa rimbewu xana?
a ndzi pfumeleli sweswo ku ndzi heta matimba.
A swi famba na ndhwalo wa vufambisi.
Sweswo hakunene hi leswi a hi ri eku swi endleni sweswi.
hi ku landzelelana
Xiviko xo hetelela xa muphakeri xi fanele xi katsa:
Hi ta fikelela ndzingano.
Vutiyimiseri na Nxiximo
Va tinyiketerile ku aka ntirhisano ni vaakitiko lowu katsaka:
ntshuko
Hi mavonelo ya hina, xiyimo lexi xa timhaka xi nga ka xi nga yi emahlweni hi laha ku nga heriki.
Sweswo swi tlhela swi va na nkoka swonghasi eka nsirhelelo wa mphakelo.
The Translation Automation Users Society na Centre for Next Generation Localisation va hangalasile xikatsa xa swiletelo swa tikhasimende na vaphakeri va vukorhokeri na indasitiri ya swa vuhundzuluxi lava va tokotaka xivandla xintshwa xa le ndzhaku va vuhleri bya vuhundzuluxi bya muchini.
Hi fanele ku sungula ku tirhisa gezi leri pfuxetiweke.
swilawuri swi fanele ku tiyisiwa.
i swa nkoka leswaku mpimo wa ku kala vukorhokeri wu kaleka.
Xiyelaniso!
Sweswo a hileswi xitoloveto hinkwaxo xi nga hi mayelana na swona hinkwaswo.
Hikokwalaho i ncini lexi hi faneleke ku n'wi vitana xona ke?
Swi le rivaleni, hi avelana vonelo rolero.
Kambe xana vumundzuku byi ta va njhani?
Leyi i mhaka ya nkoka ya xiviko xa hina.
Hi swona swi endlaka leswaku hi fanele sweswi hi ri karhi hi koxa ku humelerisiwa ka xidemokirasi eka mindzilakana hinkwayo.
Ina se swi lulamile
Ndzi vile
Xavumbirhi, ku hlayisa vukona bya vamanana eka tikomiti ta tikhamphani.
Xiviko xi ta yisiwa eka Khabinete ku nga ri khale.
O nge a nga vulavuli na mina.
Leswi swi katsa swiyenge swa makunguhatelo
ya mapfhumba lama ma nga endleriwa xiyenge xo karhi eka swiambalo
tanihileswi hi ku ya hi nawu
Exineneni i Norham.
Swivangelo swa ku va masipala wu hlawula ntila lowu hileswaku va masipala van'wana, mihlangano kumbe tikhamphani to tiyimela ti nga va na switirhisiwa swo antswa na mafambiselo ya swikili ku phakela vukorhokeri.
A ndzi lava ku vula swin'wana.
Vatirhela mfumo va nge ngheneleli ku mpfhapfharhuta tsalwa ra holobye kumbe xirho xa huvo yo endla milawu leri a lavaka ku ri tirhisa eka vandla ra tipolotiki.
Ndzi seketela swi helela xikombelo xa xiletelo xo angarhela
Swi kombisiwile leswaku minkumbetelo a yi nga ri na ntiyiso.
ku fana ni ku amukela mudende.
Ku rhekhoda migingiriko yo dyondza swi ta teka xivumbeko xihi na xihi xin'we eka swo tala:
Hi se hi swi twile mayelana ni swikombiso swa tipolotiki.
ku ndlandlamuxiwa ka miako a ku nge vi xitshunxo xi ri xoxe eka xiphiqo lexi.
13 Jun 2013
Kutani ku vuyeriwa eka xivutiso xexo.
Vugevenga i xiphiqo lexikulu etikweni.
Hi swona swi endleke leswaku ndzi lava ku nyika xitatimende lexi.
Xivangelo xavumbirhi i xikopu xa makungu.
Leswi swi tiveka tanihi xidemokirasi xo nghenelela.
Ndzi ehleketa leswaku swo fana i ntiyiso eka tindhawu tin'wana na tona.
hi vule leswaku ku nga va na swilo leswi hi fikiseke laha
Hi vaxidemokiratiki kutani.
Lexi a hi xiphiqo lexi nga kona hi leswi swi nga xiswona.
Hofisi ya nhluvukiso
Hikokwalaho ndzi tshembha leswaku hi fanele ku endla matshalatshala yo engetelela.
A ku na ku nghenisiwa loku ku nga endliwa eka leswi.
Leswi a hi ku kungela ka hina.
Nombora xivutiso xin'wana na xin'wana.
socha ra miri
A ndzi kona hambi eka nxaxameto.
Mpfuno wa swakudya ku ta va mhaka yo hambana.
Mfumo wu languteriwa ku tiboha eka leswaku wu ta tlakusa njhani NYS.
A va fanelanga ku va va ha khomiwa va va vakhomelanandzu.
Ntirho lowu yi wu tirhaka wa khenseka naswona, hi ku vona ka Tikomiti, wu faneriwe hi ku langutisisiwa swinene.
Swi ndzi nyika ntsako lowukulu kuva xiphemu xa ku hlangana ka hina ka hina laha ka nkoka.
Xexo xi lulamiseriwile eka kungu leri.
Nhluvukiso wo ya emahlweni wa ikhonomi ya hina wu tshembhela eka tinetiweke ta tikhamphani.
Ku hetisisiwa ka Nawumbisi wa Ntolovetiso wa Nawu ku ta pfuna ku anamisa nhlangano laha vatirhi va vaavanyisi va nga ta langhiwa.
A swi ta va kahle swinene ku hlaya xiviko...
Hikokwalaho, xileriso xi fanele ku cincacinciwa hi ku landza xiyimo lexi xintshwa.
ku pfaleriwa ekhotsweni kumbe ku riha ku onhakeriwa ka van'wana hinkwalaho ka -
Mhaka ya mina ya vumbirhi i mhaka ya vuhlapfa.
Xavumbirhi, ndza tshemba leswaku a hi fanele hi ri karhi hi swi tirhisa swinene.
A ha ha avanangi.
Minongonoko ya varimi lavatsongo na yona yi na nkoka ku fana.
A swi se tshama swi va na vumbhoni leswaku swi tano.
Sweswo i tlhelo rin'we, naswona sweswo swi le rivaleni.
a swi enelangi ku xupula vaonhi.
vutihlamuleri
I swa nkoka swinene leswaku hi vhota ehenhla ka xona namuntlha.
Tiko ra hina ri ya emahlweni ri va na xikongomiso xa vahloti va timhelembe.
rhendzeleka
Mitirho leyi yi katsa tindhawu to fana na:
A ku na vukorhokeri lebyi kavanyetiweke hi ku ya hi mahungu lama nga kona.
hi tumbuluxile ku tlula 60 000 wa mitirho.
Xi fanele ku tlhela xi twisisiwa na ku amukeriwa hi mavuthu ya yena.
U nhenha hikuva u hlurile.
Swiviko leswi swi ni vuxaka ni leswi landzelaka:
vadyondzisi na maphorisa.
mavito, vuxokoxoko bya munhu na xiyimo xa vukati bya vinyi lava va nga rejistara
Walowo i nchumu woxe lowu hluvukeke lowu va nga wu endlaka.
I mayelana na timfanelo ta ximunhu.
Ndzawulo ya Mfumoxikarhi na Vupfhumba ya ta fambisi pfhumbha ku sukela hi Dzivamisoko 2013.
Ku pasisiwa ka swimakiwa na mimpfumelelo swi taya hi xiboho xa Mulawuri.
Ndzi tlhela ndzi lava ku twa mavonelo ya vayimeri va vatirhi na vathori.
xiyenge xa mahungu
4.1 Rimba ra swa xinawu na swiletelo
xiyimo xa ntirho
Xana ku humelela yini hi mahungu?
Eka Nongonoko wa NSNP mitirho yi tumbuluxiwa hi ku thola vaphakeri va vukorhokeri byo hambanahambana eka mabindzu lamantsongo, ya le xikarhi na lamakulu.
A ndzi ta tsakela njhe ku kombisa leswi katsiwaka.
Tirha na vanhu
hi mitlawa yo ringana 25-35.
Swo tala swi fanele ku endliwa eka xiyimo xa rixaka.
Tirhana na vaxavi hi ndlela ya vumunhu na ndlela ya kahle.
Hi yima hi lulamile ku teka vuxaka bya hina ku ya eka mpimo wun'wana wa matirhelo.
Swi tano, i mani a nga ta twa ku ndhundhuzela ko ti ba xifuva ka vona.
I swa nkoka ku hlamusela ku endla swo hlawuleka swa ku hungutiwa ka ku engeteleka ka mabindzu ya xiyimo xa le hansi na ya xiyimo xa le henhla.
Xana hi tirhise tindlela leti a kumeka eka hina?
Khume ra matiko ya nghenelerile.
Muako wu ni rivanti ra nsimbi leri tshamaka ri pfuriwile mikarhi yo tala.
Michumu leyi vumbiwaka i tibuloko to aka ta masungulo eka phurosese leyi.
Hi xitalo tindzawulo ta mfumo a ti se endla ntirho wo vonaka eka maIDP
Swi endla leswaku u veleka n'wana loyi a nga hanyangiku kahle emiehleketweni.
Hikwalaho, papalata ku kuma n'wana u nga se fikisa malembe ya 18.
Khonsepe leyi
Xiyimo xa ikhonomi
ku va munhu a hanye kahle
Tinyiki kwalomu ka tiawara timbirhi ta nhlengeletano leyi.
na nhluvukiso na mpfuxeto wa matikoxidoroba.
1. Tata fomo leyi landzeleka ya xikombelo:
Nawumbisi lowu languteriweke eka xiyenge xa 42 ku fanele ku tirhaniwa no wona hi ku landza endlelo leri simekiweke hi xiyengentsongo xa, handle ka leswaku-
pfuxetu tiphurojeke na migingiriko
Vamanana va tlhela va rhwala mpingu wa ntshikelelo wa ximunhu na ikhonomi eka HIV.
Tipulani ta vuxokoxoko ti ta hangalasiwa hi nkarhi wa ntolovelo, hi Nyenyankulu haxawa.
Mubaleki loyi a lavaka vuhlayiseki etikweni rin'wana na mipfumelelo ya vabalekela ematikweni ya vambe
I ncini xikongomelo xa xona ke?
Hi fanele ku phikizana njhani na vona?
Nyika vuleteri bya Ajenda ya swa Tiyindlu eka malembe-khume lama landzelaka.
Leyi i nomboro yikulu, naswona swi le rivaleni leswaku a yi amukeleki.
vaongori eswikolweni na tikomiti ta vatswari na vatswari nakambe tanihi ku hlangana hi ku angarhela kun'we na mihlangano ya vaaki a ko va xiphemu ntsena xa sisiteme ya xikolo.
Ndzi tshemba leswaku swi ta kumeka hi ku hatlisa hilaha swi kotekaka hakona.
Vurhangeri bya Mpumalanga, Gauteng na Limpopo na miganga na vameyara va masipala va ta hlangana na Holobye hi nkarhi wa riendzo.
Hi ni ntirho wo tika lowu ha ha langutisaneke na wona.
Ku na swinharhu leswi nga hlawuriwaka ku vona leswaku vukorhokeri bya antswisiwa
Loji ya Lilogo i ndhawu leyi tsakisaka hi ku tirhisa mafambiselo lama ma nga na vukheta eka malawulelo ya timboni, ku kufumela, ku hlayisa, ku swiphakiwa, na malakatsitsa.
"Mkhine u vurile.
Ndzi na swivutiso leswi landzelaka.
Komba vuxaka bya ntirho lowu tokoteriweke.
Loko u ri hava Pasi kumbe xitifikheti xa n'wana, u fanele ku tisa leswi landzelaka:
Swivutiso swihi na swihi swin'wana?
Ku tiyisa ntalo eka mabindzu ya SADC.
Mfambelano wu fambisana ni nsinya wa leswi yisekaka emahlweni.
kambe matiko lama ha hluvukaka
Austria yi khome mihlawulo naswona yi ta ya emahlweni yi endla tano.
leswi a swi kongomi hi ku ringana.
Palamende ya Xifundzankulu na Vuavanyisi.
minkarhi yo endza na tiawara ta hofisi;
A ku na swihundzulo leswi swi ringanyetiweke, hikokwalaho ajenda yi amukeriwile.
Ku landzelela Swinawana
Hi marito yan'wana, a hi voni nkoka wa matshalatshala ya hina vinyi.
mpimo wa leswi u swi dyaka
Hlamusela xikongomelo xa khodi ya matikhomelo.
Tihuvo ta rixaka leti seketeriweke hi ndzawulo i:
Mpfumelelo wa xiyimo xa vuhlapfa na Pasi ya vuhlapfa ya 13 wa tidijiti ya Nkwama wa Ndzindzakhombo wa lava nga Tirheki kumbe xitifikheti xo hlongoriwa entirhweni loko u tshama u tirha
migingiriko ya vulandzelerisi na vuhleri lebyi mafambiselo ya faneleke ku tshaha eka byona
ku antswisa nkoka wa vutomi bya vona na xiyimo ikhonomi ya vona ha swimbirhi.
Mimbuyelo ya tikomba.
Loko u ri na vutsoniwa bya le mirini kumbe bya miehleketo lebyi endlaka leswaku u nga ringaneli ku tirha, eka nkarhi wo tlula tsevu wa tin'hweti, kutani u nga endla xikombelo xa mpfuneto wa vutsoniwa.
Eka tindhawu leti hinkwato ku na vuswikoti byikulu bya ndzavisiso.
Nyika swikombiso leswi faneleke swa ku tlakusa ximakiwa kumbe vukorhokeri bya ku ringeta lokuntshwa.
ku tirhiseriwa swo karhi
na mixungeto na ku rhekhoda mikutlunyankulu eka nkatsano wa vurhangeri wa SWOT
I nhlengeletano ya kahle hi nkarhi wa kahle.
Nghenisa dokumende ya wena ya vutitivisi na ya muyimeri wa menejimente, loko u endla xikombelo xa xitici xa vukamberi hi ku yimela van'wana.
va xanisiwile hi khombo ro yelana.
leyi i mhaka yo tika swinene.
orha masana
Ndzi na vutihlamuleri eka wena.
Hi fanele ku ya emahlweni ku vula ntiyiso.
Vukorhokeri lebyi byi tirha kahle swinene.
I xitikwana xintsongo endzeni ka mindzelekano ya tiko ra Afrika-Dzonga.
Huvo ya Mhasipala yi fanele yi fambisa ntirho wa wona hi ndlela yo kala vuciva, nakona yi nga ha pfala mintshamo ya yona, kumbe ya tikomiti ta yona, ntsena loko swi twakala ku endla tano hi ku languta mixaka wa ntirho wa kona.
thyaka
Sweswo hi swin'wana leswi ndzi lavaka muviki ku ehleketa ha swona.
Tindlela leti ti katsa:
Xiphiqo a xi le ka nxopaxopo wa ku hambana.
Tsala ndhawu YIN'WE ntsena hi layini.
no tirhisiwa ka swo rhwala swi endla leswaku vatirhi va tirha laha ku nga na pongo.
Eka nkarhi lowu, a hi swi tivi loko nxungeto lowu wu ri ntiyiso kumbe e-e.
Xo hetelela, ndzi fanele ku tsakela ku tshikelela xiphemu xin'we xa nkoka.
Leswi na swona swi ta fanela ku nyikiwa.
Kutani ke, a hi njhekanjhekisaneni ku ya emahlweni.
Tanihi laha ndzi vulaka, ndzi avela nxopaxopo.
na ku wu pasisa leswaku wu va nawu eku antswisiweni ka Nhlengeletano ya Misava eka Swikweleti swa Vaaki ka Ku Onhiwa hi Nthyakiso wa Oyili
Timhaka leti ti katsa ku tirhisa xihoko na swidzidzirisi hi ndlela yo biha
Ntlhandlamano wa swikongomelotsongo
hi ku teka ndlela ya xidemokiratiki leyi hlawulekeke.
Kambe swendleko swa sweswi swi tlhontlhile ntwanano wolowo.
Leswi a ku ri ku humelela lokukulu.
Endzhaku ka ku tekela enhlokweni swiyimo hinkwaswo, hi ta komberiwa ku nyika mpfumelelo wa hina.
Nkanelo wa mixavo
Loko ku ri ni swin'wana leswi hoxekeke, kombela leswaku va swi lulamisa u nga si sayina.
Va kongoma eka hinkwavo.
Mbuyelo wa maendlelo lawa ma ta hi nyika ndlela leyi nga ta pfuna hi endlelo ra makunguhatelo ya mimfumo.
Eka mbangu lowunene wa mabindzu na vulawuri
A ku na leswi khumbaka vumbiwa leswi tivekaka.
Nseketelo wa timali wu tirhiseriwa ku tumbuluxa marimba ya mivalango ya swa soxali.
Kutani a hi swilo swintshwa.
MAPHORISA YA NA NTIRHO WO MANGALA
Tsarisa switshoveriwa leswi trhisiweke eka vurimi.
Leri i vonelo.
Swi tshike eka ku heta ka nhlamulo yin'wana na yin'wana.
Hi lava ku tumbuluxa rimba leri nga erivaleni ra swa nawu.
Va fanele va tekela enhlokweni vundzeni bya tlilasi
u na tikhwalifikhexini leti nga nawini leti lavekaku ku endla mitirho leyi nga hlamuseriwa eka nhlamuselo na swipimelo swa ntirho.
Ha tsaka ku vona leswaku leswi swi kotekile.
Mitshovelo yi mitiwile hi ku olova.
Naswona swi nga endleka ku xi tirhisa sweswi.
swi fanele ku tekiwa nkarhi lowu kungu rolero ri sunguleke ku tirha hawona.
yo vhota eka minhlawulo ya huvo yihi kumbe yihi leyi vumbiweke hi ku landza Vumbiwa, na ku swi endla exihundleni
hi ku nandzihisa
Ku va va tekerile swilo leswi enhlokweni swi va vekile laha va nga kona namuntlha.
leswi swi nyikiwaka hi ndzawulo na nhlangano
tinyawa ti ri hava nhlonge
Loko swi ta eka xikopu
I minkokotso ntsena leyi gwitsirisiweke leyi tikaka 600 g kumbe ku tlula kumbe yo tala naswona leyi nga tluriki 25 wa tithani yi nga xaviwa ematikweni mambe.
Ku hlangana ka swivumbeko swa vutandza swa le henhla na le hansi ku vumba mhaka leyi nga heriki
Handle ka sweswo swi tava swa ntirho hinkwaswo.
Loko a vulavula na Vuk'uzenzele
swiporo
Lowu i ntirho wuntshwa lowu nga nyikiwa matsalani wa matikoxikaya.
-tshika ntirho
A swi ringananga ku tirhana ntsena na switandzhaku.
switirhisiwa swa hofisi
Swinepe swi kombile nkarhi na siku.
swakudya swa swifuwo
Swikongomelo swa EPWP i:
Kambe ku na van'wana.
Vukorhokeri byin'wana bya vanhu lebyi katsaka swa rihanyu na vuhlayiseki na nsirhelelo.
maxala
Swileriso swo hakela munhu ntsengo wo karhi hi poso na swileriso swo hakela ntsengo wo karhi hi bangi kumbe poso a swi pfumeleriwi tanihi tindlela ta mahakelelo.
yi fanele ku va yi ri yintshwa na swona yi ri yo sungula:
Matshalatshala yo lehisa mbilu ya nkarhi lowo leha ya ta laveka ku fikelela xikongomelo xolexo.
Xigwevo xa rifu i xikombiso xa kahle.
Va tlhela va kombela ku cinciwa ka ku hambanyisiwa ku ya hi rimbewu hi ku angarhela.
a yisa thyaka ku va ri ya pimiwa
chukucha
Eka ku humelela ka vaaki mfumo wu na maendlelo yo twala ya leswi va lavaka ku swi fikelela, swiletelo swo hetiseka swa hilaha vuxaka byi nga vumbiwaka ha kona na vatirhisani va vona, na matitwelo lama nga hetiseka y ringana wa swiendlo swa ntswalo wa mani na mani leswi va swi langutelaka ku suka eka vaendli lava.
vunene
Loko matimba yo endla milawu ya nyikiwo ya hi Mhaka-ntsongo ya (1), xihi na xihi tekiwa tanihi loko ku ri leswi kongomisiwaka eka vulawuri lebyi ya nyikeweke eka byona.
nkwetlembetano wa mihlangano.
Tanihilaha va vulaka, miehleketo yi fana na voko.
xitsundzuxo xa xihuhuri
Lava i vanhu va xiphurofexini.
Hambi ku ri na mpfuneto lowu
Tanihileswi masipala a a ri na vuxokoxoko lebyitsongo mayelana na vaakindhawu va masipala loyi, ku le ku tumbuluxiweni ka phurojeke yo hlengeleta vuxokoxoko leswaku masipala a ta va na mianakanyo yo antswa mayelana na nhlayo ya makaya lama a faneleke ku ma phakela mati na gezi kun'we na swikoxo swa vukorhokeri lebyi.
xitlhangu
A hi nga pfumeli swihari leswi swi onha xifaniso lexi.
A ku na rhekhodo ya milandzu leyi lavisisiwaka.
mihlangano ya swa mfuwo xik. vutshila
A va teki vutihlamleri bya swiendlo swa vona.
Swi tlhela swi katsa mfanelo yo voyamela eka rimbewu ro karhi.
hi le ku kambeleni man'wana magoza lama nga lavekaka ku tirhana ni mhaka.
Nawu wo Tlakusa Nxavo wa Gezi wu antswisiwile.
wun'wana wa vatshami vo hlawuleka va le Gauteng loyi a nga katsiwa eka mbulavulo wa Holobye wa Xifundzankulu Nomvula Mokonyane na rixaka
Hi swona swi endlaka leswaku ntlawa wa mina wu ta va wu ri karhi wu vhotela, e-e.
Hambiswiritano, xexo a hi xiphiqonkulu xa hina namuntlha.
hi hlanganisiwa swin'we hi nghingiriko
Swinawana na milawu a yi endliwa eka swiyenge swo hambanahambana swa mfumo, yi gazetiwa no tirhisiwa hi vatirhelamfumo.
Mi tirhile kahle n'wina va lulamisi
Loji ya Lilogo yi kombisiwile eka nkombiso wa xiviri lowu seketeriwaka hi timali hiwa nkwama wa mfumo wa
Hi na tindlela to tala to endla leswaku vanhu va fikelela ntwanano.
Kambe hi nga lahlekeriwi hi timhakankulu.
Hlamusela swipimo leswi faneleke ku tirhisiwa loko ku hlawuriwa mbewu yo andzisa.
Xana hi twisisa yini hi mhaka ya misava hinkwayo?
Ndzi seketela nsusumeto wa endlelo rakwe.
Eka Xiyenge xa D, swikongomelo, maqhinga, tiphurojeke, tsala xivono xa ka masipala eka ntila wa le henhla (Xivono xa Masipala);
Hilaha swi ringanyetiweke hakona eka Mahlelelo
Kombisa swilaveko swa xivumbeko na matirhele.
Ndzi ta kongomisa nyingiso wa mina eka swiletelo swo anama swa ikhonomi.
Xiendlo xo yingisela xi lava ku twelana naswona swi khumba ku yingisela hi xikongomelo
fomo ya xivutiso hi swa rihanyu
A ndzi ta rhandza ku endla tipoyinti tinharhu.
Rejoice Mabudafhasi
leswaku hi ta hanya etikweni leri pfumalaka xihlawula-mbala na ntshikelelo.
A wu ri na nseketelo lowu, naswona u ya emahlweni u va na wona.
ehandle ka Butterworth
swakudya swihi na swihi leswi faneleke ku dyiwa eka ndzhawu ya bindzu kumbe ehandle ka ndzhawu ya bindzu;
Nchumu wun'we lowu nga riki eka ntwanano i mafumelo.
Nhlahluvo wa sampuli leyi nghenisiwaku etikweni: R310
Swilo swo tala swi humelerile eka khume ra malembe lama nga hundza.
Wanuna u khomiwile hi maphorisa.
Vona leswaku u teka nkarhi wa ku tivisa Komiti ya Wadi eka ntlawa wa ntsakelo na ku va nyika vuxokoxoko bya wena bya vutihlanganisi.
a ndzi nga endli sweswo!
ku ni mhaka ya nkavanyeto wa tihlarimbya leti yisaka tihomoni engatini.
1.5 XIKONGOMELO XA BUKU HI KU LANDZA PAIA
A ndzi langutela swo antswa.
1.9. Khabinete yi khensisa vahlamberi Cameron van der Burgh, Chad le Clos and Giulio Zorzi lava nga endla leswaku tiko ri tinyungubyisa hi ku wina timendlele eka Federexini yo Hlambela ya vu 15 ya Misava (FINA) eka Tinghwazi ta Misava eBarcelona.
Swi humeseriwe ehandle, kamba swi fanele ku tshikelela.
swakudya swo kala khaboni
Xivutiso lexi xi khumba wun'wana na wun'wana, ku nga ri mimfumo ya tiko ntsena.
1.5. Khabinete yi khensa eka xiphemu lexi endliweke hi maAfrika-Dzonga hinkwavo eka ku pfuneta ku hlayisa 3 586 wa Timegawati ta eneji ku suka hi 2005, ku nga mpimo lowu ringanaka na xitici xin'we xa gezi.
Irhangana xin wana xa mfumo eka lembe leri i ku hetisisa na ku wundla maqhinga ya mbuyeriwo tanihi pholisi ya ximfumo ya mfumo
rindza khombo
Minkwama yo byala hi yona kumbe yo tiyelerisa loko ku tleketliwa swimilana leswi kamberiweke eka ndhawu yo tirhela kona yi fanele ku basisiwa hi ku humesiwa no hlantswiwa siku na siku.
Nakambe hi le ka tintswalo ta matimba lamakulu ya ikhonomi ya misava.
Ku tlula migodi, hi boxile swifambisi swa ntlhanu swa mitirho hi 2009.
Eka mhaka yinwana na yin'wana, hambiswiritano, i mihlangano leyi nga ri ki ya mfumo.
xihina
ku tsutsuma ngopfu
Xikombelo Xa Layisense Ya Holiseli
ku na swo tala ku endliwa.
Ku thoriwa ku landzela xikombelo ku suka eka UN kuya eka Afrika Dzonga.
Ndzi hisekela ku vona leswi nga eka xitshuriwa xa wena.
Khomixini ya Mitirho ya Vumbiwa yi nga ha letela mfumo wa rixaka hi mhaka yihi na yihi leyi yelanaka na vuavanyisi kumbe mafambiselo ya vululami; kambe, loko yi karhi yi kambisisa mhaka yihi na yihi handle ka ku thoriwa ka muavanyisi, yi fanele ku khoma nhlengeletano ku ri hava swirho leswi thoriweke hi ku landza xiyengentsongo xa (1)(h) na (i).
Sweswi a hi sunguli emasungulweni.
Uzbekistan ri na mavonelo yo hambana eka xivutiso lexi.
Hikokwalaho hi ta boheka ku langutisisa sweswo.
Xiyimo lexi nga kona sweswi xi langutiseka xi ri lexi nga erivaleni no va lexi tsakeriwaka.
Hambiswiritano, xi fanele ku tlhela xi tihakelela.
Leswi swa ha tiveka swi ri xin'we xa ntirho.
Hi ku endla xikombelo xa layisense ya thelevhixini
Eka xiviko xa mina xo vekiwa exitulwini ndzi vule leswi landzelaka:
Lowu i ntwanano wa nkoka swinene lowu hi wu lavaka.
Misava leyi nga ri ki na nchumu
ndzi komberile nhlamulo yo hlawuleka.
nkumo
Ku durha hinkwako ka projeke leyi nga kusuhi na ku hela hi 2004 i R228 wa mamiliyoni.
Xikimi xa Vupulani bya Tshwane xi na -
Muleteri wa mathwasani
Ku tirhisiwa ka xihundla hi ndlela yo homboloka i nkwetlembetano wa mafumelo ya xidemokiratiki.
Sungula ku tekela enhlokweni swilaveko, ku navela na mavonelo ya van'wana;
Hi fanele ku tirha na mabindzu, swa mitirho na miganga ya vahlawuri.
Xana i mahetelelo wahi lama hi nga ma nyikaka ku suka eka matimu lama yo koma?
Miako na mbango swi kumeke kuri swo tsana eka hinkwaswo.
masungulo ya vutshila bya vanhu volavo
Miphutumo a yi fambelanisiwi ni rivengo ra ku ya hi tinxaka (zenofobiya) ntsena.
Ku na tindlela tin'wana to tshunxa swiphiqo swo tano.
swakudya
MPIMO WA RIXAKA
Ndzavisiso wa ntungu kutani wa endliwa ku:
Swo fana swi nga ha vuriwa hi mhaka ya vuakatiko.
Hi ku vona ka mina leyi i nhlayo leyi nga ehansi ku tlula mpimo.
Xikombayuniti
N'wana u fanele ku sapotiwa kumbe ku wundliwa hi:
Tinyawa, tiherekisi, tilentele, na swakudya swa soya.
ku lulamisa no sungula milawu; na
Eka nkarhi wa sweswi, a hi nga endli nchumu ku antswisa xiyimo.
Ku tlhela ku ri na lava ngatshika xikolo.
U nga ti eka mina na swipimelo!
Va fanele ku seketeriwa hi tindlela hinkwato leti nga kotekaka.
Phalamende yi ta tshama yi ri leyi tiyimiseleke eka leswi.
Wena u hlawurile xivangelo xexo.
hi nga ka hi nga teki ntirho lowu wu ri na nkoka ngopfu.
Ndzi ehleketa leswaku hi fanele ku amukela leswi hi vutshembeki.
Hi nkarhi lowu Afrika-Dzonga a ku ri Mutshamaxitulu wa BRICS
vudakwa
Muahluri Holmes u te naswona ndza tshaka:
Ku kunguhata hi ta maendlelo ya LARP swi ta va kahle eka nkarhi lowu.
Manyala ma nga ha tlakuka ku suka eka maendlelo yo tsana na le ka swiyenge endzeni ka mfumo
Hlamula xivutiso XIN'WE ku suka eka xiyenge XIN'WANA na XIN'WANA.
Hi na ku tshembanyana, kambe ku nga ri ku tlula sweswo!
swi ta sunguriwa ka ha ri na nkarhi.
Vutivi bya nawu wo karhi.
Kombisa vutivi bya nhlamuselo ya ximfumo ya ntirho.
mbyana yo komba ndlela
Ndzi seketela nkunguhato lowu, lowu twalaka swinene.
Yuropo yi na nkoteko wukulukumba eka ndzavisiso na thekinoloji.
Teka xiave eka swivutiso leswi fambelanaka na malulamiselo ya tiphurojeke leti nga khumbaka vaakindhawu va ka vona.
Ndzi tlhela ndzi lava ku engetela nchavelelo wa mina.
xivono xa hina i ku tiyisisa leswaku hi 2030
tiKPI ti langutisisisa hi lembe hi masipala tanihi xiphemu xa endlelo ra ku langutisisa matirhelo.
Dyondzomhaka yo hetelela na yona i xikombiso xa madzolonga lama tlulaka mpimo.
Sivela ku haha ka nkahelo wa mati.
Ndzawulo ya Dyondzo ya le Hansi; the Department of Basic Education;
Tani hi leswi mitirho ya mfumo yi nga mavokweni ya vanhu va tiko, vatirhi va fanele ku tihlanganisa na vanhu hinkwavo lava pfumalaka vutivi, va va nyika vuxokoxoko hinkwabyo na ku va pfuna eka hinkwaswo leswi va swi lavaka.
Nyika leswi kumiweke
u kota ku vulavula, ku hlaya na ku tsala English tani hi rin'wana ra tindzimi ta ximfumo
Ndzi engeta leswi ndzi nga swi vula.
Vito ra Xirho
ku nga si fika 27 Dzivamusoko 1994
ntlawa wa hina wu ta va wu karhi wu vhota wu kanetana na vona.
Timfanelo na ntshunxeko wa masungulo a swi fanelanga swi vutisiwa swivutiso.
Xana hi ta swi endlisa njhani?
Ku rindza leswaku tikomiti ta tiwadi ta hlangana hi ndlela leyi pfunaka
Tanihilaha vanhu va vuleke hakona, xiyimo hi lexi biheke swinene lahaya.
Ndzi se ndzi xi vonile eka tindhawu to tala.
x100
Swi ta va njhani loko vaaki hinkwavo va endla leswi?
Lowu i ntirho wa hina, ntirho wa tiinsitithuxini hinkwato.
Sweswi hi le ku cinceni gere.
Tiko ri langutane na ku hlawula.
nkahelo
Phemiti ya byalwa
Handle ka ntirhonkulu wa mbulavurisano
Kambe, pfumala nkateko, a ndzi na xitirhisiwa xexo.
hi lava mphalalo wa xihatla eka vahlapfa.
(Vona Kavanyisa ka 3 3.2.2 ku kuma mahungu hi xitalo hi 'mali leyi nghenaka no huma'.)
ku katsa vatswari lava va nga adopta n'wana
U angularisa ku yini?
Loko wansati a tshama na vana va yena hinkwavo na swona ku ri hava loyi a nga lova, kutani vekela 00 eka P-36 ku fika eka P-37 (eka vafana, vanhwanyana na nhlayo).
Hi mpfumelelo wo rhumela ematikweni mambe
mutirhi wa nhlayiso u fanele ku tivisiwa hi xihatla
A hi vukorhokeri hinkwabyo byi nga vekiwaka eka xiyimo xo fana.
Sweswo hilaha hakunenenene hi bohekaka ku ya kona.
ku tiolola na ku tiolola ku va hi tshama hi ringanerile.
Sisiteme ya mahungu ya swa ntivomisava (SMN)
A ndzi ta vulavula ndzi seketela leswi.
Mhaka yo lulamisa yo hetelela.
Ku kuma ku seketeriwa hi council na garanti leyi nga voyamelangiku tlhelo ya vuswikoti bya wena.
tikhampani leti fambisiwaka hi mfumo leti tirhaka na xiyenge xa eneji
xivovomerisi
Hambiswiritano, ntlhontlho ku tava ku vona leswaku swi tiyisiwa ku ya emahlweni.
KAVANYISA KA 3:
kumbe ku tirhisa nhundzu ya mfumo eka mitirho ya kona
Naswona kunenene xexo hi xona xikongomelo laha.
Sweswo i mhakankulu leyi hi faneleke ku langutana na yona.
'Makanelwa' ko va rhekhodo leyi tsariweke ya leswi nga humelela eka nhlengeletano
Hambiswiritano, eka xiendleko lexi, van'watipolitiki va hoxisile.
kambe hinkwavo va xiximana.
Ku tirha eka maxelo yo hisa no oma, swiambalo swa kahle swi fanele ku tirhisiwa ku papalata mayelana no hambanisa no pfumelela ku hefemula ka miri
Ndzi ta tsakela ku rhamba varhangeri va hina va mabindzu ku netiweka na swikolo leswi.
Hi ntiyiso
Leswi swi kongoma, xikombiso, xiviko xo hlawuleka xa vupfhumba.
N'anga ya rihanyu ra swiharhi u fanele ku tiyisa hi nawu leswaku xihari xiamukelekile hi ku landza:
A ndzi nga ta lorha ku swi endla.
Hakanyingi i vana lava xanisekaka swinene.
Kuma swo tala hi Maendlele ya Nkumo na Vuhlayiselo bya Mahungu ya Rixaka kumbe u tihlanganisa na Ndzawulo ya Vutshila na Ndzhavuko eka 012 441 3255 / 3000.
hi ku tsundzuxana na Swandla swa Presidente na varhangeri va Minhlangano leyi khumbekaka
Xana mhaka leyi laha henhla yi vula yini?
se hi endlile leswi.
n'wafuma-yexe
Hi ku komisa, matlhelo laya khumbhekaka eka minkanerisano yi fikelele ntwanano eka timhaka hinkwato mayelana na timhaka leti matlhelo hi mambirhi a ya fanele ku ti lulamisa.
Hi swi hlamusela njhani sweswo eka vaaki?
Hi ta ya emahlweni no tirhisa G20 ku kombisa milorho ya vanhu va Afrika no susumeta ku cinca eka Tindhawu ta Bretton Woods.
Ku gwitsirisa mikwama a hi xintshunxo xa swiphiqo leswi, hambiswiritano.
vuanameni
Ndzi ehleketa leswaku yalawo i maendlele yo hoxeka.
Xitulu xa Khomixini xi ta bohiwa hi Phuresidente.
Sweswo swi amukelekile swinene.
ku tumbuluxiwa ka swivandla swa ntirho
Mufambisinkulu wa Nhlangano wa Rixaka wa Vadyondzisi (NATU) Allan Thompson u pfumerile.
"Mintlhontlho yo tanihi vukhamba bya swifuwo yi tshama ya ha ri ntshikelelo lowu pandzisaka nhloko eka vafuwi va swifuwo exifundzheninkulu.
Tatana Mapisa
Loko u nyiketa vutivi byo homboloka, kumbe u tirhisa hi ndlela yo biha mpfuneto wa xikimu xa EMIA, swi nga endleka u susiwa eka mpfuneto wun'wana wa xikimu xa EMIA kumbe TISA.
Ku khumbheka ku vona leswaku ku ni kurhula na nhluvukiso ni vululami eka tiko ra hina.
A ndzi tsakangi ngopfungopfu hi vutikayiveti lebyi fikeleriweke.
Hi endle ku cinca ko nyanyula.
ku swi tatisa.
Loko khopi leyi fakazeriweke ya fayili ya le khoto yi fika eka matsalani, Khomixinara u ta tivisa xitshunxo.
Mutivi wa swa vuahluri i engetelo wa huvonkulu.
Ku tihlanganisiwile na mutshamaxitulu wa komiti yaleyo.
Vukorhokeri lebyi i bya vadyuhari lava lavaka ku hlayisa 24 wa tiawara ekaya ra vadyuhari.
A wu vulavulela ngopfungopfu ntwanano.
Muvulavuleri La Xiximekaka, hi le kule ni laha hi lavaka kuva kona.
Sweswo swi na nkoka swonghasi.
Eka mbangu lowunene wa mabindzu na vulawuri, hi ta:
ku va kona ka xiphiqo lexi a ku ariwa.
tiyisisa leswaku xiyenge xa mfumo xi endla mitirho ya xona tanihi mutirhi wa nkoka eka nhluvukiso
Hlamusela tinxaka na xikongomelo xa makanelwa ya tinhlengeletano.
A ku na kufambafamba loku voniweke kumbe loku vikiweke ku fikela namuntlha.
Leswi swi katsa ku tirhisiwa ka switirhisiwa swa mfumo.
Mpimo wa gezi wo sungula wa mahala i 50kWh eka muti na muti hi n'hweti eka fambiselo ra ntamu wa grid leyi yi tlhomeriwaku hi nongonoko wa national electrification programme).
Ku pfuneta ku pima vanyiki va vukorhokeri.
Timfanelo ta ximunhu ti na nkoka
Tiinstituxini leti nyiketaku hi tikhoso to koma minongonoko leyi nga ri ku ehansi ka NQF, kumbe swiyenge swa tikhwalifikhexini a tikhumbeki eka ntsariso hi ku landza nawu wa FET Act.
A ndzi nga yi eka hinkwaswo swa swona.
mitwanano ya matiko ya misava na ya xifundza
Swivuriso leswi a swo endliwa handle ka xivangelo
Khomixini ya Ndzingano wa Rimbewu.
Dorobankulu / Doroba
Tihlanganise na hofisi ya le kusuhani ya swa mimovha emapatwini
Tirhekho leti faneleke ti fanele ku hlayisiwa.
1.1 Xana ku teka xiave ka vaakindhawu i yini?
Ndzavisiso wu endliwile endzeni ka mfumo na hi vanhu va le handle.
Koroni yi fanele ku tshoveriwa hi nkarhi lowu faneleke.
A ndzi ta rhandza ku heta hi mhaka yin'we yo hetelela.
Kombisa khiyi ya laha ntirho lowu wu sungulaka kona na laha wu helaka kona.
Ndzi se ndzi ri laha ku ringana 16 wa malembe.
Hi na milawu minharhu leyi nga hundzisiwa hi yindlu leyo xiximeka.
Tipresidente timbirhi ti tekerile enhlokweni leswaku vupfhumba bya misava byi le khombyeni ra ku va byi ri kahle hikokwalaho ka vusirheleri ni ntshamiseko.
Ku vonana na va ndzawulo leswaku va rhangisa ntirho wo kuma mati na ku lulamisa swa mbhasiso (sanitation) eka xikolo xa tintangha ta le hansi, na le ka tikhirexe
u nga ha va na HIV.
Ndza tshemba leswaku mimpimo ya maahlulelo leyintshwa yi lulamile.
muluvisi
Xa vunharhu, nkoka wa ndzinganano exikarhi ka vavanuna na vavasati.
hi hlanganisile vukorhokeri lebyi.
Misava ya mina
Swin'wana swa swihlovo leswi swi katsa leswi landzelaka:
A ndzi kanakani hi swa n'hweti leyi taka.
Tinsimbhi to tiyisa ti lava ku pfariwa hi khonkhele.
Xiave eka xitsundzuxo xa ku cinca ka Afrika Dzonga ku ya eka xidemokirasi.
lava pfumalaka ntirho na lava nga na vuswikoti bya le hansi.
I goza ro sunhula.
Ndza tisola eka leswi no tshemba leswaku swi ta cinca.
kumbe kumbe 76 xi tirhisiwile eku pasisiwena ka Nawumbisi wolowo.
Kumbexana leswi swi nga cincacinciwa.
Ku amukeriwa hi hinkwavo ka swikili swa rimbewu na ndzingano eka nhluvukiso
tifilimi
timfanelo ta ximunhu na tlheriselano wa ntirhisano.
Maendlelo yo vevukisa: Ximbirhimbirhi na Makunguhatelo
A hi vulavuleni hi leswaku hi nga swi endlisa ku yini.
xihlovo-mananga
naswona swi na nkoka.
Eka timhaka to tala va ta va ri hava mahungu lawa ya ringaneke.
swi nga va swi ri na timhaka to tala ta endlelo.
Mayelana na leswi, ku cinciwa ka SADC ku herile.
Ku hlanganisela na ku simekiwa ka Ajenda ya Xiafrika.
Vatlangi va ndhuma: Fernando Torres, Xabi Alonso, Iker Casillas,Sergio Ramos.
Ehleketa hi laha u burisanaka hakona.
Ko va 50% ntsena wa vaanguri va Mbalango wa Komiti ya Wadi ya Rixaka lava voneke onge vuleteri bya muxaka lowu hilebyi va vuyeriseke.
Hi boheka ntsena ku tirhana na xibyurokhirasi.
Hambiswiritano, a ndzi ta tsakela ku hlamusela ti va erivaleni timhaka timbirhi to kongoma.
Xexo hi ku angahrla i xivutiso lexi ndzi ku vutisaka xona!
a ri na timali na vuswikoti byo endla ntirho wo lavana na timinerali hi xiyenge xa le henhla
Ha swi tiva leswaku ikhonomi ya hina yi langutane na mitlhontlho.
vulandzelerisi na vuhleri ku ya hi nkhetekanyo wa phurojeke ya CBP.
Yuniti ya bindzunyingi yo phasaphasana
byatso bya maseyila
Fureme ya sampula ya mabindzu (FSM)
minhlangano ya vumaki na JAG yi yimela kwalomu ka ntlhanu wa mabindzu ya Afrika-Dzonga.
Swilo leswitsongo swo fana na xiborisi
Hlawula 5 wa tiwadi leti nga na makhombo na tinghozi to tala u tlhela u boxa muxaka wa makhombo na tinghozi
Hi fanele ku sungula na vanhu.
Yuropa yi yima emahandzeni.
Ndza tisola kambe eka lavaya va nga khomiwa hi tingana.
Kavanyisa ka 7 (Xiyenge xa 152) ka Vumbiwa ku andlala swikongomelontsongo swa mfumo wa miganga.
Vafambisi va le henhla lava hundzaka 30% va mfumo I vavasati
Xandla xa Presidente wa Vuavanyisi kumbe muavanyisi wa khoto laha swi boxiweke eka ndzimana ya loko Vumbiwa byintshwa byi sungula ku tirha
Xikombelo xa phemiti ya FPE xi nga teka masiku manharhu yo tirha kumbe ku tlula
Sweswo swi tlhela swi va xilo xin'wana lexi nga fanelangiki ku rivariwa.
Rhijisitara leyi kombisiweke eka ndzimana ya (a) yi fanele ri katsa leswi landzelaka:
leswaku wu lava mali muni na leswaku wu fambisa hi va mani.
Bodo yi fanele yi hlayisa timinete ta mafambiselo na swiboho.The Board must keep minutes of its proceedings and decisions.
leswi vulaka tindhawu leti vanhu va hlanganelaka kona hi ku va va tilulamiserile hi voxe - ku nga ha va ku ri hikwalaho ko lava ku vumba nyandza yin'we yo tshandzisana kumbe ku kombisa ku vilela ka tipholisi ta mfumo kumbe matirhelo
Loko timfanelo to tereka tiserheriwile hi Vumbiwa na milawu ya vatirhi, Khabinete yi kombela vathori na mihlangano ya vatirhi ha vumbirhi ku ololoxa minkanerisano hi ku hatlisa ku sivela switereko swa nkarhi wo leha.
leswaku xi humesiwa eka Gazete ya Mfumo leswaku vanhu va tihlamulela.
Ku hava nhlamulo leyi nga languteriwa eka Adam hikuva u le hansi ka malembe ya 5 naswona xivutiso lexi xi lava vanhu lava ngana 5 wa malembe ku ya ehenhla
Kungu ra matirhelo ri boxa:
ku pfariwa
Eka nkarhi lowu nga hundza, hi ntumbuluko, vanhu a va tsakela ku ringanana loku ka ikhonomi leyikulu.
Swivutiso leswi fambelanaka ni mapulanele ya minghingiriko ya mapurasi swi nga tirhisiwa ku tlakusa maehleketelelo yo dzika.
Ku ololoxa xiphiqo lexi
na vaxinuna lava nga na 65 wa malembe na ku tlula.
silabasi
Xinawana na Milawu
Exikarhi ka lava i vamanana, vana na vadyuhari.
Ku pfumaleka ka leswi ku hava vumundzuku.
timhaka leti rhangisiweke ta vaakindhawu na laha Komiti ya Wadi yi nga pfunaka hakona
A hi lavi ku nyikiwa ka matimba ku fumisa vanhu va nhlayo leyitsongo.
Ku ringanyetiwa leswaku kwalomu ka R99 wa mamiliyoni ya ta laveka ku hunguta xiyimo.
Vatirhela mfumo va fanele ku tirhela mfumo lowu nga hlawuriwa hi ku tinyiketela
njhekanjhekisano lowu wu na xihlawulekisi xa nkoka.
tintangu ni mapesa
Ku engetela eka mafuremelo ya swikombo swa matirhelo ya yona
Exikarhi ka mitirho ya vutshila leyi hayekiweke emakhumbhini ya munyuziyamu ku ni mitirho ya mutshila wa swikeche
Papilla ro sirhelela ra laveka ku suka eka mutshami kumbe n'winyi laha thyaka ri faneleke ku susiwa eka ndzhawu.
lowu hi tlhelo wu vuriwaka Nawumbisi.
Vuleteri bya lavakulu byi tiyisisiwile.
Ndzi twa leswaku a va tsakanga.
Laha nakambe, hi fanele ku hambanisa exikarhi ka timhaka timbirhi.
A swi koteki.
leyi yi nga ta nyika vangheneri nkateko wa ku va va hlangana na tindzawulo to hambana ta mfumo
A ndzi ta tsakela tinhlamulo to karhi leti nga erivaleni ehenhla ka timhaka leti.
Xilaveko xa nkoka xa mafambiselo lamanene i ku tiyisisiwa ka sisiteme ya tinhlayo ta rixaka.
swirho swa Maiindiya ya Palamende ya Tihuvo Tinharhu ya 1983
Tlhava eka batheni yo rhumela loko u lunghekile ku rhumela poso.
Mitsengo leyi yi fanele ku hlayisiwa.
Naswona swi tlhela swi va swa nkoka ku fikelela ntwanano wa mahala wa bindzu.
vubeburisi na ku tshungula swigulani leswi swi tlelaka
Hofisinkulu ya Huvo ya Vuchuchisi ya Rixaka
Ndzi tshemba swinene leswaku hi na malembe ya migingiriko yo engeteleka endzhaku ka sweswo.
Loko ku ri na swivutiso, tihlanganise ni va xiyenge xa ndzawulo va ta hlamusela.
Nhlayo ya vukhongeri lebyi kaneriweke
Nakambe, timpahla tinyingi letintshwa tihumesiwile eka xiboho xa vulawuri bya timpahla leti nghenisiwaku.
hi vhotile hi hambana na xiviko lexi hinkwaxo ka xona.
Hi fanele ku engetela vuhlayiseki.
Tanihi xikombiso, eka ndhawu ya ku vevukisa ntikelo wa ku rhandzana hi rimbewu rin'we.
Muvileri kumbe muhlamuri eka xivilelo a nga endla xikombelo xa ku cinca kumbe ku vekela etlhelo xileriso xa khoto xo sirhelela (protection order) hi ku nyiketa nothisi leyi nga tsariwa eka matlhelo mambirhi lama ya khumbekaku na le khoto.
Xana hi swihi switirho leswi u nga na swona kumbe ku swi fikelela?
jekajekisano wa ha ri ekule no hela.
Ku tsundzuxiwa leswaku Foramu ya CBP ya ka Masipala yi sunguriwa leswaku yi ta hlanganisa xiyenge lexi nga na vutihlamuleri bya vatekaxiave hi vaakindhawu (hakanyingi eka Hofisi ya Mulawuri wa Mbhurisano)
Vuxokoxoko
Leyi i mfanelo leyi faneleke ku tiphiniwa hi yona hi MaAfrika Dzonga man'wana.
hi ni swikombiso swimbirhi swa ku kombisa leswi.
Va na na vutihlamuleri kutani u kamberiwa namuntlha.
1. Yuniti yo landzelerisa o Swiviko swo landzelerisa
A hi pfumeleriwangi eka nkanerisano wolowo.
mulanguteri: matiko-xikaya
Ku teka xiave hi ku hetiseka ka Tikomiti ta Tiwadi swi hoxa xandla eka ku humelela ka makunguhato.
3. Swa ikhonomi
Tiva dyondzo
U nghenelela eka mphikizano wa swivutiso swa vuyimbeleri ku kuma mikutlunyo ya xipano xa wena.
I swa kahle eka mitirho na ku kula.
KNP yi na vutomi byo ringana malembe ya 5 naswona ya kambisisiwa lembe rin'wana na rin'wana.
Vuhundzluxi bya Xipanixi-Xinghezi
I ntiyiso, hi hlohloteriwa kahle hi mimbuyelo ya kahle kusuka eka swiyenge swo ka swi nga ri swa mfumo leswi kombisiweke hi ku tiyimisela ka ti-CEO ta 70 wa tikhamphani leti nga xaxametiwa eka Johannesburg Securities Exchange ku tirha na mfumo eku lulamiseni ntlhontlho wa vuswikoti lebyi pfumalaka.
Xana i mania a nga ta va na vutihlamuleri eka leswi?
Eka xiphemu xa mina, ndza tsaka mayelana na swona.
U nga kombela ku cinciwa ka ntsengo wa xiwundlo lowu hakeriwaku, loko wu nga ha ringanangi kumbe u nga ha koti ku wu hakela.
mahafukhadi kumbe mihandzu yo tshakatiwa yo olova.
Hi swona swi endlaka leswaku hi dinga xikongomelo lexi xa le xikarhi.
muaki wa mabuloho
Swi ta fanela ku sungula mikanerisano leyi.
Sweswo hi leswi hi swi endlaka hi tipholisi ta vunjoveri.
Le fa go ntse jalo
Ehleketani hi nkarhi lowu lavekaka eka ku hlela.
Ndzi ehleketa ku ri hinkwerhu hi twisisa leswi nga hi rindzela.
ku hava ku tirhisa mali ku tlurisa mpimo hi ku angarhela eka lembe ra 2005.
R6 000 - xikombelo xa vutirhelo bya ku prosesa tinhlampfi
Phurojeke a yi katsa ku thola vanhu ku endla patu ra 20km naswona yi lava leswaku 30% ya vatirhi ku va vamanana.
Hambileswi ku nga ni vuxopaxoperi lebyikulu bya mphakelo wa vukorhokeri
Qhinga rolero ri fanele ku katsa kungu ro sivela vukungundzwana.
8.1 Maendlelo yo vika kumbe ku lulamisa 14
Yo sungula i ku amukela xiyimo mayelana na ku teka xiave.
Loko leswi kuri hanyelo ra kona
batiki ya mhula
Vaholobye va kombela kuva swivutiso swi tshama tano.
Naswona eka vo tala va vona
kumbe hi vito rin'wana
Ndza khensa swinene eka matshalatshala ya n'wina lawa mi nga ma endla.
Hlamusela eka fomo ya xikombelo leswaku xana u ta yi landza phemiti kumbe u ta lava ku rhumeriwa yona.
Hi ta vona hilaha hi nga angulaka hakona eka xiringanyeto lexi.
Va endlile muxaka wa vumbiwa ra nawu lowuntshwa.
Hi ta humelela ku fika kwihi, a ndzi tivi.
U nga endla xikombelo xa ku tiendlela puletinamba ya wena hi ku tirhisa nkatsano wa tinomboro kumbe maletere ya alifabete lawa u ma hlawuleke [swi ya hiloko Xirho xa Komiti ya Vurhangeri xi swi amukela
Eka lexitsongo ngopfu lexi fanaka, leswi swi hetelela swi ri mpfumaleko wa matirhelo lama nga erivaleni.
Nhlamuselo yo koma ya ndzimana yin'we ya phurojeke leyi komisaka mbuyelo wa phurojeke
Hikokwalaho ka yini ndzi vula mhaka ya ku vula swoleswo?
Kambe ntsena tanihi xiyimo xa tiko hi roxe.
xa vusati na vununa
va hangalasile tinhlayo teto kutani hinkwerhu hi kunguhata ku ya hi tona.
Ndzi tshemba lexi ku va xa nkoka
Laha vanhu hinkwavo lava nga ringanela ku tirha va tava na nkateko wo tirha.
Swi lava leswaku na tikhampani ti langutana na leswi.
Hi le kwihi sweswi na endlelo leri?
Kuma swo tala eka http
Loko u humelela u ta nyikiwa xitifikheti xa ntsariso.
maendlelo ya ximunhu na milawu ya xindyanguehansi ka ndzhavuko, kumbe ku landzelela leswi vuriwaka hi munhu wa vukhongeri byo karhi.
Ndzi ta va ndzi ri karhi ndzi papalata eka vhoti yo hetelela.
Swibumabumelo kumbe xiendlo xo engetela lexi lavekaka:
Xana u fambisa ndhawu ya makuriselo ya vana lavatsongo naswona u lava ku nyika dyondzo na nseketelo lowu nga ringanela eka antswisa malembe, xiyimo na swilaveko swa vana lava u va hlayisaka, ku katsa vana lava nga na swa vulamari, mavabyi lama nga godzombela na swilaveko swin'wana swo hlawuleka?
Hi ta va pfuna ku endla leswi.
xihlala
Vafumi lava va fanele ku nghena hansi va tirha.
Ntirho wihi na wihi wa milawu ehansi ka xiyenge xa 235 (8) wa Vumbiwa bya khale, ku katsa ku cinciwa, ku tolovela kumbe ku endla xivilelo no nghenisiwa ka milawu yihi na yihi na goza rihi na rihi rin'wana leri tekiwaka ehansi ka mhaka leyi.
Hi tlhelo ra mina, ndzi ehleketa leswaku i xitsariwa xo ka xi nga ri kahle.
Hi ta ya kamba, ndza nga mi tshembisa.
H.L. VANHU
Ntirho wun'wana wa ha ta lava ku endliwa mayelana na leswi.
Doroba ra Mina - Vumundzuku bya Hina!
ku hela
xitatimende lexi hlambanyeriweke eka va nawu xa leswaku movha wu yiviwile, wu vaviseke lero wu nga ha tirhiseki, kumbe xitifiketi xa ntsariso xi suriwile.
Ku humelela ka Palamende swi lawuriwa hi ku nghenelela ka nkhinkhi ka vaakitiko hinkwavo va Afrika Dzonga ku nyika ndlela eka ntirho wa Swirho swa Palamende swa vona leswi hlawuriweke na le ka nhlangano.
Hikwalako ka sweswo, tsevu wa vatlangi va vavisekile naswona vambirhi va vona va vavisiwile hi maqulu.
Hambiswiritano, switiviso leswi swa mafundza swi sungurile ku tirhisiwa.
ku tiyisiwa ka ku fuma ka nawu.
Ndzi ta mi tsundzuxa timhaka ta mune.
Hi amukela nkateko lowu wo avelana vuxokoxoko mayelano na phurojeke.
leswi hi swi lavaka i pholisi ya vuhlapfa ya vutlharhi.
Loko ku ri ku gezi ri le ku tirhisiweni hi ndlela yo ka yi nga ri kahle kumbe yo ka yi nga hlayisekangi
Hi ku pimanyisa
Kwalaho a swi nga ta endliwa swi kumeka eku sunguleni.
Xiphemu xa xona
Khabinete yi amukerile ku thoriwa loku landzelaka ka Swirho swa Vatirhi swa Vahlawuriwa lavo Siva:
Leswi, tanihi leswi ndzi swi vonisaka swona, swi onha mitwanano yo so sungula.
Leswi hi leswi xinawana xi lavaka ku endla swona.
11. Hlamusela eka fomo ya xikombelo loko mpfumelelo wu ta landziwa kumbe u ta rhumeriwa wona hi imeyili.
Xana leswi swi ta cinca lembe leri hakunene xana?
Ku vuyisela vululami ku fanele ku va swin'wana leswi hi faneleke ku swi kongoma.
Nawu wa Rihanyo na Vuhlayiseki bya le Mintirhweni na Swinawana
lowu wu nga mahala kambe wu katsaka tiatikili na swihlawulekisi swi nga ri swingani.
hefemuriso wa nomo
ku katsa ni ku tirha tanihi poso
Loko u nga rhijisitariwangi a wu kona.
Xivutiso xa vumbirhi xi fambelana na mitlhontlhonkulu
Tifotokhopi a ti nge amukeriwi.
xiphemu lexi xi ringeta ku lavisisa leswi swi nga vangekaka faneleke ku endliwa ku nghenela eka CBP
Malulamisele man'wana na man'wana ya tava yari hava xisolo eka mphakelo wa tsalwa ra 40.
Va na ntsengo wukulu wa mivulavurisano yo tirhana na yona.
swa tirha na swin'wana
Hundzuluxo i nchumu wa kahle eka mhaka yin'wana na yin'wana.
chati ya mpfumawulo
Hikokwalaho hi swi teka ku swi fanele ku tirhisiwa hi ku hatlisa.
Hambiswiritano, hi lava na ku tisa ndzavisiso ekusuhi na vaaki.
Go tshwanetse ga nna le ditherisano
Lavisisa tindlela na tinxaka to hambana ta maasesele.
Xandla xa Phuresidente wa Riphabuliki ra Afrika Dzonga, Manana.
Hambiswiritano, nkateko wa kona, va lemuke leswaku xitsongwatsongwana xa ha ri na matimba kambe a xi na chefu.
Tanihileswi sisiteme ya eneji yi hundzuluxiwaka, mikarhi leyintshwa yi ta fika yo tumbuluxa.
Tiprojeke ta mbhasiso ta tsevu tintshwa ti sunguriwile.
handle leswi nga rhumeriwa.
Ntlawa wa hina wu vhotile wu kaneta xiboho xo hetelela eka xiviko lexi.
Sweswo ndzi ehleketa ku ri a swi ta va leswi nga amukelekiki eka un'wana na un'wana.
Ku nga hakeriwa na le tihofisini ta va Ndzawulo wa ta Vurimi leti nga longoloxiwa ehansi ka nhlokomhaka ya Ku tihlanganisa na ndzhawu.
Hi ntiyiso leswi swi lehile swinene.
Hi tikombisile leswaku hi nga fikelela swin'wana swa kahle loko hi tirha swin'we.
Vutirhisani lebyi a byi le xikarhi ka mimfumo leyi minharhu ntsena.
Leswi hi leswi a ndzi navela ku mi byela.
2. Ku tsala hi mfanelo loko ku ri leswaku wadi yin'wana na yin'wana yi hlawurile swilo swo karhi, hi ku boxa ntikelo (kumbe leswi rhangisiwaka) lowu fambelenaka na mhaka leyi faneleke ya wadi yin'wana na yin'wana (kusuka eka 0- leswi nga boxiwangiki ku ya fika eka 5- leswi nga na nkoka).
Kutani mbuyelo hi wihi?
Xikombiso, mali ya mpfuneto wa vanhu na mapasi sweswi swi teka nkarhi wuntsongo ku endliwa.
Yuropa yi nge ali ku twa swirilo swa vona.
laha sayizi ya tiwadi yi fikaka laha yi koxa ku tlula mpimo swirho swa huvo leswi nga na vutihlamuleri bya photifoliyo yo karhi
Lexi na xona hi xona xivangelo xa ku va khomferense yo languta hi vuntshwa yi ri ya nkoka swinene.
Xiyimo: Ku katsiwa ka swa rimbewu eka tiphurojeke ta nhluvukiso
A ndzi ri karhi ndzi vulavula nkarhi wo leha swinene.
hambanyiso wa muhlovo
Vanhu va khume va vavisekile, laha vanharhu va vona va nga eka xiyimo xo kala xi nga tsakisi.
Kambe sweswo swo va mali ntsena.
Xa masungulo
Kutani, i swa nkoka leswaku hi langutisa eka swiyenge leswi.
Va ta tlhela va pfuna ku lunghisa mavoni ya switarata.
mi nga honisi vukungundzwana.
hi nge anakanyi ntsena matimba ya nyutliliya ku hangalaka.
tinyawa to oma
Europe ri fanele ku vula swo tlula makete.
Kambe e-e, i mhaka ya mayelana na ntirhisano wa malawulelo.
ku pimiwa loku amukelekaka
Kanerisanani hi xitatimente lexi hi vuxokoxoko.
xiyimo xa switandadi swa swtindlu.
Mfumo wa xifundzankulu wu ta ya emahlweni wu hoxa tihlo leri faneleke eka mhaka ya vugevenga.
Xiendleko xa 3 xa CBP
Ntirho wu fanele kuva wu fanerile eka malembe ya vadyondzisi.
Ku lemuka vutshunguri bya xintu na mimirhi.
i ntirho wa yena ku rhamba tinhlengeletano ta tikomiti ta tiwadi;
Hambiswiritano munhu wihi kumbe wihi loyi a vonaka swilo tanihileswi swi nga xiswona wa swi tiva leswaku leswi a swi nga ta humelela.
Hi ta veka magoza yo hunguta ku lahlekeriwa ka hina hi mati hi hafu hi 2014.
naswona hi fanele ku yi khutaza.
Switshunxo swa nkarhi wo koma swi nge tiyiseleki eka nkarhi wo leha.
Ndza khensa swinene ku pfapfarhutiwa ka dokhumente leyi.
kanela na muringani wa wena na mutirhi wa swa rihanyu kumbe mutsundzuxi hi
Sweswo hakunene hi leswi muviki a nga eku swi xiyaxiyeni sweswi.
I nkarhi wo tsakisa eka vona na le ka hina.
xo hetelela ndzi lava ku hoyozela IUCN.
xikombo xa masungulo xa boha.
Burisana na vatekaxiave hi vuxokoxoko lebyi kumekaka eka Kavanyisa ka 3 va nga si endla nghingiriko lowu.
kambe swa tihakelela.
loko u ehleketelela leswaku munhu un'wana u xavisa swidzidziharisi)
vuxeni
mpimo lowu eneleke
tshaku
CIPC yi lava leswaku vuxokoxoko bya Khoporexini byi va byi va byi ri bya nkarhi wa sweswi.
Qhinga ri fanele ku:
loko u ri munhu loyi a rhandzaku ku tirhela ehandle
A hi swa xihundla
Loko Masipala wu phakela mati eka ndzhawu yihi na yihi handle ko rhanga hi ku hundza hi le ka nchumu lowu tirhisiwaka ku pima kumbe nchumu lowu tirhisiwaka ku pima wu nga tsarisiwangi
Tindhawu ta vuxa ta xifundzankulu xa N'walungu-Vupeladyambu na tona ti ta vuyeriwa hi kungu lerikulu ra ku vuyeriwa eka xikongomelo lexikulu eka switirhisiwa leswi hlanganisaka na mbuyelo wa migodi na swicelwa.
Laha a hi le London.
Mutirhi wa le kaya, loyi a tshamaka entirhweni
Leswi swi kongomisiwa eka ku tlakusa vukorhokeri hi ku tirhisa mafambiselo man'we ya mafambiselo ya mfumo
U nga ha komberiwa ku hakela tihakelo ta xibedhlele ta manana na n'wana.
Hi ndlela leyi khomisaka tingana, ku na swo tala ku va swi sirheleriwa ehenhla ka xona.
vugevenga bya mhangu ya xihatla: 10111
u fanele ku vona leswaku u kuma rhisiti ya ku hakela.
Laha, na kona, u le ka xiyimo xo tika ngopfungopfu.
Muxavisi u ta pfumeleriwa ku:
Swoleswo a ku ri nhluvuko lowu amukelekaka.
Hositele ya vatirhi
Ehandle ka xikweleti lexi, xikweleti xa riqingho ra masipala a xi ri ehenhla swinene ku katsa na nhlengeleto wa nkwama wa mfumo lowo tsana swinene lowu siyeke masipala a ri karhi a tshwimbirisana no hakela swikweleti swa wona.
Xiyimo eka tiko leri pfulekeke xi tlhela xi tika swinene.
Xivilelo eka matitwelo ya vahlayi.
Naswona mfumo wa hina wu ta tshama wu langutisa leswi humelelaka eKenya, Chad, Burundi, Darfur eSudan, Sahara Vupeladyambu, Cōte d'Ivoire, Somalia, Comoros na Central African Republic ku kuma ku rhula loku nga heriki na ntshamiseko.
Kambe sweswo a hi xileswi swi hundzukeke ku va xiswona.
Kutani hi leswi saleke.
Ku cinca ka vunharhu ku mayelana na hundzisiwa ka xileriso.
A hi voneni lavan'wana.
ku laveka khopi leyi amukeleke ya fomo ya CK7 ku nghenisiwa na xikombelo xa ku cinca.
Kutani kuma phanele ya vativi ku ahlula mianakanyo leyi.
leswi a swi nga tumbuluxi mitirho yihi na yihi yintshwa.
Loko u endla ku cinca eka Khoporexini yo Pfaleka (CC), ku fana no thola mutirhi wa swa tinkota, ku cinca kherefu, ku cinca tiphesenteji ta minkavelo kumbe ku engetela kumbe ku susa xirho, u fanele ku ku cinca vuxokoxoko bya khoporexini eka Khomixini ya Tikhamphani na Timfanelo eka Nhundzu (CIPC).
Loko leswi ku ri leswi u swi ehleketaka
A hi vonanga vumbhoni bya swona.
mitirho ya swa vuxongi
Misava ya mfumo
Ndhawu ya ku velekiwa
ku ntswontswana hi ririmi
Ku hava na xin'we lexi cinceke mayelana na mhaka leyi ya nkoka.
Xiphephana lexi xi lava ku nyika mahungu laya nga ta pfuna vathori na vatirhi eka vurimi na swihlahla ku tlakusa rihanyo na vuhlayiseki na tinghozi ta rihanyo leti fambelanaka na ntirho eka xiyenge xa vona.
Hi tlhelo lerin'wana, mbangu lowu wa tsekatseka hi ndlela yo tivikana.
Xana wa tshembha leswaku swi tano?
nxungeta-vutomi
Ndza khensa ku va ndzi pfumeleriwile ku nghena na xivutiso lexi.
Hi fanele ku langutela vanhu ekusuhi swinene.
a hi hetisangi endlelo rero hi 2006.
ngopfungopfu leswi swi nga kunguhatiwa hi mfumo wa muganga)
Ku vile lembe ra nkwetlembetano, ngati na mafu.
Hi xivangelo lexi, Phepha leri humesiweke ri ni swivutiso swa nkoka eka leswi landzelaka:
Tifuloro ta tipulenamu ti ta va xin'we xa leswi landzelaka:
Leswi swi tekile ndhawu ku lwisana na masungulo ma swikoxo leswikulu swa le makaya.
Ndzi tsakile ku lemuka hilaha swikombiso leswi swi tekeriwaka hakona enhlokweni.
2001 ri vile lembe leri tikomiti ta tiwadi to tala ti tumbuluxiweke harona, laha ku lemukiwa ka mhaka leyi ka xiyimo xa le henhla swinene ku nga Western Cape na KwaZulu-Natal laha mifumo ya swifundzankulu hi ku angarhela yi hlawuleke ku ka yi nga vi na tisisiteme ku kondza ku fika 2004.
swi endliwile hi ndlela ya nawu ku nyika xiave lexi vonakaka eka misinya ya Vumbiwa leyi vatirhi hinkwavo va languteriweke ku landzelela Khodi ya Matikhomelo leyi nyikiweke eka Swinawana na ku tlhela va languteriwa ku tirha mitirho ya vona hi xiyimo xa le henhla swinene ku ya hi vuswikoti bya vona
Hi nga kota ku kuma nkoka wa nxavo lowu aviweke, kambe hi nge koti ku kuma nkoka wa ntiyiso kumbe vutshembeki.
Xaxameta no tiva swiyenge.
Swi le rivaleni.
Ndza tshemba leswaku leswi swi nga fikeleriwa.
Nhlayo ya vanhu va misava
tikiso
kongotlo
Xana u yima njhani ku mamisa hi switsongotsongo?
Sweswo ndzi ehleketa kuri swi le rivaleni.
lebyi i vukorhokeri bya vanhu byo pfumala mindzilekano.
Leswi a swi nga ha endleki eka nkarhi lowu taka.
Swikombiso swi kombisa leswaku tikhoto to hlawuleka ti tirha hi ndlela ya kahle.
Ndzi ehleketa leswaku hi le ka vutlharhi bya miehleketo bya makete wa le ndzeni.
Dyondza no tirha hi ndlela ya kahle, u ri wexe swin'we na van'wana;
Xin'we eka tsevu xo va xi nga ri kahle hi ku enela.
Swoleswo ndza tiva mayelana na swona.
Leswi, hi mavonelo ya mina, hi swin'wana leswi faneleke ku yisiwa emahlweni.
munhu loyi a tshamaka eka yindlu leyi a nga ha endla xikombelo xo xava ndzhawu leyi yo hirhisa.
22:
Tinhlamulo to koteka ti katsa:
Xana a hi langutisi ntsena eka tindhawu ta matikoxikaya?
32% wa vanhu va ka hina a va kota ku fikelela gezi.
Naswona hi fanele ku lwisa ku cukumeta ka swa vanhu na ikholoji.
Sweswo a swi tikombi yi ri mhaka leyi nga eka ajenda.
Ku dzuneka ku ya eka n'wina hinkwenu.
xikwata
Ntshunxeko wa ku vulavula a wu kona.
ku rhukurha ka xitombo
Hambiswiritano, mali yo tala ya ha laveka eka vulavisisi na nhluvukiso.
Hi na xivangelo xa kahle xo vekisa ku tshemba ka hina eka dyondzo.
hi ta tirhisa tindlela hinkwato ta mfumo tanihi makumele
Ndzi ni ntshembo swinene eka nongonoko lowu.
Endla xikombelo xo pfumeleriwa hi Mutsarisi wa Maantswiselo ya Swifuwo ku tundza swifuwo kumbe switirhisiwa swo fana eAfrika-Dzonga.
U fanele ku yisa xivilelo xa wena eka Holobye wa Xifundzankulu wa Nhluvukiso wa Vanhu ku nga si hela masiku ya 90 endzhaku ku aleriwa ka xikombelo xa wena. (Vona Nawu wo Tlakusiwa ka Mafambiselo ya Vululami, pheji ya 10).
xiphemunene
Swikombiso swa nga katsa:
Ndzi nga pfumelelana ni milawu leyi kunguhatiweke ntsena.
Hofisi ya Holobyenkulu
Ku endla swikombelo swa mitirho.
Ku hluvukisa kungu ro tirha ra wadi
Vundzeni 8
Ndza tshemba leswaku swi fanerile swinene ku amukela vonelo leri.
Swi kombisa pholisi ya Mfumo naswona yi heleketiwa ePhalamende kuva yi amukeriwa.
Vamanana na vatatana, xiboho i xa n'wina.
Goza ro yisa emahlweni kunene ri endliwile.
muguduki
Ku humelela ka mavabyi.
Leswi hinkwaswo i swilo leswi ndzi nyikaka xivangelo xa nkhumbeko.
Kanela na wena hi leswi u nga swi endlaka ku sirhelela n'wana wa wena eka mitlulelo ya HIV.
Ku avelana i mhaka yin'wana
hi le ku tirhaneni na swilaveko swa mpimo wa le hansi.
ku ya eka endlelo ro va na xivono ku ri karhi ku langutiwa laha vaakindhawu va tsakelaka ku va kona na leswaku va nga fika njhani kona.
Va lava ntsena vukalaxihundla.
Swi tirhela swilaveko swo hambanahambana swa vadyondzi.
U fanele ku va u ri na setifikheti ya movha loyi nga tshama u kamberiwa ku pfumeleriwa ku famba epatwini u nga si wu rhijisitara hi vito ra wena.
Lexi i xikombelo xa ntiyiso.
Swo tala swi humelerile himpfhuka ka swona.
Ku humelela loku landzelaka ku tekeriwile enhlokweni:
Lawa hi man'wana masungulelo.
Vuxaka exikarhi ka tinxaka i mhaka leyi vilerisaka.
MALI LEYI TIRHISIWEKE YA XIVIRI
swi fanele ku tshikileriwa
Xikombiso xa nxaviselano
Loko xikombelo lexi nga fanelangiki xi endliwa
Figara ya 3.5 yi kombisa ku ndlandlamuka kutsongo ka 33,9% wa vanhu lava nga eka vukhale bya 20 wa malembe ku ya ehenhla lava nga hetisa tidyondzo ta vona ta sekondari loko ku fananisiwa na 30,85 hi 2001 na 33,6% hi 1996.f
hi ku landza vuswikoti lebyi nga kona na switirhisiwa
Ku tlakusiwa ka mafumelo ya kahle eka matikhomelo ya timhaka hinkwato ta mfumo.
Hi fanele hi tlhela hi endla qhinga ra rixaka ra mavabyi lama hetaka nkarhi wo leha.
Xiphemu xa 2 - Twisisa na ku lulamisa
Ku languta endzhaku
Swiphiwo leswi swi katsa:
Hikwalaho ka leswi, ku simekiwile phurojeke ya ndzingeto.
Kambe FDI a yi se tshama yi olova ku va kona.
Swa kanakanisa kumbexana
tindlela tin'wana ta ku kambela nhlohlotelo wa minonongoko ti katsa
Hlamusela tiayitheme leti faneleke ku katsiwa eka makanelwa ya nhlengeletano.
Hinkwerhu hi xiphemu xa xipano naswona hi le ku tirheni swin'we kahle.
ku hlawuriwa ka mutshamixitulu wa SADC.
Timhaka tin'wana timbirhi.
Nhlayo ya le henhla ya milandzu yi ololoxiwa ku nga si hela tin'hweti tinharhu.
Ndza tshemba leswaku hamambirhi ya maendlelo lama ya hoxekile.
Vuvabyi bya chukela i ntungu wa misava hinkwayo lowu nga na mitshikelelo leyi onhaka swa ximunhu
VULAVULA HI KU HETISEKA
I nchumu lowu hakunene hi nga wu laveki.
Xana u nga hlamusela?
boboma
U ti endlerile ku tinyungubyisa hi wexe namuntlha!
leswi swi mayelana swinene na vukalaxihundla.
Vukanganyisibyo tika no pfilungana (bohana).
Kahlekahle swa laveka.
mfungho wa vito ro doroba
i swa nkoka leswaku xi xaveriwa makumu.
Leswi swi ta lava.
Ndza tshemba sweswo swi ta va ndlela yo tivikana ku ya emahlweni
Swi le ka nxiximo wa vona kuva hi yimile laha namuntlha.
Swi tano swi humesa mitlhontlho yin'wana, yo tanihi mhaka ya mapasi.
Ku tiyimela kuntshwa hi leswi hi swilavaka.
Loko DLTC yi ri na xiyenge xa ku teka vuxokoxoko lebyi rhekhodiwaka (LCU)
1994 [Nawu 23 wa 1994]).
Hi swona swi endlaka leswaku hi vulavula hi mimpimo hi ndlela leyi rhangelaka xiyimo.
Swi na nkoka leswaku swirho swa Komiti ya Wadi va twisisa nawu lowu fambelanaka na Tikomiti ta Tiwadi, na hilaha ti faneleke ku tirha hakona.
Hi ku kongomisa a ndzi ta tsakela ku tshikelela timhaka timbirhi.
vanhu lava nga etihotela ta vapfhumba
Nesta Mosia wa makumenharhu wa malembe hi vukhale, loyi a nga tirhiki, a a ri un'wana wa lava nga kuma yindlu yintshwa.
Swoleswo, hambiswiritano, ku to va ntsena swintsongo swinene.
Ndzi pfumeleleni ndzi kombisa minhluvukiso na matshalatshala lama landzelaka:
A ndzi ta tsakela swinene nseketelo wa wena eka matshalatshala lawa.
Ndza tshemba leswaku swi ta kuma nseketelo wa wena.
Dyondzo leyi a yi bohi.
Nawu wa tihakelo ta Nhundzu ya Masipala wu hundzukile nawu ku sukela hi 2 Mawuwani 2005.
Nyika swakudya ku ringana ka 2 ku fikela ka 3 hi siku
Xivutiso lexi tumbulukaka i: Xana matirhelo ya khoto a ya fanele ku pimisiwa ku yini?
Eka swiyimo leswi swirho swa komiti ya wadi swi averiweke tiphotifoliyo
nhlamuselo ya leswaku xana munhu loyi u khumbeka njhani eka ku hanya kahle ka muxanisiwa
Kumbe ku nge si va ni sweswo
Kanela swintshunxo eka mintlhontlho ya thyakiso wa mati.
A nga swi tsakeri
Tindlu to tala ti onhiwile swinene, Bloemfontein yi nga ngheneki ku ringana masiku manharhu
Miako i khokho ra ikhonomi.
Leswi swi yimela 7,4% ya GDP.
Sweswo swi tlhela swi vumba xiphemu xa rimba ra swa nawu.
Eka nkarhi wo koma
maendlelo yo landzelerisa na ya nkambisiso... malulamiselo ya mpimanyeto
Xana hi rihi vito leri tivekaka ngopfu ra tiswichi leti ti tirhisiwaka eka xitoloveto lexi?
Hosi
Xana tiinthavhiyu ti ta endliwa njhani?
ndzawulo ya mfambiso
Leswi swi ta tiyisisa leswaku tisisiteme ti ta tirhisiwa ku fana eka tikhemphasi hinkwato.
Leswi swi ta tlhela swi ku lulamisela ku kota ku hlamula swivutiso swin'wana ni swin'wana.
Mupfhumba
kumbe Maphorisa ya Afrika Dzonga ya nga nyika mahungu hi tinhlayo ta vugevenga.
Loko swilaveko leswi hinkwaswo swi fikeleriwile, mpfumelelo wa nyikiwa.
Malulamisele yo tano a ma ringanelangi naswona a swi le ka ntsakelo wa vakhandziyi.
ntwanano wu na nkoka swonghasi.
Swi ta va swinene eka hina hinkwerhu.
Vulawuri bya ku cinca eka phurojeke hinkwayo. 'Ku khapa ka vuanami' hiloko ku cinca lokutsongo kotala ku endliwa loku yisaka eka vuanami byo hambana swinene ku suka eka lebyi a byi languteriwile eku sunguleni naswona ku tala ku va xivangelo xa ku tsandzeka ka phurojeke.
kumbe va swifundzankulu
Xana ku na xivulavuri lexi xi seketelaka xikombelo lexi?
tirhela 'kumbe' yisa ', mayelana na ku vulavurisana kwihi kumbe kwihi, swi nga ha vula-
Ku na vumbhoni bya leswaku ku katsa ntirho na ku mamisa vele swi na mbuyelo wa kahle eka manana
Meno ya tiyile swinene ku tsema.
Vuswikoti byo tirhisa khompyutara; ni
Ku Dyondza Hi ta Mfumo wa Miganga, 2006. Pj nkongomelo wa 2
Exikarhi ka yin'wana Nawumbisi wa Khomixini ya Mfambiso wa Misava
2.1 Ku hlamusela nkunguhato lowu simekiweke eka vaakindhawu
Ku na tindlela to hambana ku fikelela mitlhontlho ya dlilobalayizexini.
Swimakiwa hinkwaswo swa tiko
Tin'wana na tinhlokomhaka leti Michelle a nga tirhana na tona a ku ri ku hlawula titlilayente ta wena (va lavisisi no asesa nxungeto wa ku tirha na vona), mafambiselo ya nkhuluko wa mali ya wena (ku londza swikweleti swi sungula hi swilo swo fana birifi ya phurojeke na hakelo ya wena, leyi nga riki na tiakhawunti leti ta ha faneleke ku hakeriwa) na hilaha u tirhanaka hakona na tin'wana ta tinxangu ta ntolovelo ta ku nga lavi ku hakela.
ndzi tshembha leswaku mikanerisano yoleyo yi fanerile.
nomboro yitsongo-tsongo
I mhaka ya vululami.
A swi kanetanani na swona naswitsongo.
Swi ta tlhela swi tiyisisa leswaku Afrika-Dzonga ri humesa mivuyelo leyi yi fambelanaka na rirhandzu ra rona ra xiviri eka mitlangu.
Khabinete yi seketela ku thoriwa ka Huvo leyintshwa ya Mati eSedibeng
Ku katsiwa ka mimpimo ya rihanyo na vuhlayiseki eka swinawana.
A hi fanelanga ku tshuka hi egetile ku onhakeriwa lokuya.
a ri loyi a nga wa hikwalaho ka swikweleti a tlhela a nga kumi ku pfuniwa; kumbe
Ndzi ehleketa leswaku a swi fambelana na vuhlayiseki na vusirheleri.
Hambiswiritano, ku hundzisa loku ka vun'wini a ku langutisisiwanga hi vuenti eka nkambisiso lowu:
Ku tshika ku dzaha.
i xivutiso xa ndzinganano.
Makunguhatelo ya Masipala na Swipimelo swa Mafambiselo ya Matirhelo, 2001
Xana u na switirho swihi kumbe ku kota kus wi kuma? (xik. switirho
Mhaka yo olova ya timakete ta vatirhi na yona i xikombiso xa kahle.
U nyikile mavonelo ko tala hi ntirho wa vateki va mahungu.
hi leswi kungu ra masungulo ri nga xiswona.
Xindzhuti xa vumunhu xi ni nkoka ku tlula mali.
GTZ Ejensi ya le Jarimani ya Ntirhisano wa swa Xithekiniki
Komiti ya Huvo ya Rixaka eka Vutshila na Ndzhavuko yi rhamba lava khumbhekaka na mihlangano leyi nga ni ku tsakela ku rhumela swibumabumelo leswi tsariweke hi Nawumbisi lowu boxiweke laha henhla.
Hi byihi vukorhokeri lebyintshwa bya tiko hi byi tekeleleke?
Milawu ya mabindzu yi fanele yi tirha ntirho wa yona eka vundzeni bya mhaka leyi.
xihambanyisi
(Nhlokomhaka: Ku oma swirho swo tala, i xiyimo laha masocha ya miri ya hlaselaka misiha, xi nga hundzeleta xi fika laha loyi a vabyaka a nga ha swi koti ku ololoka a hetelela hi ku tirhisa whilichere.)
Kutani ndzi pfumeleleni ndzi vula ku khensa ka mina ko hetiseka na le ka vona
yindlu
Nawu wo rhwala nhundzu hi movha wu ta va ni mbuyelo wa:
layini yo avanyisa
Ndzi ta hlamula swin'wana swa swivutiso swa wena.
Ka ha ri ni mitlhontlho eka ndhawu leyi tanihi leswi vukorhokeri bya laborhetari byi nga fikelelekiki.
u ta tivisiwa loko ku ve mfumelelo wu ta nyikiwa hi muxaka unwana.
Makungu lawa ya kongomeke vanhu na ku va antswisela;
hi fanele hi endla swin'wana.
Loko ha ha ri na ku tikeriwa loku, ha swi tiva leswaku hi nga tiyisela eka nkarhi lowu wa nhlupheko.
leswi nga kulaka swi tiya swinene.
U kayivela masaka ya 10 ya swinonisi, lama nga tivekiki laha ya nga kona.
B a nga tirhisiwa ku rhumela na ku amukela tiemiyili.
swiyimo
Nongonoko wa hundzuluxo wu kongomile eka tlhelo leri nga rona.
a xi humelelangi hakunene hi ndlela leyi.
Toya ri vutisa xivutiso
Vuswikoti bya xipfuno lexi xi ta tlhela xi pfuxetiwa.
Swa laveka swonghasi leswaku ku dyondza ririmi swi seketeriwa.
Swa olova ku titivekisa na vona.
I xiboho lexi hi ntiyiso xi nga xa vatirhisi.
Hambiswiritano, nawu lowu wa mahanyelo a wu bohi.
Xivutiso xa vumbirhi i ku
Ku nga va ndlela yin'wana na yin'wana ya thekinoloji kumbe swa mirhi.
Ndzi ta tsakela ku nyika xikombiso xo tiya xa leswi.
Hi ku landza swiyimo, mukamberi a nga lava ku rhumeriwa vayimeri vo tala, hambi loko ku ri laha nhlayo ya vatirhi yi ri ehansi ka 20.
Ndzi mi nkhensa nakambe eka mikunguhato hinkwayo.
Kambe xana leswi swi olovile ngopfu ku swi endla?
Hambiswiritano, xana i yini lexi hakunene u faneleke ku xi vula?
xana a ndzi ta hoxa njhani?
Tiko ro Sungula ku vika eka Komiti ya Nhlangano wa Vativi va Afrika eka Timfanelo na Nhlayiseko wa N'wana.
ya vanhwanyana a ma endli tano.
Ntlawa lowu a wu nga vi ndhawu yo vulavula ntsena.
mutirhi a landzelerile xitiviso xa nawu, (xik. yirisa, xitiviso xo tlula nawu, na swin'wana)
Ku nghena ka klayente: Ku amukeriwa ka klayente eka rejistara ya vaendzi
Hlamusela, loko swi koteka, mbuyelo.
Hikokwalaho ku hava xivangelo xa ku hlwerisa ku ya emahlweni ku hangalasiwa ka mavuthu eka ndhawu yo karhi.
Xo sungula i xa swa mbangu kasi xin'wana i xa swa tipolotiki.
mfungho wa vuandziso
3.2. Khabinete yi pasisile Nawumbisi wa Maantswiselo ya Khomixini ya Vukorhokeri bya Mfumo leswaku vaaki va nyika mavonelo na ku nghenisa Nawu wa Maantswiselo ePalamende.
Switoloveto eka ku tirhisa xtirhisiwa swi fanele ku endliwa hi mikarhi yo nghenelelana.
nhlamuselo leyi nga erivaleni ya nsinya wa ku siva.
Yi lava leswaku hinkwavo lava hehliweke va tengisiwa hi ndlela leyi tengeke ekhoto eka vubihi lebyi va hehliweke ha byona.
A ndzi ta tsakela ku pambula xiphemu xin'we xi ri xoxe.
swilaveko swa mbulavulo
ndzi teka nkarhi lowu tanihi lowu nga hlawuleka.
xendlo xo tereka
Goza 4
Vavuyeriwa va nkwama a hi swirho swa nkwama.
ku lwisana na vugevenga
Munhu wihi kumbe wihi la susiweke eka hofisi ya ku va Holobyenkulu hi ku landza xiyengentsongo xa kumbe a anga amukeli nchumu swa hofisi yeleyo, nakona a nga ha tirhi eka hofisi yihi na yihi ya vanhu.
Ndzi ehleketa leswaku sweswo i swa nkoka swinene eka hinkwerhu ka hina.
-tlakuseki
Hlamusela hi komisa hikwalaho ka yini leswi kuva xiphiqo xo tika eka khamphani ya hina.
Xiviko xo koma xa ku langutisisa Vito ra phurojeke
Humesa eka inthanete no tata fomo ya xikombelo hi ku helela hi duplikheti.
Ku pfukelana matimba loku ka ha ku vaka kona eAfrika-N'walungu i xitsundzuxo lexi nga lo tlangandla erivaleni, xa mixungeto ya mafumelo ya xiyimo xa le hansi na mihlangano yo tsana leyi pfumelelaka lava nga na swa vona ku hlengeleta rifumu hi ku pfumata vanhu.
hi vulavurile hi mayelana na endlelo ro angharhela eku sunguleni.
Hambiswiritano ha fana tanihi munhu un'wana na un'wana wo karhi laha.
Loko xiboho xa executive council xi ri lexi pfumelelanaku na xikombelo, registrar u pfumeleriwile ku humesa phemiti.
ku sirhelela no yisiwa emahlweni ka vanhu, kumbe lava a va nga vuyeriwi hikokwalaho ka xihlawuhlawu xo ya hi nghohe.
Nomination to act as executor/ Nomination form -yi fanele ku tatiwa hi vadya ndzhaka va mufi ku langa muyimeri wa Master of the High court.
Ndzi vulavurile hi mhaka ya pholisi ya nsirhelelo eka xiviko xa mina.
rikhwakhwa
Khabinete yi tiyisisile leswaku mfanelo yaleyo yi fanele ku tirhisiwa hi ndlela yo pfumala madzolonga no landzelela nawu hi ku hetiseka.
Mhaka ya nkoka yo hetelela i ku langutisana ni xitshunxo.
Swivekiwa swa swotirhisa swa masipala swi kongomisiwa eka maAfrika zonga lava nga na mfikelelo wa vukorhokeri bya masipala meka vaakindhawu va ka vona hi ndlela yo koteka.
Xana hi ntiyiso swi vula yini?
eku heteleleni
yuniti ya tinhlayohlayo
Tumbulaxa ntirhisano wa vumaki.
TiCDW na tikomiti ta tiwadi ti nga vumba vuxaka lebyinene hikuva:
Ku na leswi kotekaka swimbirhi.
khume nkombo
komiti ya wadi a yi nyiki foramu eka muyimelakulanghiwa loyi a lahlekeriweke hi tivhoti ku tshamela ro lwela nhlawulo wa ka masipala hilaha swi nga heriki.
kambe leswi i matlhari.
ku tlovota eka ximatsi eka mouse ya wena eka linki ya dokumende leyi u lavaku ku yi hlayisa.
Hlamusela loko ku hlundzuka ka wena ku fanerile, hlayisekile na ku va kahle ku endla tano.
Vayimelakulangwa va nga kongomisa eka xifaniso na vona.
na ndlela ya ku pima na ku landzelerisa ndzima / nhluvuko lowu nga endliwa eka tlhelo leri.
Ku chayela movha lowu wu nga tsarisiwangiki epatwini ra Afrika-Dzonga
75% wa mindyangu yi rhangeriwa hi vavasati lava holaka ehansi ka R 500 hi n'hweti
Ndzi seketela muteki wa mahungu eka ku antswisiwa loku a ku kunguhateke.
Tanihi leswi ku nga na swivutiso swinharhu ntsena
Xirho xin'wana na xin'wana xa ntlawa xi fanele ku vhota naswoana va nga 'vhota' hi ku vekela mfungho wun'we kumbe yo tala etlhelo ka mbuyelo lowu languteriweke lowu va vonaka leswaku wu fanele ku rhangisiwa emhalweni.
Loko swikongomelo a swi ri erivaleni
Sisiteme ya Vuavanyisi
Swinawana swo Lawula Huwa eGauteng
Tinhloko ta matiko va na ntirho wukulu eka mhaka leyi.
I vugevenga ku tirhisa tindlela to tsemakanya leti nga riki enawini. I mhaka ya nkoka ya masungulo eka mphikizano wun'wana na wun'wana.
2.8 Ku antswisa nseketelo eka mabindzu lamantsongo hi, exikarhi ka swilo swin'wana, ku tumbuluxa xitolo xa yimo wun'we no khomeka xa mabindzu lamatsongo (ti-SMME).
Tinhlengeletano ta Bodo
Kapa
thiriliyoni
Mimpimanyeto ya Swihlovo swo Pfuxeta hi vuntshwa Gezi i ku Fikelela Matirhisele ya Gezi ya Misava.
Hi tshama hi ri karhi hi tsundzuka ndzhaka ya hina yo tiyisela.
I mhaka yo tsekatseka
Ndzi ehleketa ku ri ku ni vanhu vo ringana ku vhota laha.
Hialaha minkwetlembetano eka nhlangano yi nga ololoxiwaka ha kona.
Ku hava xivangelo xo chava n'wangulano na ku rhula.
hina ntirho wo tala ku wu endla.
Swi teke tanihi ndzhaka ya wena yo suka eka hina
leyi yi lavaka ku pfuneta vahumelerisi va tifilimi va laha kaya eku humeleriseni ka timhaka ta laha kaya.
Kumisisa hi mayelana na makumu ya rendzo
Mhaka ya ntiyiso ya ku va hi ri ku endleni leswi i ya muxaka wa yona yoxe.
Ndzi ehleketa leswaku leyi i mhaka ya nkoka.
Swiphiqo leswi
tanihi mfanelo wo hanya eka mbango lowu nga na rihanyo lerinene
Ku pfumaleka vutiolori.
gwitsirisiwile / tihlampfi to titimela / na swin'wana
Ku onhaka ku ngava ku herile kumbe ku nga helangi.
Va tlhela va ringanyeta leswaku tiphurojeke letikulukumbanyana ti endliwa hi IDP
Hi lexi naswona a ku na xin'wana xo karhi lexi hi nga ku xi kaneleni.
Nkarhi lowu hi nga humelela
Ku tiboha ku landzelela
Swoleswo a ku ri kungu laha mpimo wu nga fikeleriwangiki.
Leswi swi titshege hi maendlelo ya xifundzhankulu.
yo tanihi mhaka ya mapasi.
fowunela matsalani eka 012 393 2500 kumbe 012 393 2536
Ku honisa swilaveko swa rihanyu
U hlamusela leswaku bindzu rakwe ra tikonta na mitirho yakwe ya nhlangano swi na nkoka swinene ku tlula ku rindzela swirho swa komiti ya wadi leswi fikaka nkarhi lowu vekiweke se wu hundzile, loko swi endleka ku tshika ku vile na tinhlengeletano ta wadi.
n'wana wa wena na muringani wa wena mi tshama mi hanyile kahle.
kun a misinyankulu leyi ehenhla ka yona hi nga ta tshembela.
Yuropa yi kula swin'we
Lexi i xiyimo xa kahle.
I swa nkoka leswaku swakudya swo sungula leswi n'wana wa wena a swi dyaka swi va swi ri henhla hi ayoni.
Ku tlhela ku ri ni xidingo xa switirho swa nseketelo wo karhi wa swa timali.
Hinkwerhu hi tshemba eka tisenthara ta vuswikoti eka dyondzo.
Hikokwalaho ndzi ta ringeta ku lulamisa swivilelo leswi.
Loko swo hatla swi va kona, swi ta antswa.
Xa vuntlhanu, mafambiselo ya chayeni ya mphakelo yi fanele ku tiyisisiwa.
Vuvekisi eka timakete leti hlayisekeke
Ntirho wa swirho i ku:
Swi njhani ke?
Xiviko i xitiyisiso xo amukeriwa hi mfumu eka xikambelwana xa matirhele ya tiko no yimela swikongomiso swa nkarhi lowu taka leswi nga boxiwa eka Pulani ya Nhluvukiso wa Rixaka.
U endlile mhaka ya nkoka eka mikanerisano leyi nga va kona.
Batho Pele i xivuriso xa Xisuthu lexi vulaku leswaku Vanhu ku Sungula, leswi swiboha vatirhela-mfumo leswaku va tirhela vanhu hinkwavo va Afrika Dzonga.
Mitirho, hi ku vona ka mina, i ya nkoka tanihi ntshamiseko wa mixavo.
3.2.1 Ntirho wa Komiti ya Wadi
Humesa vumbhoni bya mpfumelelo wo tshama minkarhi hinkwayo.
Vumaki byi dinga ku sungula eka levhele ya purasi hi tlhelo ra vatirhi.
Sweswo hi leswi ndzi swi tivaka.
a hi na bindzu tanihi ntolovelo.
A hi fanelanga ku hluleka hi rin'wana ra matlhelo
Swi khomisa tingana ku ku na ku cinca ko tala swinene.
Swiviko leswi swi ta fikisiwa eka yingiso wa Komiti ya Ndzhaka ya Misava.
A ndzi tilunghiselanga ku hlamula swivutiso hinkwaswo leswi vutisiwaka.
Handle ka sweswo, hi tshemba leswaku xiviko lexi i ku paluxa ka kahle swinene.
Leri i goza ro tlhelela endzhaku.
matimba ya munhu
hi fanele ku endla sweswo.
pheji ya 56 ku fika 64
kungu ri fanele ku va ra wadi
[Hi ku pfumelelana na Holobye wa Vululami na] hi ku tivisa eka Gazete,
Ehenhla ka tinhweti timbirhi leti hundzeke, maendlelo ya sisiteme ya VAT ya ximanguvalawa yi sungurile.
Iraq
Ntirho a hi wo olova ku wu endla.
kambe leswi a swo humelela hi xihoxo.
Ku na ndlela yin'wana leyi nga hlawuriwaka.
na hina hi fanele ku angula eka swivilelo swa vaaki.
Hambiswiritano, hi tama ha ha ri na mipfhuka ekule na sweswo.
Timali to pfuneta eka miti leyi nga swela ti fanele ku kongoma na ku va erivaleni hilaha swi kotekaka hakona.
hi khomiwa hi tingana eka mbuyelo lowu.
Ndza eneriseka hi ndzima leyi Ndzawulo ya mina yi yi endleke lembe leri nga hundza.
Ku teka makanelwa swi lava swikili swa ku yingisela na ku katsakanya timhaka.
U vule leswaku ndzi ba riqingho.
Timakete swi nga endleka ti nga rito rosungula kumbe rito ro hetelela eka nhluvukiso wa vumunhu.
Xana u nga hlamusela?
Swi tlhela swi sirhelela rihanyo na nhlayiseko wa vanhu lava khumbhekaka eku tirhiseni ka michini.
Xitatiment eka ku Simekiwa ka Nongonoko wa Maendlelo wa Kenya.
Timali leti nyikiwaka hi ku tirhisa mavonelo lamanene i goza lerinene naswona yi tirha eka migingiriko leyi yi endliwaka hi vaaki ku simeka makungu ya vona, hakanyingi ku va ku ri tiphurojeke.
Swilo swa nkunguhato wa CBP Xiyimo ku simeka
ku nga ha va hi ku kongoma kumbe hi muphameri un'wana wa vukorhokeri
Va-nkwama wa rixaka, hi ku twanana na xirho xa Khabinete lexi nga na vutihlamuleri bya timali ta rixaka, va nga ha yimisa ku hundziseriwa ka nkwama ku ya eka xirho xa mfumo ntsena hi ku endlela vangwa leri xungetaka kumbe leri tshamelaka ku tivonakisa eka magoza lama ya simekiweke eka xiyengentsongo xa (1).
1. Yana eka Xiyenge xa Nsivelo wo Ndlandlamuxiwa xa DAFF enhlalukweni ro nghena etikweni u ya tata fomo yo endla Xikombelo xa xitifikheti xo teka kumbe u yi humesa eka webusayiti.
Leswi a swi ri emasunguleni ya vuvabyi.
Varimi va nge amukeli va karhi va khomiwa hi ndlela leyi.
Ndzi ehleketa leswaku i ku pfumala vutihlamuleri.
hilaha phurojeke yi nga ta simekiwa hakona.
loko ku kula ka ikhonomi loku hatlisaka ku ta anamisa swivandlanene eka hinkwavo na ku endla swipfuno leswi swi lavekaka ku antswisa dyondzo.
Yana emahlweni ku fikela loko swirhendzevutana hinkwaswo swi va endzeni ka swirhendzevutana leswi sukelaka ndhawu yin'we ku rhendzeleka na vaakindhawu ku komba ndlela leyi swi kumekaka hayona.
Xitefikheti xa vukorhokeri bya maendlelo mambe.
Vuxokoxoko byo tala hi mayelana na ntsariso na timali swa kumeka eka webusayiti ya SACAP kumbe u tihlanganisa na huvo hi riqingho eka 011 479 5000 kumbe hi imeyili registrar.rp@sacapsa.com.
Ku nyika sisiteme ta swofamba leswi swi hlayisekeke, to tshembeka na ku fikeleleka b.
Swoleswo swi pfumelela ku katsiwa lokukulu ka vanhu hinkwavo va tiko.
I swa nkoka leswaku leswi swi fambisiwa ku antswa.
tiyunivhesiti ta tithekinoloji na tikholeji ta Dyondzo ya le Mahlweni na Vuleteri.
ku luma ndzeni
Hikokwalaho, ndza tshemba leswi a swi ta endliwa.
Hakunene, ku fanele ku va na vuvekisi eswiporweni.
1. RITO RO RHANGA
Hi 2010 sweswo ku ta va ku ri swilo leswi hundzeke.
THIYETA YA MFUMO YA AFRIKA-DZONGA
Holobye wa xifundza hi yena mutshamaxitulu wa foramu.
a a ha ku va eriqinghweni.
ntirhisano
Kumbexana xexo xo va ntsena lexi eka xona hi nga kanetanaka.
Ndzi ehleketa ku ri i ndzingo ku endla sweswo.
Hi ta ndlandlamuxa matirhele eka vukorhokeri bya mfumo no tiyisisa vutshembheki byo tiya, hi swi ta ndzhaku swo tiya laha ku nga na ntsandzeko wa mphakelo wa vukorhokeri eka vanhu va hina.
mudyondzi wa vudyondzela-ntirho
nongonoko
3. U fanele ku hakela mpfumelelo wa vutshunguri bya swiharhi wo rhumela laha tikweni (Pfuxetiwa lembe na lembe no kandziyisiwa eka Gazette ya Mfumo)
loko lexi xi koteka.
Hi ku vona ka mina, mikarhi yo cinca yi lehile ku tlula mpimo.
ekule na le kaya
Leswi hi faneleke ku swi endla sweswi i ku sivela nkayonkayo wa ikhonomi.
Hi twisisa swi helela swivilelo leswi vuriwaka eka muhundzulo.
Xo hetelela swi tkomba kuri na ntshembho wo karhi.
Ndzi ta tirhana ni swivutiso swin'wana swimbirhi kumbe swinharhu.
na ku dizayina switirhisiwa swintshwa laha swi lavekaka.
U nyikiwe vutihlamuleri byo rhangela no letela vantshwa va hina.
Elembeni ku na mavhiki ya makumemune yo dyondzisa, ku dyondza na ku asesa.
Tindlela leti katsiweke ti nga va na nkucetelo lowu vuyerisaka eka mbangu.
xihambukelo lexi akiweke ehenhla ka mugodi
Mitlulelo leyintshwa eka vanhu lavatsongo yi enhlile naswona malembe lama munhu a languteleke ku ma hanya ya le ku tlakukeni.
Hi yima yi vona.
Ku sukela loko ku tumbuluxiwile Vutirheli bya Maphorisa ya Afrika-Dzonga (SAPS) hi 1994
Nseketelo wa tipolitiki wa lexi, hakunene wu na nkoka swinene.
Vumbhoni lebyi bya ku hakunene vana va tleketliwile byi tirhisiwa hi n'wakontiraka wa ndzawulo, One Future Development 46, ku tumbuluxa xilipi lexi rhumeriwaka eka ndzawulo.
Hakunene xa fanela
Nhlanganiso na ku hlangana: mabindzu ya le migangeni ya tirhela swilaveko hi ku angarhela.
Khodi ya ntlawahato ya ndzinganeriso ya vumaki
wu lava muthori ku tisa no hlayisa
Swo hambana
4. Ku thoriwa Khabinete yi pasise ku thoriwa ka lava landzelaka:
Va fanele ku tirha swin'we.
Munhu loyi a hlamulaka ematshan'weni ya un'wana (loyi a nga riki kona kumbe ku vabya, xikombiso).
yi se yi wongile mfumo.
Phurofesa wa swa Ikhonomiki eYunivhesiti ya Cape Town.
landzelerisa ntirho lowu endleke hi vayimeri va tendzo, swihahampfuka, tibangi kumbe tikhamphani to lombisa timovha
Basisa michini.
i nkateko eka mna ku mi amukela laha Afrika Dzonga.
Jenerali wa Khansele ya United States
Ndzi pfumeleleni ku kombisa leswi hi xikombiso xo kongoma swinene.
Hinkwerhu hi tshemba lexi.
ku nga entangi
Mhaka leyi i yo tika ku tlurisa ku va swi nga va tano.
Hi mikarhi yo tala swi tlhela swi tshikelela vavasati.
swin'w. na swin'w.) ku tiyisisa vuhlayiseki na vusasekisi bya doroba leri enerisaka loko ri karhi ri tlakusa nhluvukiso wa ikhonomi.
Naswona ku hava phurofexinali leyi yi nga tswariwa eka yindlu yo tani, loyi a nga tswariwa ku ri hava nhlayiso wa rihanyu.
eka Masipala wa Doroba ra Buffalo City
Eka endlelo leri, mihlawulo yi tlanga xiave xa nkoka.
ntlawa wa swicelwa
Hi ta kota ku lulamisa ntirhisano wa hina wo tirheka.
Kuva ni kurhula, hi lava nhluvukiso.
khwatsi
Jenerali wa Tikonta u kume leswi landzelaka:
I nkarhi wo va hi teka mhaka leyi yi ri ya nkoka.
yima ku nwi mamisa kutani u ya emahlweni u n'wi nyika masi yo phungahatiwa ya homu hi khapu.
Hambileswi vunyingi bya timasipala letitsongo ta miganga ti nga se hluvukisaka tisisiteme to hetiseka ta mafambiselo ya matirhelo, tikomiti ta tiwadi ti vona mianakanyo ya ku teka xiave eka swikambelo swa matirhelo ya masipala ku ri loku nyanyulaka swinene.
hulela
Lexi i xiyimo lexi nga tiyiselekiki.
3.3 Vuxokoxoko bya Vutihlanganisi hi ku Angarhela 7
Vutshamo byin'wana byi vula xivumbeko xin'wana lexi ndyangu wu nga eka xona ku nga ri yindlu / vutshamo lebyikulu.
Holobye ehofisini ya Phuresidente loyi a nga na vutihlamuleri eka nhluvukiso wa Vamanana, Manana Susan Shabangu, u ta tirha na tindzawulo ta Mfumo, tiejensi, xiyenge xa purayivhete na mintlawa yo ka yi nga ri ya mfumo, ku tiyisisa nhluvuko wa ikhonomi ya vamanana, nhluvukiso na timfanelo ta ximunhu.
ntombhi ya Muwini wosungula wa Nobel Peace Laureate
na le ka vulawuri byihi na byihi byin'wana lebyi vekiweke hi milawu ya tiko.
I mfanelo ya xinawu na vumunhu, hayi ku hlawula.
Ku engetela, va nga tirha eka leswi landzelaka:
henhla
hi nga ka hi nga swi pfumeleli sweswo ku humelela.
Xi khumba vumundzuku bya rixaka hinkwaro ra vanhu.
Ndzawulo ya Timhaka ta Mati na Ndzawulo ya Timhaka ta Mbangu yi hluvukisile nhlayo ya minongonoko ehansi ka EPWP
ku angula hi nkarhi
Swi ta tika ku kuma mbuyelo wa xihatla
Loko mu-aka tiko loyi a nga kombela vuxokoxoko bya manyikele ya tibazari o nyikiwa mahungu ya kona se nkarhi wa ku endla swikombelo swa ku nyikiwa tibazari wu hundzile wa lembe-xidyondzo rero, xikongomelo xa ku nyika vuxokoxoko xi ta va xi nga ha ri xa nkoka.
Eku amukelena ka xivilelo lexi endliweke hi huvonkulu ya xifundzhankulu, nhlangano lowu tiyimeleke wa maphorisa lowu simekiweke hi mfumo wa milawu ya tiko wu fanele ku lavisisa matirhelo yo biha yo, kumbe xidyoho lexi endliweke hi, xirho xa ntirhelo wa maphorisa eka xifundzhankulu xexo.
Mpaluxo wa swikongomelo
Hambiswiritano
Tindlu letintshwa ti tisa mihloti ya ntsako
ku ni mhaka ya xitiko xa switiviwa.
Hi kotile ku swi endla eku heteleleni.
Loko ku pfaleka ku va kona eka xiphemu xa phayiphi ya nkululo leyi hlayisiwaka hi Masipala
Swi fanele hakunene swi olova ku swi hlamula.
Vanhu va le xivindzini xa ku tumbuluka ka GEMS.
Kuma khothexini ya ketlele yintshwa
Hikokwalaho, swilo swi le ku fambeni.
Sweswi ndzi mutwisiwakuvava wa ku dzaha fole hi ndlela leyi nga kongomiki.
Hi ta amukela xiboho ku nga ri khale.
Hlamusela leswaku lexi i xikalu naswona xi tirhisiwa njhani.
Swivilelo eka swiboho swi endliwa eka Khoto Leyikulu ya Swivilelo.
Xibokisana xa 7
hi byihi vuxaka?
Timhaka eka memorandamu
Mitirho ya muofisirinkulu
Hi swona swi endleke leswaku ndzi va ndzi papalatile ku vhota eka switshunxo haswimbirhi.
Eka xirhangana xin'wana na xin'wana, a ku vekiwile tithagete ta ntlhanu ti tlhela ti hlamuseriwa.
Wu sungurile ku tirha eNEDLAC lowu ku nga nhlangano wa ntirhisano eka xidemokirasi xa hina
Leswi swi fanele ku hlohlotela Bafana Bafana
registrar u pfumeleriwile ku humesa phemiti.
Leswo swi fikeleriwile.
Leswi swi endliwile hi ku khumba kunupu.
Xikongomelo xa hundzulo lowu xi le rivaleni swinene.
Tanihi leswi u vulaka
Timixini e Afrika ti kule ku suka eka 17 ku fika eka 45.
Yaleyo i mhaka ya nkoka.
Leswi nga vuleki leswaku a hi nge sirheleli mavonelo ya hina, nkarhi wun'wana hi matimba.
mupfuni wa n'anga ya swiharhi
Ndza tsaka ku vula leswaku Afrika Dzonga yi nghenerile eka hinkwato tinhlengeletano to lulamisela ta vaholobye.
Afrika Dzonga A1
Nhluvuko na vusirheleri swa hlangana swinene.
Hambiswiritano, ndzi tsakela ku hoyozela murhapotiya
Leyi i nhlokomhaka ya nhlengeletano wa namuntlha.
NCOP yi sungule Nongonoko wo Yisiwa ka Palamende eka Vanhu hi 2002.
Tikereke ta laha mugangeni ti hlanganile ku kanela hi lava xiphiqo lexi xi nga hluriwaka hakona.
Vayimeri va swiyenge hinkwaswo
Swi nga va swo tala
nkotloto
Hi ta tsakela ku hambuka eka timpakani leti fambelanaka na ku hoxa xandla.
ku haxa mahungu
Ndzi susumeta no tshemba leswaku leswi swi ta humelela ku nga ri khale.
Maendlelo ya Vululami hi tlhelo ra Vugevenga.
Vutshila, mfuwo, ikhonomi na rixaka
Eka mhaka yin'wana, ku nghenelela ko tala i swilo leswi mfumo wu nga tiyimisela ku swi endla hambi leswi swi nga hlanganisiwangiki kahle.
switirhisiwa leswi faneleke a swi kumeki.
gwandza
swikombonkulu swa matirhelo leswi nga vekiwa hi masipala swi fanele ku katsa swikombonkulu swa matirhelo swo angarhela leswi nga vekiwa ku ya hi xiphemuntsongo xa
i matilulamiselo yo tekela enhlokweni timfanelo na swidingo swa vona kun'we na ku tiyimisela ku va pfuneta ku engetela nkoka eka vutomi bya vona.
Xivangelo hi leswaku hi lava ku papalata vukanakanisi byin'wana.
minkwama hakanyingi yi tirha yi kanetana na matikoxikaya.
ku langutisisa eka ku tirhisana exikarhi ka indasitiri na swivandla swa xiakhademiki
kumbe ha swimbirhi ka swona.
Hikokwalaho, ndzi ehleketa leswaku leswi swi hi nyika mhaka yo ehleketa hi yona.
Xana hi na milawu leyi fanaka?
Xo hetelela, rito eka swiyenge.
NHI yi sungula ku tirha eKZN
Muholo na tihakelo ta swirho swa Huvo yo Tsundzuxa
Ku hava n'wangulo wolowo eka tlilasi ya swa tipolitiki.
Lava i vaseketeri va nkoka ngopfungopfu eka tindhawu ta le matikoxikaya, lava nseketelo wa vona wu nga ta pfuna ku vona ntlhontlho wo karhi: xikombiso ku tsema misinya ku kuma tihunyi eka ndhawu leyi nga vangaka nkhuluko wa misava.
vuhumo
Hambiswiritano, ku kota ku fikelela swikongomelo swa hina, leswi hi lava vatirhisani.
Ku na vunyingi byo chavisa bya vugevenga ehenhla ka rixaka ra vanhu.
Xo hetelela, marito matsongo mayelana ni mpfuno wo karhi wa ximunhu.
swo tanhi swintlangwana na miletelovutivi leyi nyikiweke eka swirho etikweni hinkwaro na swivandlanene swo tala swa PR leswi tumbuluxiweke ku tlakusa ndzemukiso wa phurofexini leyi na migingiriko ya Vandla.
Ndlela yin'wana i ku kula ka madzolonga
Ku va na vutumbuluxi, ku basisiwa ndlela yo akiwa ka switsundzuxo.
Loko mufambisi wa swilahlo a ri na mfanelo ya ximfumo yo amukela tinothisi ta rifu, ku tata rejistara ya rifu, no humesa swileriso swa swilahlo, mufambisi u ta endla leswi landzaku:
Tisisitemenkulu
ku katsa na swikongomelo leswi landzelaka
tanihi ntlawa
I referendamu xana?
Handle ka sweswo, ndzi ehleketa leswaku yuro i nchumu wa kahle hi ku hetiseka.
Kungu ra mutirhikulori wa hina i goza ro ya e tlhelo ro lulama.
Hetisa ku simekiwa ka qhingha ro hlengeleta mali leyi nghenaka.
Naswona swa olova ku vona leswaku hikokwalaho ka yini.
Kambe hi fanele ku ololoxa xivangelo xa nkwetlembetano.
Swikongomelo swa nongonoko swi katsa:
Ku paka i mahala.
eHartebeespoort
Tafula ra 3 laha hansi ri kombeta leswi CBP a nga ta fambisa xiswona CBP ku ri xiphemu xa leswi nkunguhato wa IDP na ndzhendzheleko wa mpimanyeto wa mali, lowu wu nga kombiwa eka fomo yo hambana eka ndzhendzheleko wa Xifaniso xa 5.
leswi swi ta khumba vuxaka exikarhi ka matiko ya ka hina
Mhaka leyi yi vula leswaku swilaveko swa hina hinkwenu i ku yisa emahlweni hi langutisisa hi vurhon'wana.
Tanihi hi xirho xa Afrika
Ntirho wu tava kona hi Wavunharhu hi ti 4 Dzivamusoko...
Loko u ri muhlaseriwa wa vugevenga
Eka mhaka leyi swikoxo leswi landzelaka swi na nkoka ngopfungopfu.
Ndzi longoloxile timhaka ta nkoka to tala swinene.
Hi swona swi endlaka leswaku hi ri eku kunguhateni ka ku hundziseriwa emahlweni ka ku khanisa.
nhlata
-politiki
Mitirho eka ku vumbiwa bya vukhongeri byi katsa:
Hambiswiritano, ndzi na swilelo swimbirhi.
Ku kuma mahungu hi xitalo, endzela webusayiti ya: www.oigi.gov.za kumbe u fowunela nomboro ya mahala ya: 0800 000 013.
Xa vumbirhi i nhluvuko wa swa ikhonomi.
a xi amukeleki.
leswi swi tiveka tanihi 'mali leyi nghenaka no huma'
Hi nga endla swo tala naswona hi fanerile.
Hi fanele ku humelerisa lexi.
Ndza tshemba a swi nga avanyisi ntshamo lowu.
Ku endla sweswo, tikhoto ti fanele ku fikeleleka, ti tirhiseka hi vanhu na ku va na vuswikoti.
Hunguta manyunyu eka vatirhela mfumo loko va endla ntirho wa vona wo nyika vukorhokeri hi ndlela yo amukeleka tani hi laha vaaki va nga ta byeriwa hi leswi amukeriwaka
U komberiwa ku joyina Ndzawulo ya Rihanyo eka:
Tumbuluxa masungulo ya switirhisiwankulu swa xiyimo xa le henhla swinene, xiyenge xa vatirhi na marimba yo lawula.
Tafula ra 1.1 ri kombisa nhlayo ya vanhu lava nga tirheki ya 15-24 wa malembe hi vukhale leyi yeke ehansi ku suka eka 55.9 wa tiphesente ku fika eka 46.6 wa tiphesente eka nkarhi lowu.
A hi vuli leswaku a swi tikombi leswaku i ntiyiso.
Xiyenge xa ku vulavula hi vukorhokeri hilaha ku nga na matirhelo na mahlayiselo
N'wangulano wa endleka exikarhi ka vayimeri va vatirhi na vathori.
Manghenelo ya hina eka ku hlengeleta mali ya mfumo ku katsa ntwanano wa le rivaleni na swirho swa miganga.
kambe a hi kumangi nhlamulo.
Ku na timhaka ti nga ri tingani ta nkoka swinene.
Hikokwalaho ndzi tshembha leswaku hi lava nhluvuko eka mhaka leyi.
Ndzi lava ku vula swimbirhi swa leswi.
Ntiyiso hi leswaku a hi yi tivi ndlela.
Mhaka ya nsirhelelo wa swakudya hi yin'wana yi faneleke ku rhangisiwa laha ndhawini.
Masipalankulu
Milawu ya machudeni
Eka nkarhi wa sweswi, mahanyelo yo va na vutihlamuleri i tlhari ra nkoka eka ku lwisana na vuvabyi bya HIV na AIDS.
ku va u tivisiwa hi xiboho mayelana na ku nyikiwa ka mfikelelo
A ndzi ta lava leswaku ku va na vutoloki.
Stalplein yi hluvukisiwile emasungulweni ya va1980, loko ku cincacinca ku endliwa ku rhurhela Hofisi ya khale ka Presidente wa Tiko.
Ndzi seketela swibumabumelo leswi.
U fanele u tlhela u kota ku nyika nhlamulo yaleyo.
A ku na mahungu yo tala n'hweti leyi, leswi swikolo na tiyunivhesiti swi nga eka nkarhi wo wisa wa vuxika naswona vatirhikuloni va hina eka hafu ya misava ya n'walungu va sungulaka ku tiphina hi tiholideyi ta ximumu.
hunguva yo tsindziyela
A ndzi voni leswi swi ri xivangelo xo tlangelo.
Ku hava xirho xa Bodo xi yimiseke ku humelerisa.
Ha swimbirhi swi kombisa ku sirheleleka na matimba ya ximfumo - na swona swi kombisa ku tiya ka milenge ya xinyenyana lexi.
Hambi u antsweriwa hi yini kumbe yini
xiyenge xa lavakulu (tigiredi ta 7 - 9)
Ku nga ri nkombiso kambe phathene
mapfhumba yo dyondza entsungeni wa malwandle
Eka milandzu leyi fambelanaka na swidzidziharisi.
ko va noto yin'we eka okhesitira ya demokirasi
Xikongomelo xa Nawumbisi i ku endla leswaku xiyenge xa swa timali xi hlayiseka hi ku tirhisa maendlele ya 'swilawuri swa mahahlwa' leswi ku nga ku tumbuluxiwa xa swilawuri swimbirhi: xin'we xi langutane na vuhayiseki na ku twala ka minhlangano ya swa timali naswona lexin'wana xi langutana na maendlele lawa minhlangano ya swa timali yi fambisiwaka hi kona.
hi ku ya hi swipimelo.
Swinawana swa Dorobankulu ra Tshwane swi nga ha voniwa eka Senthara ya Vatirhisi ya le ku suhi na wena kumbe eka webusayiti ya Dorobankulu ra Tshwane eka www.tshwane.gov.za.
U na vumunhu, papalata ku soriwa hi van'wana.
Swoleswo i vucivanyana.
Ku cinca ka mindzelekani ya swifundzankulu hi xitalo a swi ri hikwalaho ka timasipala ta nhungu ta mindzelekani yo hingakanya leti tswongiweke hi xitalo eka swifundzankulu swa tona.
Xo hetelela, xi tlhela xi va xivutiso xa switirhisiwankulu.
Lexi hi xona xi nga endla leswaku swi va kahle ku tshikelela ntirhisano.
yuriya
Tanihi xiphemu xa rimba leri, swi koxa nyingiso wa hina hinkwerhu.
Xana hi ta fika njhani kwalaho?
ku nghenelela ka milawu yo endliwa ya tiko hi ku landza xiyenge xa 44(2), milawu ya tiko yi na matimba ku tlula kungu ra vumbiwa ra xifundzhankulu; kumbe
Mpimanyeto i kungu leri kombetaka hilaha mali yi kumisiwaka xiswona ni hilaha yi nga ta tirhisa xiswona eka karhi lowu pimanyetiweke.
Swi le rivaleni leswaku, hi fanele ku vekisa eka vumundzuku.
xana wa ha kumeka?
Sweswi a ku na mali yo ringana ya kun'wana.
komiti ya wadi yi nga
Maqhingha ya Maafambiselo ya Swifambo swa le Mapatwini yi vilerisiwa hi leswi landzelaka
va nga ka va nga khwalifayi ku rejistara tani hi tiprofexinara ta van'wasayense ya ntumbuluko.
Ku vuyeriwa ka phurogireme ka vonakala swinene.
 Mali ya nhlohlotelo na minongonoko ya ku tshineta mitirho na vuvekisi eka ndhawu yo tshama ya doroba laha vanhu va nga tala kona emakumu ya matikoxidoroba
Leswi swa hlamuseriwa eka swiviko swa nongoloko wo pfuneta.
Bindzuxidzi ri va na swirho swa ntlhanu kumbe ku tlula leswi swi nga vanhu lava a va tekeriwa ehansi.
Khale ka swandla swa vaphuresidente;
Mifungho leyi bumabumeriwaka (loko swi koteka).
tindlela to tivisa vaakindhawu hi timhaka leti nga ku tekeriweni enhlokweni hi huvo na maendlelo yo kuma mavonelo yo karhi ku suka eka vaakindhawu
Ndzi tshemba kuri hi nga vona mintirhisano yo hlaya ya vutshila ya muxaka lowu.
Eka swisiwana
mfumo wu nghenisile tiphurogireme to hambanahambana ku antswisa nkoka wa vutomi bya vana va Afrika Dzonga.
Ntirho wa vona i ku nyikela vukorhokeri lebyi va nga na ntwanano wa ku byi nyika.
handle ko onha mitirho kumbe vuphikizani.
hi tsakela ku va tlangerisa
Ndza twisisana swinene na swiringanyeto swa wena.
Hlamusela leswi rito leri khwatihatiweke laha henhla ri vulaka swona.
Papalata swakudya leswi nga na munyu swo fana na tikhubu ta homu
Hi fanele hi twa ku vava
Swinawana leswi endliweke ehansi ka nawu wihi kumbe wihi
Tanihi loko rixaka ri tilulamisela ku tlangela malembe ya 20 ya Ntshuxeko, Vaaki va Afrika-Dzonga va fanele ku tinyungubyisa hi mhaka ya leswaku vutomi byi cincile hi ndlela yo antswa ku sukela hi 1994.
Endlelo rihi na rihi rin'wana a ri nge pfumeleri.
Loko movha wa wena wu tirhisiwa tanihi hi xifambo xa mani na mani kumbe ku ri movha wo rhwala nhundzu leyikulu
Vaendli va swikombelo va fanele ku tlhela va rejistara tani hi tikhampani ehansi ka nawu wa Companies Act
mfungho wo kombisa tlhelo ra patu ro pfuleka
Xihlawulekisi lexi faneleke xi hlayeka:
Lowu i mpimo wa ku kula wa 5
Leswi i swivutiso leswi welaka eka xivandla xa ntwanano wa vun'we bya ntlawa.
xidikizelo xa sathelayiti
"Eskom i khamphani ya mfumo naswona hi na xikongomelo xo twala ku nga ku phakela gezi eAfrika-Dzonga hinkwaro na ku antswisa nkoka wa vutomi bya vanhu va hina
Ku vhota kutisiwile emahlweni eka siku ra namuntlha.
Swivangelo swa masungulo leswi nga ta nghenisa xandla eka ku humelela eka ku lulamisa hi vuntshwa loku:
Ku laveka ka ku antswisa nkoka wa dyondzo
Mitirho ya Rihanyo ya ka mhasipala
swa ikhonomi leswi kotekaka
kama
Nkarhi wa vuleteri wu nga fika eka tin'hweti tinharhu, ndzingano wa nkarhi hinkwawo.
Leswi swi tirha eka mhaka ya vutihlamuleri bya swa mbangu.
Hlamusela ku tirha kahle ka swa timali eka bindzu.
Leri i goza lerikulu kuya hi vutihlamuleri bya maphorisa
Matsalwa ya le ndhawini yoleyo na le handle - xik. swiviko swa lembe
kambe hakunenenene swi kahle.
Ndzi se ndzi boxile leswaku ndzi gqweta.
Swakudya ku suka eka 8 wa tinhweti
Ku fana na Maafrika-Dzonga laman'wana hinkwavo, vaofisiri va vuhlanganisi va na ntshunxeko wa ku katsana.
Ku va mudyondzisi wa vuchayeri, u fanele ku leteriwa na swona u pasa xikambelo xa kona.
U nge faneli ku yima nkarhi wo leha.
Mhaka ya mina ya vunharhu hileswaku hi lava vutirhisani lebyinene.
Ku hlahluva swi nga endliwa ximfumo na ntlawa lowu rhambiweke ntsena
Langutisa vundzeni lebyi mitirho ya hlelelo yi nga ta humelela ha kona.
[Ndzimana ya (b) yi susiwile hi x.3 xa Nawu wo Cinca Vumbiwa wa Vukhume mbirhi wa 2005.]
xiluko
Maendlelo yo lawula - ya katsa ku landzelerisa na ku pima nhluvuko ku tiyisisa leswaku swikongomelo swa phurojeke swa fikeleriwa
ku komba vuanakanyi.
muchini wo sayiniphepha
2.2 Khabinete yi amukerile Vuako bya Afrika-Dzonga byo tihlanganisa na Nhlangano wa Ntirhisano wa Ikhonomi na Nhluvukiso eka nkarhi wa 2013 / 14-2016 / 17.
vavabyi lava twaka ku vava
Xifaniso xa 2: Swiendleko xa CBP
xiphemu
Hi timbirhi tilayisense ta vuhaxi bya tindzhawu ta vaaka-miti na vuhaxi bya matimba lamatsongo byi ta tirha malembe manharhu
Kumbexana sweswi hi wona nkarhi wo languta leswi hi vuntshwa.
Kambe hi fanele ku xi endla.
Manana Xipikara xa Huvo ya Rixaka
A ndzi ta tsakela ku kombisa timhaka ti nga ri tingani ta nkoka.
Tiphurojeke leti ti kongomanile ni leswi:
Mukomberi loyi a lavaka ku kuma rhekhodo leyi yi nga na mahungu ya yena, a nga laveki leswaku a hakela mali ya xikombelo.
Swona hiswoxe, sweswo i mhaka yo akisa.
swi humela hi ku siyana ka mikarhi.
Movha lowu wu nga nyikiwangiku layisense eka malembe ya mune wu ta vhela wu suriwa eka ntsariso.
Loko ku ri na madzolonga ya le mindyangwini tanihi xikombiso
Hakunene, ndhawu leyi hilaha ndyangu wa vanhu wu nga velekiwa kona.
u fanele ku apulayela xitifikheti xa mbhasiso wo suka emaphoriseni exiticini xa maphorisa xa le kusuhi na wena xa Afrika Dzonga.
U ta fanele ku nyika vumbhoni leswaku xikweleti xa yindlu xi pasisiwile.
Loko hi nga burisani hi ku hetiseka, leswi swi yisa eka ntshikelelo, nkanetano na ntlimbo lowu nga va ka kona.
Naswona va landzurile ku tlhelela eka JVMM hi mpfhuka ka nkarhi wolowo.
Swirho leswi nga na xivongo xo hambana na xa nhloko ya muti swi fanele swi tata mavito ya swona hi xitalo (vito na xivongo).
A hi swi kotanga ku xiya ku antswa kwihi kumbe kwihi.
A ndzi ta tsakela ku boxa swivangelo swinharhu swa nkoka.
Xo hetelela, ku na vusirhelelo.
Ku kota ku tirhisa tikhompyutara/ vanhu va valawuri lava va nga pfunetaka hi ku thayipa
Swiphiqo a swi humeleli.
MaAfrika-Dzonga lava makaka na lava va rhumelaka swimakiwa ematikweni ya lehandle.
ku katsa xikombelo xa ku hundzisela xikepe xo phasa tinhlampfi, mpfumelelo wo khoma na layisense eka malwandla yo leha
Michini - vuvabyi byo rhurhumerisa voko ku suka eka ntirho wo tirhisa tisaha ta nketana
kambe timali leti ti nga tlakusiwa ntsena loko swi boha ku fikelela xikongomelo xo karhi xa timali.
ntshuxeko na xidemokirasi.
A ndzi ta tsakela njhe ku vula swin'wana hi ku hetisela.
Hi ku tshembeka va engetela
Hi marito man'wana, i switsongo ngopfu.
Ntirho wa pulasitiki yo sivela mati ekhumbini i ku...
1 / 2 Nxopaxopo wa vaakindhawu na loyi a nga na xiave
Riphabliki
leri i goza ro tlhelela endzhaku.
eBotswana.
A xi kongomisi eka mhaka yihi kumbe yihi yo lulamisa.
Handle ka loko swi nga fambelana na matirhiselo ya kona kumbe swi ri erivaleni leswaku a swi fambelana, leswi vuriwaka eka milawu yihi na yihi kumbe endlelo swi kongomisiwa eka -
Vo tala va lava hi nga swin'we eka nhlangano va vurile mhaka leyi.
Fomo ya RLF (Xikombelo xo tlheriseriwa mali ya layisense)
Mhaka ya nkoka i ndzinganiso lowu faneleke.
Ndza tshemba leswaku hi ndlela yin'wana hi ta humelela.
ndlela yin'wana
Tinhlengeletano ta Khomiti
swa mfumo na leswi nga riki swa mfumo.
Xiyengentsongo xa a xi siveli mfumo ku wa pfuneta hi timali eka mavandla ya dyondzo yo tiyimela.
Nhlangano lowu wu nga na switulu swo sukela eka 20 kumbe ku tlula eka Nhlengeletano ya Tiko ya Milawu naswona leri wu nga boha ku nghenela eka mfumo wa vun'we bya rixaka, wu na mfanelo yo va wu nyikiwa ndzawulo yin'we kumbe ku tlula eka Khabinete leti hi tlhelo ra tona Vaholobye lava va vuriweke eka xiyengentsongo xa (1)(a) va faneleke ku thoriwa, hi ndzinganelano wa nhlayo ya switulu leyi wu nga na yona eka Palamende ya Rixaka loko ku pimanisiwa na nhlayo ya switulu leswi swi nga na Minhlangano leyin'wana leyi ngheneleka.
Xiyimo a xi nge olovi ku ololoxiwa
Swi tava swi ri kahle swinene hi ku landza vuswikoti byo hakela nawu.
misava yo ondza
KU THORIWA KA MUCHAYERI WA GANDAGANDA WA NKARHI HINKWAWO
Mapaluxelo ya xiphiqo
swa ntivo-vutivi
Loko u lava ku nghenisa etikweni movha wo huma ehandle wa sekeni kumbe lowu nga tirhisiwa u wu nghenisa eAfrika Dzonga, ku laveka u va ma phemixini wa xipeceli wo huma eka Hofisi ya Holobye wa Minxaviso na Tiindastri kumbe tiejenti ta ofisi leyi.
A ndzi swi vulangi swoleswo.
Tinxaka leti ta tinhlengeletano ti tumbuluxeriwile ku tisa lava nga na xiave lexi faneleke ku avelana mianakanyo na ku kuma switshunxo eka swiphiqo leswi nga kona.
Ndzi nga vutisisa leswo.
Swo fana swi tlhela swi tirha eka ku akiwa hi vuntshwa ka tiko.
yinso yo endliwa
KU HETISELA (0.5 WA MASIKU)
Ku kotisa loko ya tele matsalwa lama boxiweke eka papila leri khomisiweke ya fanele ku yisiwa.
Hi swona swi endleke leswaku hi va hi ri ni mivulavurisano yo tala swinene.
Nhlamuselo yo endla makungu
Nyika swikombiso swimbirhi swa milawu yo lawula switirhisiwa swa ntumbuluko.
Eka switiviwa swo karhi a ndzi ta mi hundzisela eka xiviko xa mina.
Hi sungule ku langutisa swilavo swo tala swa xihatla swa vanhu va hina.
Mitlhontlho na swa kahle
Mitlawa yi nga hi pfuna
Xiphemu lexi nga riki kona i xa malulamiselo ya swa mihlangano ku pulana maxavelo ya swilo leswi humesiwaka eka nkarhi wo karhi hi ndlela ya nxavo wa le hansi swinene.
Ha titwela hina hinkwerhu.
Loko ndza ha hetisa
Vamanana va le ka switulu swa nkucetelo eka mfumo naswona va tlanga xiave xa nkoka eka maendlelo yo teka swiboho.
Timfanelo ta vadavuki va tiko relero
Naswona ahi na ku kanakana leswaku Themba Pharmaceuticals yi ta hi pfuna ku fikelela eka nkhuvo.
vutifumi
xidemokirasi xi fanele vekiwa eka masungulo yo angarhela.
Va nyiki nyama.
Vuxokoxoko byin'wana byi ta kumeka loko byi komberiwa.
Hoyozela laha swi faneleke, hambiloko u nga swi tsakeli.
Ndzi ta heta emakumu ka jekajekisano lowu.
Hi vile hi ringetile ku nghenelela eka mhaka ya kona.
Hambiswiritano
Swihlawulekisi swa mitirho na nkoka wa n'wamabindzu.
xivuyevuye
Hi fanele naswona hi ta dumisa vumbiwa.
Laha u endlaka xikombelo hi ku yimela un'wana
lowu pfunaka vapfuniwa hi swa xithekiniki swo aka yindlu yi ta thoriwa.
A ku na ku balekela mhaka leyi.
Hi mayelana na phemiti yo chayela ya phurofexinali
Ku tiva vanhu lava faneleke eka xiendleko xo karhi.
Irhangana xin wana xa mfumo eka lembe leri i ku hetisisa na ku wundla maqhinga ya mbuyeriwo tanihi pholisi ya ximfumo ya mfumo, leswaku hi ta sungula ku tshovela mimbuyelo leyi heleleke ya switirhisiwa swa hina.
bolo ya tavala
A wu fanelangi ku tshama ekheleni.
Ndzi tsakile swinene hi mbuyelo walowo.
Xifundzankulu xa rihanyu lerinene i xifundzankulu xa ntsako, a vula.
Lowu i nkarhi wo sungula laha nhlengeletano yi khomeriweke eAfrika.
ndhawu ya mihlangano yo ka yi nga ri ya mfumo.
Sweswo i xikongomelo lexi nga xona tanihilaha xi nga yima hakona.
Hi fanele ku hlayisa ntshembo.
tuva
Hi fanele ku tlhela hi va vukheta swinene hi mayelana na ndzhurhiso.
Tiko ri ta va na vuhlayisi bya rihanyo bya masungulo bya mahala eka tindzhawu ta ximfumo, mitirho ya vutshunguri bya xihatla ya 24-wa tiawara na mimpimo ya laha kaya yo xiyaxiya mintungu ya mavabyi.
Va tshama ehenhla ka phiramadi.
Mpfilungano wa swilo wu nga va kona laha muyimeri a sukaka eka ntlawa wa ntsakelo laha ntlawa walowo wu nga ta ka wu nga humesi munhu loyi wu n'wi hlawuleke eka komiti handle ko tihlanganisa na vahlawuri.
xitatimende lexi nga sayiniwa hi munhu loyi a nga dilivhara fomo.
Leswi swi vanga nxungeto lowukulu eka ku cinca ka hina ka mafumelo, eka mfikelelo wa hina.
Xikombelo xi fanele ku fambana na marhungula hinkwawo laya faneleke, ku fana na:
Nkarhi wu fikile sweswi wo va a teka goza.
I swa ntsakelo wo karhi.
ndlela leyi vanhu va nga tekaka hayona xiave na swiakiwa leswi nga ta tumbuluxiwa ku tiyisisa leswaku vanhu va teka xiave
Hi kombela ku tirhisiwa ka nawu lowu xikan'wekan'we.
Loko u teka layisense ya thelevhixini ro sungula, u fanele ku hakela mali leyi heleleke ya lembe.
Khauhelo
Vaakindhawu a va koti ku teka xiboho xa ku tiva hi ku va mpfuneto wa timali wu ri kona ku va pfuna ku aka tliniki na xikolo.
17 Mahungu lawa ya hlanganisiweke nakambe ya nkunguhato wa mivuyelo leyi rhangisiweke
(h) fambisisa tindzhawu ta vanhu lavakulu leti vuriweke eka xiyenge xa 24 xa Films and Publications Act
Ku sukela nkarhi wolowo, ku vile na mafu mambirhi man'wana.
ku tiyisa tibuloko ta nxaviselano ta rhijini
Xana swi tiyimisele ku yisa emahlweni nsirhelelo hi ndlela yihi eka tindhawu leti.
swa rihanyo ni
Tanihiloko hi kombisile ekusunguleni, loko hi kokisana swin'we ha humelela.
Figara ya 3.1
Leswi swi ta pfuna Bangi ku tinghenelerisa eka switirhisiwa leswikulu na le ka tiphurojeke ta makungu ehandle ka xifundzha xa SADC lexi nga na matimba yo kurisa nkulo wa mabindzu na ikhonomi ekhonthineteni no seketela tikhomixini ta rixaka timbirhi ta Afrika-Dzonga na ku tiyimisela eka nhlangano wa xifundzha.
A ndzi tivi loko u nga vula swinwani mayelana na timhaka teto.
Vandla ri na mfanelo wo tisa tindlela ta mafambiselo.
Ehenhla ka 2 000 wa vapurosesi va datara lava a va tirha tixifiti tinharhu hi siku va thoriwile eka xiphemu lexi ku tiyisisa leswaku mapheji ya rin'we rin'we ya 225 wa mamiliyoni ya hlamuleriwa.
ku antswisiwa ka vuxaka mayelana na mfumo wa sweswi.
Xo sungula, ku na mhaka ya ku cinca ka tlilayimete.
humelerisa mafambiselo ya timali lama nga erivaleni na hi ndlela leyi vuyerisaka eka timasipala na switirhisiwa swa vaakindhawu swa ka masipala (tanihi Khamphani ya Mabazi ya Joni).
vutiolori
Sweswi a hi nkarhi wa ku hambuka eka vuxokoxoko lebyitsongotsongo.
Xiphemu xa 35 xa Nawu wa Vukorhokeri bya Vaaki, 1994 [Nawu 103 ya 1994]
Xana i muxaka muni wa ku hambana lowu wu kombiwaka eka ntshovelo wa masi?
Nhluvukiso wa swa vutlhari bya tipolitiki eka muganga swi katsa ngopfu leswi landzelaka:
mpfumelelo
Nawumbisi
Hambiswiritano, lowu i ntwanano, a hi xileriso.
Vatswari na vahlayisi va fanele ku teka maendlelele yo tivonela ku tiyisisa vuhlayiseki bya vana.
Swi tlhela swi va na nkoka ku xixima ndzingano na ku ringana ko helela ka swiyimo swa vutomi leswi vatatana na vamanana va swi tekaka evuton'wini bya vona.
Nsusumeto wun'wana i wo hlamusela tiwayeni.
Xiyimo lexi xi lava ku cinca lokukulu eka xiyenge xa eneji
SAHRC (yi ta vitiwa Komixini ku ya emahlweni), hikuya hi Xiyenge 10 xa PAIA, 2000, yi ta tsala makombandlela ya matirhisele ya nawu lowu.
Phurogireme yi ta languta eka swiyengenkulu swinharhu,hileswi:
Swi ve njhekajekisano wo tsakisa swinene.
151-164 Mfumo wa Muganga
Ku swi bakanyela etlhelo i ndzhukano eka xidemokirasi.
E ka swiyimo laha mutirhi wa nhlayelo wa vanhu a lavaka leswaku u nyika mahungu lawa u nga ya tlula, u komberiwa ku endla sweswo.
ku tikeriwa ko tala e ka ku hlaya
U ta va a ya Enhlengetanini ya Ntlawa wa 20 eSt Petersburg hi siku ra vuntlhanu na ra vuntsevu ra Ndzhati 2013 tanihi xiphemu xo kurisa swilaveko swa tipolitiki na ikhonomi ya Afrika-Dzonga.
Misava ya mina, ndzhaka ya mina, tiko ra mina.
Xiyimo lahaya xa chavisa.
xikimu xa xipfuno xa mimovha
eka ndhavuko wo karhi.
Hi 1997, vavanuna va malembe ya 20‐ ku fika eka 39- hi vukhale a yi ri 1.6 hi ku tala lava talaka ku fa ku tlula vavasati va malembe yo fana, vo tala hikokwalaho ka ku vaviseka hi ku humela hi khwiri.
hakunene ndzi fanele ndzi vula swilo swin'wana swingariswingani.
Langa kunupu ra ku rejistara eka xandla xa ximatsi no langa muxaka wa rejistrexini leyi yi tirhaku eka wena.
Xandla xa Phuresidente wa hina u le ku teni haleni vhiki leri taka.
Yo tala ya mabindzu lamatsongo ya le ka xiyimo xo fana.
Eka swin'wana swa leswi hi lavaka ku swi endla, miako i ya nkoka swinene.
naswona ya tirha tanihi matsalwa ya nkoka ya xinawu.
Milawu yi lava leswaku mabindzu ya tekela enhlokweni ndzingano wa matholelo, havaxeriso wa matimba eka Vantima wa swa ikhonomi, mbangu, nhluvukiso wa swikili, timhaka ta miganga, nhluvukiso wa mabindzu lamatsongo, vutihlamuleri byo pfuna vaakindhawu na leswi nga swa nkoka swonghasi hi ku hambanahambana ka swona eka muganga wo karhi, swo tanihi maqhinga ya nhluvukiso wa tindhawu ta migodi.
A hi nawu.
Eka Poso yihi na yihi.
Tikhwalifikhexini tinyingi to hambana eka xiyenge xa sayense ya mbango
i nhlokomhaka leyi hambaneke swinene.
Eka mikarhi yin'wana, u nga ha tlhela u komberiwa ku hakela dipositi.
Ku nghenelela ka nkoka loku hi nga ku angarhela eka kungu leri i:
Tindhawu tinharhu ta nkoka to nghenelela ti tava:
hi xikongomelo xo aka 2000 wa tiyuniti.
N'hweti
Lowu i nhlengeletano wa nkoka ku lulamisela timhaka tingari tingani to tekela enhlokweni Samiti.
Pasipoto leyikulu ya fana na pasipoto ya vaendzi ntsena handle ka leswaku yi na tipheti leti nga tlhandlamana kambirhi ku endlela leswaku ku va na tipheji to tala ta vhisa.
"Loko ka ha ri na maAfrika Dzonga lava va faka hi mavabyi lama ma sivelekaka;
masalelo yo ahlukanya
Xiyenge xa mina xa vumbiri xa ntsakelo i mbangu.
Matiko man'wana a ma si fika eka xiyimo xexo.
vuthu ra ha ri na matimba.
I ndlela yo fika emakumu - vutomi byo antswa eka hinkwerhu.
Hi tlhele hi va kombela ku cinca mahisiselo ya mati ku ya ka matimba ya dyambu.
Ku Herisiwa ka Misava ya Venda hinkwayo.
hlula
Muviki wa hina u tiyisile handle ko kanakanisa eka mhaka yaleyo ya nkoka.
Hambiswiritano, swi ni swo tala ngopfu ku swi nyika.
Hi ku engetela, nongonoko wa vayimela vathori wu hetisekile.
Ha swi dinga naswona hi swi dinga hi xihatla swinene.
ndzi ehleketa leswaku u ta tsundzukiwa eka swo tala ku tlula sweswo.
A ndzi tsakeli nyangwa wa le ndzhaku.
Vaaki tiko?
i swa nkoka leswaku Maphorisa ya Afrika Dzonga ya nyikiwa tikhopi ta mapapila ya xikimi xa "419" ku katsiwa eka nxaxamelo wa wona.
Xikongomelo xa rendzo
Nkarhi wa nongonoko wo tshungula:
ku teka magoza ku hunguta ku tiseketela hi van'wana.
hi fanela ku pfala sweswi.
Nkandziyiso wa xielekitironiki wa ha lulamisiwa.
ku kurisa nhlanganelo wa eneji lowu katsaka malahla
azt
Swinepe swa le ndzeni na le handle ka golonyi-kokiwa
sweswi nkarhi wu hi siyile.
Hi nge swi koti ku va hi lahlekeriwa hi miehleketo leyi.
Mbuyelo - vuendzi / tinhlengeletano
-phawula
yi hluvukisiwile ngopfu hi vavasati.
Nkoka lowukulu swinene wa xiyimo wu hlamuseriwile hi nkhaqato.
Mikarhi hinkwayo swa nonon'hwa ku rhamba nhlengeletano ya vanhu vo tala, ngopfungopfu loko u fanele u tihlanganisa na vona ha un'we un'we.
Ku tsakela ka ku rhurhela tinhlengeletano ta matiko ya misava a swi nge vi swi enerile.
yi nga ha tirhisa matimba wahi kumbe wahi na ku endla ntirho wihi kumbe wihi lowu nga nyikiwaka.
Ku pfuxeta hi vuntshwa
Kuva ni kurhula
A ndzi ta rhandza ku hetelela hi sweswo, vamanana na vatatana.
Ha ha ri eka xiphemu xa ku hlayiwa ko sungula.
Muxavi wa movha u fanele ku yisa tifomo eka hofisi yo rhijisitara exikarhi ka 21 wa masiku movha wu xaviwile, kun'we na fomo yo rhijisitara leyi kumiweke ku suka eka muxavisi na setifikheti ya sweswi ya ku va movha wu ri lowu nga lulamela ku famba epatwini.
hilaha ndzi lavaka hakona.
Xiga xo sungula: xirilo xa ikhonomi
Khombo ra kona, lexi i xiyimo lexi hi nga langutana na xona.
setifikheti ya xikolo
a ndzi ta tsakela ku nyika miehleketo eka timhakankulu timbirhi.
I yin'we ya timfanelo ta ximunhu ta masungulo.
Xana swi teka nkarhi wo fika kwihi ku va nondzo wu tirhiwa?
U nga nyiki n'wana swakudya swin'wana na swin'wana kumbe swihalaki swo fana na mati, masi ya swiharhi, tiya, masi ya vana masi kumbe mukapu.
Swi ta tlhela swi pfuneta Tikomiti ta Tiwadi leti enetisaka vutihlamuleri tanihi vuhlanganisi exikarhi ka vaakindhawu na huvo kun'we na khanselara wa wadi loko va ri na rimba ra ku teka xiave ka vaakindhawu.
Leswi i ku nyika nothisi eka vafumi va ku tsarisa swa mimovha emapatwini leswaku vun'winyi kumbe vukhomi bya tayitele ya movha byi cincile.
Leyi i "premise" ya masungulo.
Yaleyo i ndlela leyi hi nga ta tsakela ku yi teka.
Hikokwalaho ndzi ala ku cinca loku.
Ndzi ta tsakela ku vula laha nsinya wa milawu wa khamphani hansi ka yin'wana.
MAENDLELO YO LAWULA
Vaendzi lava vo tsandzeka ku ku nyika nongonoko wa mavito
Vona va faneriwa hi ku kuma nseketelano wa hina
Vupfhumba byi tekiwa tanihi xiyenge xa nkoka eku tumbuluxeni mitirho
H-02: Vutshamo byin'wana byi vula xivumbeko xin'wana lexi ndyangu wu nga eka xona ku nga ri yindlu / vutshamo lebyikulu.
ndzi tshemba ku ta va na mbuyelo lowunene.
Ku endla ntwanano na vakorhokeri va xithekiniki hi vukona /ku tshunxiwa ka vatirhi / ni ku tirha endzhaku ka nkarhi wa ntirho
Tigolonyi to rhwala vavabyi lava tsandzekaka ku famba
Ndzi teka sweswo tanihi swilo swa nkoka swinene.
Ha tsaka hi sweswo, kambe tanihi vugimotsongo.
Xikombiso xi kombisa xidingo xa swiletelo leswintshwa.
Eka nkarhi lowuya, u vurile ku a wu nga swi tivi.
a swi pfumeleriwi.
Palamente a yi fanelangi ku pfumelela timfanelo ta yona ti tekiwa.
Tikhirediti to dyondza ta masungulo a hi xilaveko.
Ku na swiyenge swinharhu leswi nga ta ndzeteriwa:
Hikokwalaho, ndzi alana na ku yisa xiengetelo lexi xa nomu.
E-e, ku hava xiboho lexi tekiweke hi mayelana na leswi.
Swi sungula hi nkarhi wa vhiki ro kunguhata naswona swi fanele ku ringeta ku hetiwa hi vhiki leri landzelaka.
Loko dokodela wa swiharhi wa mfumo eka Hofisi ya Rixaka a pasisile ku rhumela
Swi fanele swi va rimba ro hluvukisa ra nkoka.
Xin'wana xa swivulavuri swa namuntlha se xi kongomisile eka leswi.
Hi lava ku twisisa leswi humeleleka etindlwini na le mindyangwini ya hina.
Ku boxiwa ko hlawuleka ku ta endliwa ka matirhele ya swikolo swa le madorobeni ni le mapurasini.
Eka Mbalango wa Komiti ya Wadi ya Rixaka wa 2004 / 05
Town-planning and Townships Ordinance, 1986, hikokwalaho yi pfumelela n'winyi ku londza ku ririsiwa ku suka eka mfumo wa muganga loko wo cinca timfanelo ta muako.
Leswi hakunene swi ta va na nkhumbo hi ndlela yin'we kumbe yin'wana.
Misava leyi hi hanyaka ka yona yi tshama yi ri ku cinceni hi xihatla.
Hi fanele ku va erivaleni hi swilo swo hlayanyana.
8.2 Yin'wana mindzulamiso yo seketela 15
Xipano xo seketela xi nga nyikiwa hungu ro kongoma ro lulamisela hi xipano xa phurojeke leri nga ta katsa mikarhi leyi vekiweke, migingiriko, mitirho na mipimanyeto.
Swixavisela-vambe swa hina eka tikonkulu swi le ku tlakukeni lembe na lembe, hi lembe ra 2002 a swi ri eka 22.6% kasi sweswi swi le ka 28.5%.
leswi ku ngava xikombiso xa xiphiqo.
hi ku tekela enhlokweni mavonelo ya vona eka ku tshemba eka swa tipolitiki.
ehandle ka ndhawu ya mitirho hi ku landza Tixedulu xa ta 4 na 5
Swi kongomisiwile hi ndlela ya le hansi eka wa nuna loyi a nga exitarateni.
Naswona mhaka yeleyo i xiyimo xa sweswi xa nkitsikitsi wa timali.
Xikombiso -Marhurhelo:
Mina hi ndzexe ndzi museketeri lonkulu swinene wa rheferendamu.
lowu i nkitsikitsi eka matiko laya ha hluvukaka.
xirho lexi pfunetaka hi xihlangalala
xiyenge xa phurayivhete
Nsirhilelo i xilaveko lexikulu.
Tanihi leswi u swi tivaka, i mhaka yo pimiwa.
Mfumo wa muganga wu langutane na mitlhontlho yo tala eku nyikeni ka vukorhokeri lebyi nga ta pfuneta ku aka mbango wo rhula, ni ku va ni rihanyo lerinene.
Nxavo wo andziso inifulexeni wu tlakukile swinene eka malembe lama.
mfurhe
Mali yo tala yi kona, kambe a yi tirhisiwi.
dari ra thayifodi
Hi fanele ku xi languta hi ndlela yo tatisa.
Xikepe xi ta nyiketiwa eka Vutluti bya Afrika Dzonga hi N'wendzamhala 2005.
Lava va talaka ku tlhakisiwa i vavasati, vanhwanyana na vafana va tlhakiseriwa ku endla swilo swo hambanahambana ku katsa na ku xavisa miri, swifaniso swa vuhava kumbe ku tirha mitirho ya le tindlwini.
Xikombiso xin'wana i xilaveko xa ku nyika tinhlamuselo hi ku tsala.
tlimeti ya ximediteraniyani
Ha mi khensa eka nkarhi wo vumba vuxaka bya hina bya ku rhula
Eka nkarhi wo leha, ku tsakela ka miganga na vaxanisiwa va vugevenga a swi nga tekeriwi enhlokweni nkarhi hinkwawo.
Ku hoxa xandla ka vakindhawu eka masipala wa muganga ka tirha eka vamasipala ku tiyisisa ku tirha ka Komiti ya Wadi na leswaku ku na swilaveko swa xinawu swa masipala ku katsa vaakindhawu va muganga
Muviki u vuyelela mhaka leyi ya mavonelo, leswi ndzi swi amukelaka.
Tinkota ta mpimanyeto wo engetela
ku tsakela ka miganga na vaxanisiwa va vugevenga a swi nga tekeriwi enhlokweni nkarhi hinkwawo.
Va balekile hi movha.
hi fanele hi xi endla pfhumba ra nhlawulo.
Xi khorwisiwile eka sweswo.
Yuropa yi na ku hoxa xandla ko kongoma swinene ku ku endla.
Ku khutaziwile swikombelo swo nghenela mphikizano swo huma emadorobeni na matikoxikaya.
Swiphiqo swi ve kona eka nhlayo leyitsongo timhaka ntsena.
Hi ku ya hi Muholo na Nkambisiso wa Matirhiselo ya mali
Sweswo a swo va ntsena nkhutazo hi marito.
Hambiswiritano, swi ta teka nkarhi ku swi veka leswi endhawini ya swona.
Hikokwalaho hi fanele ku hlamusela ti va erivaleni timhaka laha naswona sweswi.
Vutihlanganisi bya Masipala
kambe na xona xi fanele ku endleiwa hi nkarhi.
Hi XIHI xa switatimente leswi landzelaka swi nga VUNWA?
vutavala
Vanhu vo tala va khomiwile.
lava va nyiketaku vutirheli eka mfumo kumbe minhlangano leyi nga ri ku ehansi ka mfumo leyi langutanaku na vuhlayisi bya vanhu lava va nga xanisiwa hi madzolonga ya le kaya.
Eka mhaka yo lulamisa
Minongonoko ya vuhaxi yi endliwile mahala.
Xo sungula a ndzi ta rhandza ku n'wi khensa ku va a endla tano.
Mitlhontlho
Xo hetelela, ndzi ta tirhana no ava eka tindzawulo tin'wana.
Ku hoxa xandla swa rhambiwa eka tsalwa ro hlawuleka ra ITT leri kongomisiweke eka ku cinca loku nga eku humeleleni eka phurofexini ya vuhundzuluxi hikwalaho ka ku hangalaka ka Xinghezi tanihi ririmi ra vuhlanganisi bya matiko ya misava, naswona ngopfungopfu eka leswi swi vulaka swona eka dyondzo ya vahundzuluxi na vatoloki.
hi xihatla naswona handle ka swikambelwana swa le laboratori handle ko tikeriwa.
maina a batsadi ba monna le mosadi le leina la moeteledipele kgotsa baeteledipele ba setso.
Tihlanganise na va council emasikwini ya 30 ku sukela eka siku leri u amukelaku hi rona xiboho xa ku ala na swona u ta nyiketiwa xitsundzuxo hi leswaku u fanele ku endla yini.
xexo a xi fanele xi enerile.
Swi ta va swi tsakisa ku tlula mpimo ku swi tiva.
Nongononoko Fomo ywo sungula ywa swivutiso
Mufoni: Ndzi ehleketa leswaku hi kanerile hi ku hetiseka mhaka ya ntshunxeko wo vulavula.
Un'wana na un'wana loyi a nga ni ku tsakela eka ku nghenela u fanele ku tihlanganisa na Marion eka hofisi ya SATI hi xihatla.
mahungu hi mayelana na tindzhawu to cukumeta thyaka na swikombelo swa swichela thyaka na swikhomelo
Maendlelo lama nga tirhisiwaka ku tisa ntshamiseko wa timali eka swirho ma fanele ma tumbuluxiwa.
Nsivelo wa vukungundzwana na nxopaxopo wa tipholisi ta switirhisiwa swa vanhu na maendlelo.
Ku nga ri hansi ka 30 wa masiku Nawumbisi wu nga si hundzuluxa Vumbiwa lebyi khumbhaka xiyenge xa 73 (2), munhu kumbe Komiti leyi lavaka ku nghenisa Nawumbisi yi fanele ku -
Swi tlakusa na ku seketela ndzavisiso lowu kotekaka wa masungulo.
Hi humesa ku tsaka ka hina eka Mfumo wa Afrika Dzonga eka mafundzha ya wona.
Loko matsalwa ya wena ya tumbuluka eAfrika-Dzonga kutani ya ta tirhisiwa etikweni rin'wana va fanele ku ma "tiyisisa" kumbe va ma "pfumelela".
Maphepha ya swivutiso ya xikombiso ya ta endliwa leswaku ya kumeka hi ndzawulo.
Mfumo wa nhluvuko wu aka vuswikoti bya vanhu ku antswisa vutomi bya vona vini
ku va na gezi swi vula ku va na thelevhixini.
Nakambe ndza khensa swinene eka malwandla ya n'wina.
Minkavelo yintshwa yi nyikiwile eka siku ro sungula eka nkarhi wa lembe ximali.
ku katsa munhu loyi a koxaku ku wundliwa
Hi na tivhoti to tala ku ti hundzisa.
ndhawu ya mahungu
riengeteri
Swi pfuna swinene naswona nxavo wu le hansi.
Kambe, van'wamimovha va veka switsongo miehleketo eka xona ku tlula leswi swi xi faneleke.
NDHAVUKO NA NDZHAKA YA NTUMBULUKO
Ntlkuso wa bajete lowu nga kunguhatiwa wa laveka swinene.
Hi ndlela yihi kumbe yihi, ndza tshemba hi hambukile.
Xi vumbiwile ku endla xiyenge xa ntleketlo xi tirhela vanhu.
A ku ri na swo endliwa swo hambana leswi a swi ri ku endliweni.
A ndzi kholwi leswaku wa swi twisisa
Leswi swi katsa ku xavisa na mafambiselo ya bindzu
Leyi i mhaka yo vilerisa.
•vanakulorhi va vamhani lava kurisaka vana ehandle ka vukati va pfumala vutivi bya ku tirhisa tikhndomu
Hi fanele ku endla leswi endlekaka eka nkarhi lowu taka wa sweswinyana.
Loko u lava ku susa byalwa bya wena lebyi nga xaviwa ku suka eka ndhawu yo nghena
Xiboho lexi xi ta yisiwa eka Khomixini ku langutisiwa.
(iv) swiyimo swa nkarhi wolowo ni leswi languteriwaka eka nkarhi lowu taka swa ikhonomi na timali ta muthori
khoso yo dyondzisa
Ku lahlekela hi ku tsakela swakudya na ku hlamba timbilu
Ku suka loku ku ta humelela hi swiphemu swimbirhimbirhi.
Leswi swi ta kotisa leswaku ku va na ku nyika ko antswa ka nseketelo eka mfumo wa miganga
Afrika eku lulamiseni vugevenga bya xibindzu.
muchandzukwa
Leswi swi katsa, kambe a swi pimeriwanga ku:
Elemente ya vumbirhi ya qhinga leri i nsivelo.
Ku hava lexi nga rindziwa swinenenene.
U endlile tano handle ka mpfumelelo wa vanhu vakwe.
Ha swi lemuka swiringanyeto swa Vumbiwa bya hina eka mhaka leyi.
Mi nge ndzi swi veka erivaleni
Hambiswiritano, a hi fanelangi sweswi ku tshika ntila lowu.
Swi enerile ku vula leswaku xin'wana xa swona a ku ri ximilana xa nkhaviso.
Swivulavuri hinkwaswo a swi navela leswi.
kambe kungu ro tifambisa hi roxe ra ntwanano leri wu pfumeleriweke hi Palamende i nawu laha Riphabliki handle ka loko wu nga fambelana na Vumbiwa leri kumbe Nawu wa Palamende.
Sayense na thekinoloji na swona swi nga tirhisiwa hi ndlela leyi vuyerisaka ku ololoxa yin'wana ya mitlhontlho leyikulu eka dyondzo na rihanyu.
Swikolo swi nga kuma tifomo to endla swikombelo eka Ndzawulo ya Dyondzo.
Endla swiringanyeto SWIMBIRHI ku antswisa vuswikoti bya vatirhi lava ku kongomisiwaka eka vona.
Hinkwavo lava nga na xiave eka mafumelo ya muganga yo teka xiave va dinga ku va na vutivi bya masungulo mayelana na mfumo wa miganga
Mali ya mpfuneto yi na nkoka lowukulu eku simekiweni ka TXsaao.
Switirho swa xikambelwana na swingolongondzwana swa ntirho.
A swi na xivumbeko xa vatirhi.
yi vevukisa ndlela yo nghenelela leyi faneleke.
Ku tlhela ku va na swin'wana swo tala hi swi amuelaka.
Khopi ya antenuptual contract kumbe tayitela hi xikongomelo xa vutivi: I R36
Leyi a hi ndlela ya ku vuyisa ntshembo wa vanhu.
Leswi landzelaka a ku ri swikongomelonkulu.
Naswona hi xona xivangelo xa ku va xivutiso lexi xi ri xa nkoka swonghasi.
hi na swo tala ku tlangela.
Vuqambi bya nchumu lowuntshwa ku fanele ku va prodaktri kumbe prosese leyi yi nyiketaku ndlela leyintshwa ya ku endla xan'wanchumu
eka nsimeko
Tindzhawu laha ku hlengeletiwaku kona metheriyali ya swa jenetiki
kambe lexi a xi nga ri xiboho xa mina.
Eka swo tala va hava ku fikelela ka muxaka wun'wana wa nhlayiso wa rihanyo.
nhlayo-nkatsana
ti katsa mitolovelo yo hambana leyi fambelanisiweke na maqhinga na minghenelelo.
hi Palamende ya Tiko
Mfumo wu nge koti ku lulamisa ntlhontlho wa tindlu wu ri woxe.
(Vona Goza ra 10 mayelana na ntirho wa matsalana.)
Loko mutirhi wa le kaya a tshama endlwini yin'we na vathori
Leswi a swi pfuni ngopfu.
ku tumbuluxa mitirho - na ku lwisana ni vusweti.
xikumiwa xa tiko
Ku Herisa Vuxirho na N'okiso wa Tikomii ta Tiwadi
Mufambisi wa CBP u nyika xiviko eka tikomiti ta wadi hi xiyimo xa tiphurojeke leti nga komberiwa (Xitirho 8).
Xana hi yihi mhaka kumbe xiphiqo ke?
Hi ku vona ka mina, endlelo leri ri lava ku pfuxetiwa.
Hi ku ya hi mbango
Ku fikelela xipimelo lexi, hi fanele ku ta na maqhinga yo hambana-hambana ku tlhiva ikhonomi.
Hi vonelo ra mina leswi swi kombisa nkoka wa matimba ya "nuclear".
nakambe laha swi kotekaka
Leswi i xitsundzuxo eka ku veka nkoka eka xidemokirasi
kambe i swa mani na mani eka vurimi na nxaxamelo lowukulu wa swakudya ku nghenisa xandla.
mfukuzani
vuvabyi bya ku tekela eka vatswari (genetic disorder) kumbe ku vaviseka hi nkarhi wa xikombelo
Switirhisiwa ni vuseketeri lebyi byi lavekaka
tanihi xiphemu xa magoza yo ringeta ku herisa xiphiqo xa mabindzu lamatsongo
Nkul.Morake u tsandzekile ku kuma loni.
leswi i mavonelo ya nkarhi wo leha.
Ematikweni ya Afrika.
I swa nkoka swinene ku hi lulamisa leswi.
A ku na ku kanakana leswaku ntiyiso wa kona wu hambanile.
Ndzi ta va ndzi papalata.
Ku kunguhatiwa leswaku xan'wanchumu xin'we xa mfumo xi tumbuluxiwa eka ndhawu ya vanhu.
kambe a hi mahetelelo.
Hi swona swi endlaka leswaku hi va hi ri karhi hi vhota hi ndlela leyi nga yimiki ni xitshunxo.
Hi tekela enhlokweni
Nkambelo wu le ndleleni, endzhaku ka nkarhi lowo leha.
ku nonon'hwa
Mabindzu ya fanele ku yisa tlhontlho wa vuvekisi eka tindhawu tintshwa.
Sweswo a hi mhaka yo olova, va swirhundzu na va matlhari.
hi fanele ku kuma dyondzo eka swikombiso leswi.
Loko muhehliwa a nga kumeki a ri ni nandzu, swi vula leswaku mufambisamitengo u vile ni ku kanakana.
Eka xivangelo lexi, xinawana xa vaaki i xa nkoka.
Sweswo hi swona swi endlaka leswaku ndzi vhotile ndzi hambana na xiviko lexi.
U fanele ku mangala ku chavisiwa ka wena eka vanhu lava landzelaka, lava nga ta ku pfuna ku endla xikombelo:
Tirhasiti i ta:
Ku ringanela ku kuma mali ya tiphurogireme ECD
Ku fika sweswi
Ndzi ta ku nyika xikombiso ku kukombisa ku hambana.
nomboro yi tlakukile yi fika eka mamiliyoni ya 13 ya vaendzi.
Sweswi a hi hundzeleni eka vumundzuku.
Nhundzu na vukorhokeri swi cinciwa emakete.
Nhluvukiso wa vurimi wu fanele ku humelela goza rin'we hi nkarhi.
Maendlelo ya swilo hi ndlela leyi toloveriweke no tiveka ya ta tirhisiwa eka swibalo leswi nga kona sweswi leswi landzelaka:
Ku nga ri lexi ngahansi ka leswo.
Xiviko i goza ro sungula ra xiyimo xa le henhla ku yisa eka leswi.
Leswo hetelela swi vonaka swi ri swa nkoka swinene ku ya hi nsinya.
A hi tirheni kun'we ku endla leswaku lembe leri ra migingiriko ri va ro humelela eka tiko ra hina.
Swi endlise ku yini?
U nga pfumeleri ku mitiwa hi xivumbeko xa tikomiti ta tiwadi ku huhurisa vukorhokeri bya tona byi kongomisiwa eka vanhu vo karhi, ngopfungopfu mayelana na mitirho ya masungulo ku fana na ku amukela na ku hundzisela swivilelo na tiphetixini.
nkwama wa xikhigelo
Ndzi seketela nsusumeto wa xiviko lexi.
Swi na nkoka ku teka goza hi ndlela ya misava hinkwayo.
xikhongelo xa mixo
hlangana
leyi nga ta khakhuletiwa ku suka eka siku leri yi nga susiwa ku fika eka siku ra tihakelo.
Hikwalaho ka sweswo hi ku twisisa nxungeto, mphikelelo wa vaakandhawu wu nga kota ku antswisiwa.
Tiphurojeke hi nhlamuselo ya tona ti fana ti ri toxe naswona ti khumba nchumu wo karhi wuntshwa.
Masipala a wu nge vi na vutihlamuleri eka ku onhaka kwihi na kwihi loku nga ha vangiwaka hi ku aleleriwa kumbe ku tsamiwa ka vukorhokeeri bya mati.
Ndlandlamuxa vulawuri bya tiphenalithi eka ku ka ku nga landzeleriwi milawu.
Ku tlakusa vuswikoti bya sisiteme; 2.
u ta rhumeriwa layisense ya wena.
Lowu i antswiso.
Kutani Napoleon u yimile ku hlamula.
Tihakelo ti nga langutisiwa hi vuntshwa lembe na lembe kumbe ku nga tekiwa xiboho hi Holobye wa Timhaka ta Mbango na Vupfhumba kumbe vulawuri lebyi vekiweke
Leswi swi kongomisiwa eka xiyimo xa le makumu xa SAPS ku lwisana na vugevenga lebyi nga ku humeleleni emisaveni hinkwayo loko hi nkarhi wun'we ku fikeleriwa swilaveko swa Mfumo lowu wa ha hluvukaka.
hundzulo lowu ku amukeleka ntsena xiphemu xa wona.
Van'wana va lava ku tlhantlhiwa na ku nyikiwa matimba swinene.
Loko ku ri na mukhuhlwana wa swinyenyana kumbe muxaka wun'wana na wun'wana wa vuvabyi, tiyimbhu a ti nga rhumeriwi ematikweni mambe ku kondza swikombiso swi nyamalala.
Mimpimo leyi tekiweke hi Nhlangano wihi na wihi yi fanele ku fambelana ni ku tika ka xiyimo.
A ku ri ntirho wa matimu.
Hi seketela mbuyelo yo tilawula hi woxe lawa leswi swi nga wona.
Eka Nhlamulo ya wena kongomisa eka leswi landzelaka:
Sweswo hi leswi hi nga le ku swi sindziseni eka xiviko lexi.
Lebe leri hi ta yisa emahlweni ku tiyisisa matshalatshala na ntalo eka mfumo wa muganga ku fambelana na Ajenda ya Tindlela ta Mfumo wa Muganga ya 5 wa malembe.
Ku vile ni nkumbetelo ehenhla ka swona, wa swi tiva.
Holobye u fanele ku veka nawu hi ta mithwaso ya vakamberi.
A ndzi nge lulamisi ku cinca loku hi nga twanana.
leyi a hi mhaka leyi hakunene yi fambelanaka namuntlha.
ku cinca ka ikhonomi ya misava hinkwayo
Leswi hi swona ntsena leswi hlayisekeke hi ku hetiseka.
Xiphemu xin'wana xa nkoka xa nawu wuntshwa i Komiti ya Vukorhokeri bya Nkoka.
Hlamusela matheme lama landzelaka hi ku landza vundzeni bya ripfumelo.
Mbuyelo i wa ku onhaka ka phayiphi swinene.
Vana va ya hi xitalo hikkwalaho ka ku hunguteka ka mpfhuka woya exikolweni
Hi mhaka ya ku va mutirhi a pfumala vutivi
Vamanana na vatatana, ndzi xixima mavonelo ya n'wina.
Nkatsahinkwavo
hakerisa no vuyisa tihakelo ku suka eka vanhu lava tsarisiweke levy and recover fees from registered persons;
Lexi vuriweke ra vumbirhi
ku tlakusa nhlayiso
Leri i ra vunharhu lexi xi karhi xi humelela.
Swi na xiave xo hambana swinene namuntlha.
Application for registration of a fire protection association eka va Ndzawulo ya ta Mati na Swihlahla.
Mavhengele
Swimbirhi swa leswi swi lulamile ku ya eka ku twa miehleketo
Nyika swihlawulekiso leswi endliweke swa vuhungasi:
amelojenini
Yuniti yi ta pakanisa nakona eka mitlawa yo karhi ya vaehleketeriwa.
Vuyimelo?
xo vavisa
Hi ta endla nandzelelano wa swibumabumelo.
Ndza khensa nhlamulo ya n'wina.
Kun'we, loko un'wana na un'wana wa hina a hoxa xandla, hi nga endla swo tala swo antswa.
Hikokwalaho xiviko lexi ku tirhaniwile na xona ku hambana.
A ku ri lembe leri nga hundza, naswona a hi fanelangi ku ri rivala.
ku sungula eka nongoloko wa lava a va ri kona
ndlela ya ku yisa emahlweni ku engetela vutekaxiave bya ku ringana eka vamanana na vatatana
Hi xona xiyimo xa hina lexo.
Hi nga swi kanela sweswo.
Ku yimisiwa ka nkarhi wo leha ka vilerisa swinene naswona swi ta landzelerisiwa swinene.
Swin'wana leswi nga na nkoka eka swa maqhingha i ntirhisano eka swa eneji.
Mhaka ya mina ya vumbirhi, va swirhundza na va matlhari, yi khumba malawulelo ya timali lama ringaneleke.
Misava ya le nhoveni ya Mfumo kumbe swiphemu swa yona yi nga ha pfariwa.
Ku lahla ra vumbirhi
ku tihlawulela ku tika
Leyi i ndhawu leyi nga bohiki naswona yi nga tatisiwa.
kumbe mixaka ya madzolonga ya le mindyangwini.
vumbhoni bya hlelelo na kumbe swikambelo emakumu ka lembe rin'wana na rin'wana
Laha hi kona vun'we hakunene byi fikaka emakumu.
Hi ntiyiso, lowu i nsinya wa milawu ya khamphani hansi ka yin'wana eku tirheni.
hi pfumela leswaku ntirho wo kondletela ku rhula wu fanele ku ya emahlweni.
Ndzi tlhela ndzi seketela ku cinca hi xikongomelo
ku pasa matiriki
Invhoyisi ya ntiyiso ya xibalo yi fanele yi khomiwa hi wena.
Xikombiso 2: Mutirhi u tirhisa nhundzu ya mfumo ku fana na movha, michini kumbe vhanichara hi ndlela ya vusopfa a tlhela a swi onha.
Nhluvukiso wa ikhonomin emadorobeninkulu..
Swi lulamile ku njhani wena?
A hi yeni emahlweni na swona hi tirha swin'we.
Xivumbeko xa NCOP
Tifomo ta mali leyi nghenaku ya vuvekisi, timfanelo ta prophati na ti-royalty
Xikongomelo xa byona i ku tumbuluxa swiyenge swa mabindzu ka vanhu va muganga, nakambe phurojeke yi tumbuluxile vutirhisani na Ndzawulo ya Nhluvukiso wa Matikoxikaya na Antswiso wa Misava, Ndzawulo ya Vurimi ya xifundzankulu, swa Mbango na Nhluvukiso wa Matikoxikaya na Ezemvelo KZN Wildlife.
Kutani a ku ri na swivangelo swin'wana.
Hi ta hlayisa xikombelo xa hina xa vhoti ya mbitanelo wa mavito.
hi tlhela hi lava ku tirhisa minongonoko ya nkarhi wo leha
Walowo i ntiyiso wa ku tirhisa endlelo ra ku nga teki xiave.
Leswi kahlekahle swi lawuriwa hi milawu ya ntumbuluko.
nkoka wa mpfuno.
Ku ta va ku nga ri ku hlawula ko hetelela eka leswi kongomaneke na vadyondzisi.
Xipimamikarhi ku hetisisa makungu ya wadi (ku suka Maluti-a-Pofung)
Hakunene, ndza swi twisisa leswaku ku na ku langutisisiwa ka swa vubindzurisi.
Hi tirha eka ndhawu yo bohana ngopfu.
ku khensa na rirhandzu.
emahlweni ka Presidente wa Khoto ya Vumbiwa
Malembe ya khumembirhi endzhaku ka ku tumbuluxiwa ka xidemokirasi
5. Dipozita ntsengo wa mpfumelelo eka akhawunti ya bangi ya Ndzawulo:
Ku tirhisiwa tiforamu leti nga kona leti nga boxiwa laha henhla.
Swi fanele ku yimisiwa.
nhlengo
u na ku tsakela hi ku kongomisa kumbe ku nga ri hi ku kongomisa eka kontiraka yihi na yihi na Huvo naswona a tsandzeka ku hlambanya / tiyisisa ku tsakela ka yena na vuvekisi kolaho hi ndlela leyi laviwaka hi Nawu lowu is directly or indirectly interested in any contract with the Council and fails to declare his or her interest and the nature thereof in the manner required by this Act;
xi va murhangeri wa vurhumiwa byelebyo.
hi tshembha leswaku misava yi fanele ku amukela ntirho wa nkoka lowu engetelaka wu endliwaka hi China.
Leswi a hi yona mhaka.
Tanihileswi ku nga hava xitshunxo lexi nga erivaleni lexi ringanyetiweke, swi tikomba leswaku eka nkarhi lowu taka lowu nga ehleketiwaka Xinghezi xi ta tama xa ha ri lingua franca ya tiko ku fikela loko mhaka leyi ya tlakulavaxurhe ya tindziminyingi ta masiku hinkwawo yi ololoxiwa eka levhele ya rixaka.
Tolovela TIMHAKA ta kahle ku endlela leswaku u kota ku tisirhelela wena
Mufambisi wa IDP hi yena munhu loyi a faneriwaka hi ku hlamusela vavevukisi ni vakhanselara va tiwadi hi mahungu ya nkoka yo huma eka IDP
Xikombelo xa khoramu ku va yi tumbuluxiwa xi ariwile.
Xo sungula eka hinkwaswo, i pholisi ya misava hinkwayo.
gandlaso-tapula
Swo tala swa swiringanyeto swi katsiwile eka xitshuriwa.
Hambiswiritano
A ndzi tivi loko Liesl Loubser a ri laha
Hikokwalaho ka xivangelo lexi, ntlawa wa mina wu ta vhota wu kanetana na swona.
Xiviko lexi xi tile hi nkarhi.
endlelo ra vuleteri bya wa valeteri ri humelerisiwile eka timasipala to tala.
Loko ku nga si humesiwa vutivi eka va hofisi ya ku rejistara titayitele
I mali muni?
Na leswaku leswi swi teka ndhawu ya swona eka vanhu.
Xo sungula, hinkwavo lavaya va tirhaka eka indasitiri.
Eka nhlengelatano (Lekgotla) wa Khabinete hi Sunguti, hi kunguhatile ku endla nkambisiso wa le xikarhi ka kotara, hi langutisa eka ku humelela loku ku veke kona ku suka hi 2009 ku fikela sweswi, ematshan'wini ya nkambisiso wa ntolovelo wa ku hela ka lembe.
Xiviko xa Lembe na lembe xa Eskom.
Kambe, xiyenge xa vaaki xi fanele ku nghenisa xandla xa nkoka.
Nghingirikonkulu (xitumbuluxiwa)
Vukorhokeri byo sungula - nhluvuko ya endliwa ku tiyisisa leswaku vanhu hinkwavo va fikelela mati yo tenga, mbhasiso na gezi.
Swivangelo i Ina:
Swi faneleku humelela.
ntleketlo wa malakatsa wa vhiki rin'wana na rin'wana mikarhi hinkwayo ku suka eka phevhumente leyi nga ehandle ya vutshamo byin'wana na byin'wana
Nyika ntlawa wun'wana na wun'wana mitirho leyi landzelaka.
Naswona swesw swi tirhana na ku vuyeleriswa loku hi faneleke kuva hi ku endla.
Nghingirikonkulu wo tihanyisa
yele
leyi hoxaka xandla eka swiyenge swa mafumelo eka swiyimo swo hambanahambana
u fanele ku tshama u ri karhi u kamberiwa miri wa wena hambiloko u nga ri na swikombiso swa ngati leyikulu
Leswi hi swi hlamuseleke laha i xileriso xa mavuthu.
hi rindzerile etibuweni ta nambu.
Kutani, hi taya emahlweni ku tihlanganisa no kuma ntwanano.
Hi nga tlhela hi vona ku hambana eka xiboho.
Ku kunguhatiwa leswaku phurogireme yi ndlandlamuxiwa eka tindhawu leti faneleke ku katsa:
Swirho swimbirhi swintshwa swi ta ya eka nhlengeletano leyi landzelaka ya Komiti.
Ntlawa wa Hlelelo ra Matirhelo.
A hi tiko ra hina.
exifundzeni xa -
Swivutiso leswi landzelaka swi nga va leswi pfunaka
A swi kanakanisi leswaku ndzavisiso na nhluvuko i swivumbi swa nkoka.
Ku hundzuluxa hinkwako loku ku fanele ku va kona.
Xana mimfumo yi nga va na swihlohleteri njhani leswi kahlekahle swi nga tumbuluxaka mulawuri loyi a tiyimelaka ngopfungopfu eka tithelekhomu hikuva a swi langutiseki mimfumo yi ri na xihlohleteri xa ku tumbuluxa mulawuri loyi a tiyimelaka ngopfungopfu loko va hundzuluxa mikavelo ya mfumo ku ya eka yo ka yi nga ri ya mfumo eka Telkom ku ya hi mhaka ya leswaku i khamphani leyi ngo va yoxe laha swi langutisekaka onge lava endleke swikombelo swa mitirho leyi fanaka na khamphani leyi swi landzuriwile.
Xi endleriwe ku tshama.
Xavumbirhi, hi fanele hi vulavula hi mfikelelo wa makete eka tinhundzu na vukorhokeri.
Hambiswiritano a hi lavi ku hambanisa matiko ya va woxe ku fana na leswi.
Georgia, hakunene, yi na xiave xa nkoka laha.
Hi ndlela leyi vonakaka, Batho Pele yi ta va na xiave eka ndlela leyi ntirho wu endliwaka hayona hi ku tirhisa Sisiteme ya Mafambiselo ya Matirhelo leyi vekaka swikombiso swa matirhelo kutani hi ndlela yoleyo yi endla leswaku mfumo wa muganga na vaakindhawu va kota ku pima leswi fikeleriweke ku ya hi swikombiso leswi.
Ndzi ta amukela swona sweswi
Minxopanxopo leyi yi endliwile hi ku twisisa timhaka ta swa matimu ya hina na ku nga amukeli ka ku humelela ka hina ku fika sweswi; ku fambisiwa hi ku tiyimisela ku endla swa kahle, ku lulamisa leswi nga lulamangiki na ku tisa vutomi bya kahle ka hinkwavo.
tlhantlha
ku tlakusa na ku landzelerisa xiyimo xa le henhla xa matikhomele eka vutirhela mfumo.
Vutihlamuleri bya ku tsakela loku byi le ka Tinhloko ta Tindzawulo na Tinhloko ta Vuhlanganisi.
g) Dokodela Jeffrey Mabelebele (Dyondzo ya le Henhla ya Afrika-Dzonga)
a ndzi voni swiphiqo leswikulu.
Mimovha leyi yo hlawuleka yi nga katsa teretere, michini yo borha mati, michini yo tshovela, yo rima, tsema byanyi, hala, levhela, michini yo fafazela, michini yo tlakula swo tika, xigolonyana xo hlanganisela, movha lowu endleriweke swo hlawuleka kumbe cinciwile kuva wa mphikizano na / kumbe nkombiso.
Mhaka ya vumbirhi yi fambelana na vuhlayiseki na vululami.
nawu wo sivela ku tibombisa
Ndzi ta rhandza ku ka ndzi nga vi na nkanerisano wa vuxokoxoko laha.
Handle ko dya nkarhi wun'wana
Xiletelo xa ntolovelo hi leswaku miphalalo
Ku fikela loko nawu lowu boxiweke eka xiyenge xa 229 xa Vumbiwa byintshwa xi nghenisiwa, mhasipla wu ta tshama wu ri na vuswikoti byo hakerisa xibalo, ndzhuvo kumbe ntirho lowu wu nyikiweke matimba hi Vumbiwa ku wu endla wu endliwa.
Nxaviselano lowu tshunxekeke a wu fani na.
Vona na miganga ya vona va na swotala ku swi endla eku akeni rixaka leri rintshwa.
Xiyimo lexi xi fanele ku lulamisiwa hi xihatla hilaha swi nga kotekaka ha kona.
emfuweni na le migangeni.
u fanele ku tatisa fomo ya C.
Tsalwa ku ya hi Xiyenge xa vu 14 xa nawu wa ku fikeleriwa ka Mahungu (PAIA)
Swi na ajenda ya swa tipolitiki.
Tanihi mfumo hi tibohile.
Ndzavisiso wu komba leswaku magidigidi ya timhangu ta TB ti tala ku va kona hakanyiki ku tlula ka ntlhanu hi vunyingi swinene ku tlula hi lahaleswi a swi faneleke swi va xiswona hikokwalaho ka HIV na AIDS.
ndzuvo
Leswi swi twala tanihi mahungu lamanene, kambe xana swi vula yini hi ntiyiso?
Mimpimo ya muako yi nga pfuna ku lawula vugevenga
hi swi teka tanihi mhaka leyikulu swinene.
ntirho wo tsala
Nhlamulo yi vile ya kahle.
endla xiyimo xa nghozi kumbe a tlula xinawana; naswona a
Tirhisa milawu leyi landzelaka ku hambanyisa:
Sweswi Navy ya Afrika-Dzonga yi na ku hatlisa lokuntshwa.
Swi tano, xexo xi ta va xi ri xitshunxo xa khombo swinene.
sweko
rimbewu-fularha
Ehleketelo ra mina ra olova.
ku phahla hi munhu
Ndzi rhandza ku hoyozela vaviki hivambirhi hi malwandla.
nkambelo wa xihatla
ravunharhu
Khabinete yi amukerile ximfumo marito yo kombela ku rivaleriwa ku suka eka Holobyenkulu wa Central African Republic, Tatana Nicholas Tiangaye, eka leswi humeleleke ku nga leswi nga riki kahle leswi nga endla leswaku ku kondza ku hundza emisaveni swirho swa Vuthu ra Vusirheleri ra Afrika-Dzonga (SANDF).
ku nga ka vanhu, ikhonomi, mfuwo sw na sw.
Ndzi lwile na ntshikelelo wa valungu, naswona ndzi lwile na ntshikelelo wa vantima.
Swirho swa ndyangu leswi nga na 5 wa malembe ku ya ehenhla, leswi nga hava dyondzo ya ximfumo na leswi nga na tidyondzo ta le hansi swi fanele swi tata xivutiso lexi
Tanihiloko swi nga koteki ku va muaki un'wana na un'wana kumbe xirho xa vaakindhawu xi katsiwa eka maendlelo yo karhi, swi nga ha lava ntsena ntlawa lowutsongo lowu hlawuleriweke ku tirha timhaka to karhi.
Yi kombisa levhele yo ringanela ya mavonelo na ku twisisa.
Rheferandamu yi fanele ku va kona.
Ku hi swivangelo leswi leswaku hi kuma tilevhele ta sweswi ta mpfumaleko wa ndzingano wu nga amukeleki.
2.1 Endzela Senthara vuleteri bya swatindlu e Kumberley
A hi si tshama hi vona nchumu wihi na wihi eka mhaka yoleyo.
vunyingi bya swirho swa tikomiti ta tiwadi byi boxile leswaku nkarhi lowu swi tweke hi ta mpimanyeto wa masipala hi le nhlengeletanini leyi meyara a andlaleke mpimanyetompfapfarhutwa.
xikongomelonkulu i ku tlakusa vutumbuluxi.
leswi hi leswi hi swi endleke laha.
leswi hi nga pakanisa eka swona.
Lexi a xi kahle.
Loko va fika ematikweni lawa mitirho leyi yi nga vuriwa ku yi kona
onha
Swi amukeriwile.
Ndzi lava ku ku khensa eka sweswo.
masipala wu fanele ku kombisa leswaku wu lulamisile xilaveko xa Xiyenge xa 7 lexi eka xona PMS yi
Swi le ka miehleketo ya vana va hina na vadyuhari va hina.
Vuhumelerisi bya swakudya byi na swiyenge swinharhu – vurimi, vumaki na xiyenge xa mpahla/swakudya.
Ku vuriwa leswaku mimpimo ya mitswalo yi sungula ku wa.
Sweswo a hi xihundla.
Hakunene, ku vile na matshalatshala eka nkarhi lowu nga hundza.
Mitlawa ya vativinkulu
Naswona sweswi hi na ntlimbo wa vanhu.
Loko ndyangu wa mina wu rhurhela laha
Xavumbirhi
ku lulamisa matirhelo ya le hansi
hi ku hetiseka mfularhelo wu tano.
Hi yima laha namuntlha ku tsundzuka switshembiso swoleswo.
eka dyondzo ya nkoka na ku tshama eka tindhawu leti nga tshama kahle.
Namuntlha, kwalomu ka 17 wa tiphesente ta vanhu va tiko ra Afrika-Dzonga va kota ku fikelela inthanete - nhlayo leyi yi nga eku tlakukeni hi kwalomu ka 20 wa tiphesente hi lembe.
ID ya wena, loko swi endleka, na ID ya loyi u lavaka ku endla xikombelo xo kuma mali ya nhlayiso eka yena.
Handle ka swona ringanyeta vundzeni bya xirhendzevutani.
ndzi helela hi marito ya hilaha ndzi nga hlamuselaka ku khensa ka mina swi hetiseka eka nseketelo lowu wa timali - na nkateko wo tlhela ndzi tiyimela.
Lexi hi xona xi nga endla leswaku hi va khomile njhekajekisano lowu namuntlha.
Ku endliwile swo tala ku lulamisela wena.
Muhirhi
Muviki a nga lava ku tekela leswi enhlokweni.
Nandzeleriso na ku pima matirhelo ya manyikelo ya vukorhokeri i endlelo ra ku kambela loko ku fikeleriwile swikongomelo leswi vekiweke emasunguleni naswona swa laveka eka xiyenge xin'wana na xin'wana xa mpimanyeto ku ya hi xiphemu xa 27(4) xa PFMA.
ku rima hi ndzhambalalo
Leyi yo va ntsena yin'wana ya vuhina leswi hi hanyaka na swona hi ku hambanahambana.
Hi sirhelela ehenhla ka lexi.
1.1.1 Swilaveko swa Nawu ku ya hi KNP
Eka nkarhi wa sweswi, ha ha ri eka xiyenge xa makunguhatelo.
xikhongelo xa ku nkhensa
Samiti yo sungula yi endliwile eCairo hi 2000.
Mbundzumuxo i xiphemu xa kontirakankulu leyi nyikiweke namuntlha.
Vhoti yi ta va kona hi nkarhi wa xiphemu xa sexini lexi nga ta landzela.
Hi ku vona ka mina, i xikombiso xa ku tivona hi hi ri na mavonelo ya xiyimo xa le henhla hi ri hexe ku tlula mpimo.
Hi ku navelela mikateko eka ntirho wa wena tanihi Presidente.
Hambiswiritano, kahlekahle, xiviko xi kongome ku endla swilo swimbirhi.
Xipano xo herisa xi ta tirhana ni swiphiqo swihi na swihi eka mhaka leyi.
Hinkwawo magoza lawa a ya amukeleki.
Ndzi vona leswi tanihi xiphemu xa nkoka swinene ngopfu.
Leswi swi vula leswaku n'wana a nga fanelanga ku nwisiwa mati kumbe swihalaki swin'wana kumbe ku dyisiwa swakudya eka tinhweti ta tsevu to sungula.
Ku na ku lahlekeriwa swinene: ku hela ka ku tshemba eka vumundzuku lebyinene.
Leswi swi kombisiwile eka vhoti ya ntwanano wa hinkwavo eka komiti ya hina.
Ya kumeka hi mixaka mimbirhi: muxaka wa le Henhlahenhla, lowu eka wona munhu a faneleke ku titsarisela ku wu kuma nkarhi na karhi, na muxaka wa Masungulo, lowu wu nga mahala kambe wu katsaka tiatikili na swihlawulekisi swi nga ri swingani.
Ndzi tsakela ku yisa emahlweni mhaka leyi ya nkoka.
Mina hi xiviri ndzi tinyiketerile eka timhaka leti.
Tafula
Xitirho xa IDP 6: Ku hlanganisiwa ka tiwadi hi maqhinga ku ya hi timhaka leti rhangisiwaka ta IDP ku suka eka maqhinga ya CBP ku ya hi mivuyelo leyi rhangisiwaka (Xiendleko 20)
Xana u fanela ku endla leswi eka levhele ya ximfumo?
wa mahala eka ndhawu ya vukorhokeri
Leswi swi lava hina leswaku hi kambela xiyimo xa Mfumo.
Hikokwalaho ka xivangelo xexo hi landzula xitshunxo lexi.
xiphiqo xi nga vuya nakambe nkarhi lowu taka hikuva a xi ololoxiwanga hi nkarhi wa ntlimbo.
"Ndzi twe hi yona eka TV na rhediyo
Ku boha ku i mali muni ya nkumbetelo hinkwawo wa tihakelo yi nga ta averiwa eka switirhisiwa swin'wana na swin'wana swa ntirho.
Ravumune a ri vonaki onge i miehleketo ya kahle.
Holobye wa Vulawuri na Vukorhokeri bya Vanhu
Ku hava xikombelo xo fekisiwa kunene xi nga ta amukeriwa.
Ku vutisa hi mitsengo ya vutshunguri na/ kumbe mimpfuxelelo na ku twanana hi mahakelelo
U nga ha pota xihumelelo hi ndlela yo ka u nga tiboxi, loko u swi lava.
Xana ku humelela loku ku fika kwhi eAfrika?
Xitatimende xa nhlengeletano ya Khabinete ya 30 Dzivamisoko 2013
Holobye wa Nhluvukiso wa Vaaki kumbe Xirho xa Huvo Nkulu xi fanele ku thola un'wana leswaku a nghenelela.
Minkunguhato ya hina yi fanele yi famba swinene ku tlula mfikelelo wa nseketelo wa timali.
Leswi hinkwaswo swi ta vuyerisa mbangu hi ndlela leyi nga erivaleni.
A hi fanelangi hikokwalaho ku amukela xihundzulo lexi tanihilaha xi andlariweke hakona.
A hi njhekanjhekisano wo olova.
Kambe hi tlhela hi tiva leswi hi swi endlaka ku tiyiseleka.
Eka xivumbeko xa rhandzavula lexi vumbiweke hi meno mambirhi i tindleve ta koroni, leti funengeteke xitlhangu xa golidi lexi nga le xikarhi.
Ndzi kholwa leswaku hi yona ndlela yi ri yoxe yi amukelekaka yo yi landzelela.
Hi ku komisa, a ku humelelangi nchumu.
pfuna khanselara wa wadi mayelana na swivilelo leswi humaka eka vaakindhawu;
xiphemu xa le ndzeni-ndzeni
